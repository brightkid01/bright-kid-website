(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.Bitmap2 = function() {
	this.initialize(img.Bitmap2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,73,48);


(lib.Bitmap3 = function() {
	this.initialize(img.Bitmap3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,73,48);


(lib.BRIGHTEDGEEDUSYSTEMPVTLTDlogopng1 = function() {
	this.initialize(img.BRIGHTEDGEEDUSYSTEMPVTLTDlogopng1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1601,404);


(lib.sound = function() {
	this.initialize(img.sound);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,834,834);


(lib.Sunflowerpngwithleaf = function() {
	this.initialize(img.Sunflowerpngwithleaf);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,451,699);


(lib.Symbol113 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AieFBQg0gsgOhaICEgOQAFApAVATQAUATAiABQAqAAAdgoQAegnAIh7QgzA8hNABQhUAAg9hBQg+hBAAhoQAAhtBBhDQBAhDBkAAQBsAABGBUQBGBVAADAQAADEhJBXQhIBXh0gBQhUABg0gtgAhOjdQgZAeAABFQAABFAbAgQAbAgApAAQAnAAAbgfQAbgfAAg9QAAhCgegkQgfglgnAAQgmAAgZAeg");
	this.shape.setTransform(29.075,57.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("Ah+EBQgqgkgLhHIBqgLQAEAgAQAQQARAPAaAAQAhAAAYgfQAYgfAHhjQgqAwg9AAQhDAAgxg0QgxgzAAhUQAAhXA0g1QAzg1BQAAQBWAAA4BDQA4BDAACbQAACbg6BGQg6BGhdAAQhDAAgpgkgAg+ixQgVAYAAA3QAAA3AWAbQAWAZAhgBQAfAAAWgYQAVgZAAgwQAAg1gYgdQgZgegfABQgeAAgUAXg");
	this.shape_1.setTransform(29.275,57.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAcEgIAAhzIjpAAIAAhhID4lqIBcAAIAAFqIBHAAIAABhIhHAAIAABzgAhmBMICCAAIAAjDg");
	this.shape_2.setTransform(29.675,56.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(58,61,118,0.247)").s().p("AkhHNIAAuZIJDAAIAAOZg");
	this.shape_3.setTransform(28.5,55.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_3},{t:this.shape_2}]},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,0,60.3,115.8);


(lib.Symbol112 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AioEZQhGhUAAjAQAAjEBIhXQBJhWBzAAQBSAAA2AtQA1AuAPBXIiFAOQgFgpgVgTQgUgUghAAQgqAAgeAnQgeAngIB8QAzg9BMAAQBVAAA+BCQA9BAAABoQAABuhABCQhBBChlAAQhsAAhFhUgAg5AVQgbAeAAA9QAABDAeAlQAgAkAmAAQAmAAAZgeQAZgeAAhEQAAhGgbggQgbgggpAAQgmAAgcAfg");
	this.shape.setTransform(30.15,57.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("AiGDhQg4hEAAiZQAAidA6hFQA6hFBcAAQBBAAArAkQArAlAMBFIhrAMQgEghgQgQQgQgPgbAAQghgBgYAgQgYAfgHBjQApgwA8gBQBFABAxA0QAxAzAABTQAABYgzA1Qg0A2hRAAQhWAAg3hEgAgtARQgWAYAAAwQAAA2AYAdQAZAdAfABQAeAAAUgYQAVgZAAg2QAAg4gWgaQgWgZghAAQgeAAgWAZg");
	this.shape_1.setTransform(30.125,57.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AiCD4QgzgtgIhIIBqgOQAFApAWAWQAXAVAfABQAhAAAYgaQAXgaAAgsQAAgqgWgXQgXgZggAAQgUAAgdAJIAMhZQArABAYgUQAXgVAAgiQAAgdgRgRQgRgRgcAAQgcgBgUAVQgUATgEAlIhlgRQALg0AVgfQAVgfAmgRQAmgTAwABQBPAAAxAzQApAqAAA2QAABLhTAsQAxALAeAkQAdAlAAAzQAABMg3A1Qg3A2hRAAQhOAAgzgtg");
	this.shape_2.setTransform(29.625,57.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(58,61,118,0.247)").s().p("AlUHhIAAvBIKoAAIAAPBg");
	this.shape_3.setTransform(35.25,56.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_3},{t:this.shape_2}]},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,69.3,115.8);


(lib.Symbol111 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAkFnIAAiQIkkAAIAAh4IE1nFIB0AAIAAHFIBYAAIAAB4IhYAAIAACQgAiABfICkAAIAAj0g");
	this.shape.setTransform(85.175,56.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAUFnIAAoEQhKBGhmAiIAAh8QA2gSA/gxQA+gxAXhBIBvAAIAALNg");
	this.shape_1.setTransform(25.625,56.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("AAcEgIAAhzIjpAAIAAhhID4lqIBcAAIAAFqIBHAAIAABhIhHAAIAABzgAhmBMICCAAIAAjDg");
	this.shape_2.setTransform(74.175,56.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("AAQEgIAAmdQg7A4hSAbIAAhjQArgOAygnQAygoATg0IBZAAIAAI+g");
	this.shape_3.setTransform(26.525,56.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#D4D4D4").ss(1,1,1).p("AIznPIAAOfIxlAAIAAufg");
	this.shape_4.setTransform(62.325,57.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF0000").s().p("AoyHQIAAufIRlAAIAAOfg");
	this.shape_5.setTransform(62.325,57.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,119.7,115.8);


(lib.Symbol110 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AjuD6Qg1hoAAiiQAAiMBGhqQBVh+CTAAQCLAABOBxQBABfAACHQAADZhKBsQhKBtiTAAQiiAAhJiLgAh0i2QgqBEAABaQAAB2AXBBQAkBoBgAAQBPAAAohJQAohJAAiRQAAh1gkg6Qglg6hJAAQhOAAgwBPg");
	this.shape.setTransform(93.325,75.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhTF8QhdAAAAg6QAAhBBoAAIAVAAIAAmwQgqAdgNAAQgcAAgUgTQgUgUAAgaQAAgaAhgdIA3goIA7gwQAkgaAiAAQAsAAAAA1QAAA6gFBpQgFBqAADDIAAB2IAhAAQAcAAATASQAUASAAAbQAAAbgUASQgTASgcAAg");
	this.shape_1.setTransform(31.175,74.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("Ai+DIQgrhTAAiCQAAhwA5hUQBEhlB1AAQBvAAA+BaQA0BMAABsQAACtg7BXQg7BXh2AAQiBAAg7hvgAhciSQgiA3AABIQAABfASAzQAdBTBNAAQA/AAAgg6QAgg6AAh0QAAhegdguQgegvg6AAQg+AAgmA/g");
	this.shape_2.setTransform(81.15,74.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("AhCEwQhKAAAAguQAAg1BSAAIASABIAAlaQgiAYgLAAQgVAAgQgQQgRgPAAgVQAAgWAagWIAsggIAwgnQAcgVAcAAQAjAAAAAqQAAAvgEBUQgEBVAACbIAABfIAaAAQAWAAAQAOQAPAPAAAVQAAAWgPAOQgQAPgWAAg");
	this.shape_3.setTransform(31.425,73.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#D4D4D4").ss(1,1,1).p("AJHqFIAAULIyNAAIAA0Lg");
	this.shape_4.setTransform(49.225,64.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF0000").s().p("ApGKGIAA0LISNAAIAAULg");
	this.shape_5.setTransform(49.225,64.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.1,-1,136.4,144.4);


(lib.Symbol109 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(58,61,118,0.247)").s().p("EhKyANxIAA7hMCVlAAAIAAbhg");
	this.shape.setTransform(464.7218,88.125,0.9707,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,929.5,176.3);


(lib.Symbol81 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhVA4IAAhvICrAAIAABvg");
	mask.setTransform(8.575,5.625);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.Bitmap3, null, new cjs.Matrix2D(0.235,0,0,0.235,-8.6,-5.6)).s().p("AhVA4IAAhvICrAAIAABvg");
	this.shape.setTransform(8.575,5.625);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,17.2,11.3);


(lib.Symbol79 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhVA4IAAhvICrAAIAABvg");
	mask.setTransform(8.575,5.625);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.Bitmap2, null, new cjs.Matrix2D(0.235,0,0,0.235,-8.6,-5.6)).s().p("AhVA4IAAhvICrAAIAABvg");
	this.shape.setTransform(8.575,5.625);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,17.2,11.3);


(lib.Symbol62 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Sunflowerpngwithleaf();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,451,699);


(lib.Symbol25copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol22copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
		
		this.stop();
	}
	this.frame_1 = function() {
		playSound("wro");
	}
	this.frame_59 = function() {
		/* stop();*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(58).call(this.frame_59).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AAAhvIAADf");
	this.shape.setTransform(0,11.225);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,2,24.5);


(lib.Symbol21copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{corsound:1});

	// timeline functions:
	this.frame_0 = function() {
		/* this.stop();*/
		
		this.stop();
	}
	this.frame_1 = function() {
		playSound("yes");
	}
	this.frame_74 = function() {
		/* this.stop();*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(73).call(this.frame_74).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AAAiCIAAEF");
	this.shape.setTransform(0,13.075);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(74));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,2,28.2);


(lib.Symbol20copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* this.stop();*/
		
		this.stop();
	}
	this.frame_1 = function() {
		/* stop();*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AoFEgIAWABQCHAACnjOIAcgjIgkgnQiZigABhwQgBhdCnh8QAYCgB1CXIAfAnIAYgfQCsjcCNgBQBtAAA4CnIgXgCQgxAAhbBCQhZBCg/BVIgeAoIAdAeQCnChC0AAQhgDDhqAAQhfABizioIgugrIgQAVQihD0hnAAQh3AAhyjBg");
	this.shape.setTransform(7.8,9.5);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-44,-38.6,103.6,96.2);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		/* _root.b1.enabled=false;
		_root.b2.enabled=false;
		_root.b3.enabled=false;
		_root.b4.enabled=false;*/
		
		this.stop();
	}
	this.frame_141 = function() {
		/* stop();
		
		_root.b1.enabled=true;
		_root.b2.enabled=true;
		_root.b3.enabled=true;
		_root.b4.enabled=true;*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(140).call(this.frame_141).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
		
		this.stop();
	}
	this.frame_1 = function() {
		/* stop();*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00873C").s().p("Al8G2IgYg4Qg0h6gtg6Qgtg6g3gUQBdhiBOAAQBEAABRC1IAbA9QCTj3DljpQDnjqDbh9IAeAsQi7CNjiEhQjjEjh4D8IhAAsQhRA4gbAaQgMgpgmhdg");
	this.shape.setTransform(46.375,-15.4);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.8,-72.6,120.39999999999999,114.39999999999999);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.sound();
	this.instance.setTransform(9,9,0.0761,0.0761);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(9,9,63.5,63.5);


(lib.Symbol1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


// stage content:
(lib._9 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		this.stop();
		this.stop();
		createjs.Sound.play("intro");
		//this.stop();
		
		this.b1.addEventListener("click", fl_MouseClickHandler_2.bind(this));
		function fl_MouseClickHandler_2() {
			// Start your custom code
			// This example code displays the words "Mouse clicked" in the Output panel.
			//alert("Mouse clicked");
			//this.dhoti.play();
			this.wrong1.play();
			var my1=createjs.Sound.createInstance("wro");
		this.my1;
		my1.play();
			// End your custom code
		}
		
		this.b2.addEventListener("click", fl_MouseClickHandler_3.bind(this));
		
		function fl_MouseClickHandler_3() {	
			this.wrong2.play();
			var my2=createjs.Sound.createInstance("wro");
		this.my2;
		my2.play();
			
		}
		this.b3.addEventListener("click", fl_MouseClickHandler_4.bind(this));
		
		function fl_MouseClickHandler_4() {
		
			this.wrong3.play();
			var my3=createjs.Sound.createInstance("wro");
		this.my3;
		my3.play();
		
		}
		
		this.b4.addEventListener("click", fl_MouseClickHandler_5.bind(this));
		
		function fl_MouseClickHandler_5() {
		
			this.correct.play();
			var my4=createjs.Sound.createInstance("yes");
		this.my4;
		my4.play();
		
		}
		this.b8.addEventListener("click", fl_MouseClickHandler_9.bind(this));
		
		function fl_MouseClickHandler_9() {
			
			//this.wrong3.play();
			var my9=createjs.Sound.createInstance("intro");
		this.my9;
		my9.play();
			
			
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_7
	this.b8 = new lib.Symbol6();
	this.b8.name = "b8";
	this.b8.setTransform(1414.3,114.05,1.821,2.2072,0,0,0,49,40.8);
	new cjs.ButtonHelper(this.b8, 0, 1, 1);

	this.instance = new lib.Symbol1();
	this.instance.setTransform(-169.1,227,1,1,0,0,0,43,43);

	this.instance_1 = new lib.Symbol25copy();
	this.instance_1.setTransform(2123.85,587.25,1,1,0,0,0,20,16);

	this.wro_sou = new lib.Symbol22copy();
	this.wro_sou.name = "wro_sou";
	this.wro_sou.setTransform(2117.5,521.9);

	this.cor_sou = new lib.Symbol21copy();
	this.cor_sou.name = "cor_sou";
	this.cor_sou.setTransform(2098.5,476.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag5CWQgJgIgBgLQAAgNAIgMQAKgOAQAAQANAAAHAKQAGAJAAALQAAAMgHAKQgIANgOAAQgMAAgJgHgAgtBDQgJgIABgLQAAgPAZgUIAuggQAZgTgBgPQAAgSgSgQQgSgQgUAAQgKAAgSAMQgSAMgIAAQgMAAgHgJQgJgIAAgLQAAgTAjgQQAdgOASAAQAqAAAjAfQAhAfAAApQAAAogoAeIggAXQgUANgJAMQgJAKgLAAQgLAAgJgIg");
	this.shape.setTransform(1323.2,119.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhNBmQgGgIAAgKIAAh/IABgSIAAgTQAAgKAHgIQAGgHAMAAQAWAAAEAXQAigaApAAQAoAAAAA0IgBAMQgBAegaABQgYAAAAgaIgBgTQgrAGgTAnIAABhQAAALgHAIQgIAGgMAAQgMABgHgIg");
	this.shape_1.setTransform(1285.35,124.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhCBUQghgYAAgtQAAgwAagjQAdglAwgBQAiABAWAKQAeAPAAAeQAAAVgYASQgLAHghANIhBAdQAJALAOAFQANAFAQAAQAaAAASgLQARgJAJgBQAVAAAAAVQAAAVggAPQgcAMgfAAQgtAAgegXgAgaguQgNAMgIAYIAsgTQAZgMARgKQgOgIgVAAQgRAAgNANg");
	this.shape_2.setTransform(1263.95,124.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Ag6CUQgHAIgKAAQgLAAgHgHQgIgHAAgLIABgOIABgPIAAjcQAAgOAGgLQAIgOAPAAQAUAAAAAXIAAAIIgBAIIAABLQAOgIAOgEQANgEALAAQAuAAAdAhQAaAeAAAtQgBAtgeAgQgfAggtAAQgbAAgagKgAgWgDQgNAFgQALIAABTQAaAMAUAAQAYAAAPgRQARgRgBgZQABgZgNgRQgOgQgXAAQgJAAgOAGg");
	this.shape_3.setTransform(1241.2,119.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgRByQgHgIAAgLQAAgWgFgsQgFgqAAgXQAAgMgCgHQgXANgWAfIgEADIgBA9IAAAPIAAAOQAAALgJAFQgIAGgLAAQgRAAgGgPQgEgJAAgVIAAhIIgBgdIAAgdQAAgQAGgOQAIgTANABQALgBAJAKQAJAHAAALIgCARQAdgjAbABQAeAAANAWQAMgKAOgFQAPgGAQAAQAnAAANAmQADAIAGAtQAFAfAJBKQABALgJAHQgIAIgMAAQgWgBgEgWQgDgUgEglIgHg4QgFgjgIAAQgFAAgQAJQgQAJgHAGQAAAXAFApQAGAqAAAWQAAALgIAIQgIAGgLABQgLgBgIgGg");
	this.shape_4.setTransform(1214.2053,124.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAnBhQgZAJgaAAQgbAAgTgMQgWgNgEgaQgHgwAAgmQAAgZAFggQAEgWAXAAQALAAAIAHQAIAHAAALQAAAIgDASQgCATAAAJQAAAcABATQACAVAEANIAKADIAIABQAVAAAagGIAAgiIgBggQAAgoAEgdQADgXAYAAQALAAAIAHQAJAHgBALIgEBFIAAAmIABAoIAAAMIABAMQAAALgIAHQgIAHgLAAQgRAAgHgOg");
	this.shape_5.setTransform(1187.7053,124.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAoBaIgGgoQgDgWAAgTIABgQIABgSIAAgGIABgKQAAgQgIAAQgRAAgPAWQgQAVgJAgIgCASIgBARIgBARIgCARQAAAMgHAHQgIAIgMAAQgLAAgIgIQgIgHAAgMIgBgQIgBgRQAAgTADgiQADghAAgTIgBgSIgBgSQAAgLAIgHQAIgIALAAQAaAAACAfIAAACQAdgcAeAAQAlAAAOAeQAKAVAAApIAAAOIgBAMQAAAPAFAYQAEAYAAAPQAAALgIAHQgIAIgLAAQgYAAgDgYg");
	this.shape_6.setTransform(1167.225,124.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgRCIQgIgHAAgKIAAgWIABgVQgBgXgDhNIgkgDQgZgDAAgWQAAgLAIgIQAGgIANAAIAgADIgBgVIAAgTQAAgLAIgHQAIgIALAAQAcAAAAAxIAAAQQAMgCAIAAQAWAAAIADQAQAGAAASQAAALgIAIQgHAHgMAAIgKAAIgJgBQgJAAgKACQADBOABAYIAAAKIAAALQAAAtgcAAQgKAAgIgHg");
	this.shape_7.setTransform(1129.8,120.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("Ag9BWQgegaAAgqQAAgmAbgqQAggvAoAAQAUAAAbALQAhAOAAARQAAAJgGAIQgHAIgLAAQgJAAgLgJQgMgKgYAAQgOABgSAdQgQAcAAAVQAAAUAOAMQAOALAXAAQANAAATgKQASgKAGAAQAKAAAIAHQAHAIAAAKQAAAPghAQQgeANgSAAQgqAAgegYg");
	this.shape_8.setTransform(1109.675,124.25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AhCBUQghgYAAgtQAAgwAagjQAdglAwgBQAiABAXAKQAdAPAAAeQAAAVgYASQgLAHghANIhBAdQAKALANAFQANAFAQAAQAbAAARgLQARgJAJgBQAVAAAAAVQAAAVggAPQgcAMgfAAQgtAAgegXgAgaguQgNAMgIAYIAtgTQAYgMAQgKQgNgIgVAAQgRAAgNANg");
	this.shape_9.setTransform(1088.35,124.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AhNBmQgGgIAAgKIAAh/IABgSIAAgTQAAgKAGgIQAHgHAMAAQAWAAAEAXQAhgaArAAQAnAAAAA0IgBAMQgBAegaABQgYAAAAgaIgBgTQgrAGgTAnIAABhQAAALgHAIQgIAGgMAAQgMABgHgIg");
	this.shape_10.setTransform(1068.25,124.35);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AhNBmQgGgIAAgKIAAh/IAAgSIABgTQAAgKAGgIQAHgHAMAAQAWAAAEAXQAhgaArAAQAnAAAAA0IAAAMQgCAegZABQgZAAAAgaIgBgTQgrAGgTAnIAABhQAAALgIAIQgHAGgMAAQgMABgHgIg");
	this.shape_11.setTransform(1049.05,124.35);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("Ag/BSQgdgbgBgtQgCgqAZgiQAegoA0AAQAnAAAXAfQAVAcAAAqQAAAsgZAgQgbAkgsAAQgkAAgagZgAgcggQgLASAAAYQAAAXANAMQALAKAOAAQAQABAMgMQAOgNABgYQADg+gkAAQgXAAgOAXg");
	this.shape_12.setTransform(1028.2958,124.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("Ag9BWQgegaAAgqQAAgmAbgqQAggvAoAAQAUAAAbALQAhAOAAARQAAAJgGAIQgHAIgLAAQgJAAgLgJQgMgKgYAAQgOABgSAdQgQAcAAAVQAAAUAOAMQAOALAXAAQANAAATgKQASgKAGAAQAKAAAIAHQAHAIAAAKQAAAPghAQQgeANgSAAQgqAAgegYg");
	this.shape_13.setTransform(1007.375,124.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AhCBUQghgYAAgtQAAgwAagjQAdglAwgBQAiABAXAKQAdAPAAAeQAAAVgYASQgLAHghANIhBAdQAJALAOAFQANAFARAAQAZAAATgLQAQgJAKgBQAUAAAAAVQAAAVghAPQgbAMgeAAQgvAAgdgXgAgaguQgNAMgHAYIArgTQAZgMAQgKQgNgIgVAAQgRAAgNANg");
	this.shape_14.setTransform(968.7,124.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAuCPQgFgQgEgdQgDgbAAgSIAAgPIABgOIgBgRQgBgKgJAAQgWAAgRATQgJAKgPAcQAABGgHAPQgHAQgRAAQgLAAgIgHQgJgHAAgLQAAgEACgHQACgEAAgwQAAgoABhaIAAgHIACgeIgDgSIgCgSQAAgLAJgHQAIgHALgBQATABAHAUQAEAMAAAYIgCAoIgBAmQAOgPARgGQAQgHASAAQAhAAAPASQALAOACAdIADAwIADAmQADAWAEAQIABAHQAAAMgIAGQgJAIgLgBQgUAAgFgTg");
	this.shape_15.setTransform(946.65,118.95);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgRCIQgJgHAAgKIABgWIAAgVQABgXgEhNIgkgDQgZgDAAgWQAAgLAHgIQAHgIAMAAIAiADIgBgVIgBgTQAAgLAIgHQAIgIALAAQAcAAAAAxIAAAQQAMgCAIAAQAWAAAIADQAQAGAAASQAAALgIAIQgHAHgMAAIgKAAIgJgBQgJAAgKACQAEBOgBAYIAAAKIABALQAAAtgdAAQgJAAgIgHg");
	this.shape_16.setTransform(925.35,120.975);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAtCRQgKgRgTgZIgegoIgZASQgDAbAAAZQAAAMgHAHQgIAIgMAAQgbgBAAghIACgtQACgfABgQIAAg/IABhBIgBgUIAAgUQAAgLAHgHQAIgHAMgBQALABAHAHQAJAHAAALIAAAUIABAVIgBA3IgBA2QAagUA2g2QAIgJALAAQAMAAAIAIQAIAIAAALQAAAJgIAIQgXAZggAcIAqA0QAdAoAAANQAAALgJAHQgIAIgLAAQgQgBgIgPg");
	this.shape_17.setTransform(888.45,118.75);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("Ag9BWQgegaAAgqQAAgmAbgqQAggvAoAAQAUAAAbALQAhAOAAARQAAAJgGAIQgHAIgLAAQgJAAgLgJQgMgKgYAAQgOABgSAdQgQAcAAAVQAAAUAOAMQAOALAXAAQANAAATgKQASgKAGAAQAKAAAIAHQAHAIAAAKQAAAPghAQQgeANgSAAQgqAAgegYg");
	this.shape_18.setTransform(866.275,124.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgYCOQgIgIAAgLIAAgkIgBgjQAAgSACgaQACgZAAgRQAAgMAHgHQAIgHAMAAQAKAAAJAHQAHAHAAAMQAAARgCAZQgCAaAAASIABAjIAAAkQAAALgHAIQgIAHgLAAQgLAAgIgHgAgRhjQgJgIAAgMQAAgNAJgIQAJgIALAAQANAAAJAIQAJAIAAANQAAAMgJAIQgJAIgNAAQgLAAgJgIg");
	this.shape_19.setTransform(851.25,119.675);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgSCZQgIgHAAgLIAAkOQAAgLAIgHQAIgHAKAAQAMAAAHAHQAIAHAAALIAAEDQAAAlgbAAQgLAAgHgIg");
	this.shape_20.setTransform(839.5,118.75);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("Ag9BWQgegaAAgqQAAgmAbgqQAggvAoAAQAUAAAbALQAhAOAAARQAAAJgGAIQgHAIgLAAQgJAAgLgJQgMgKgYAAQgOABgSAdQgQAcAAAVQAAAUAOAMQAOALAXAAQANAAATgKQASgKAGAAQAKAAAIAHQAHAIAAAKQAAAPghAQQgeANgSAAQgqAAgegYg");
	this.shape_21.setTransform(823.575,124.25);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AA2CTQgNAIgPADQgOACgOAAQgsAAgdgcQgdgcAAgsQAAg1AegfQAdghAvAAQAPAAALAEQAMADAIAGQADhDADgZQAEgXAWAAQALAAAHAHQAHAIAAALQAAAcgEA5QgFA4AAAcQAABGAFAYIAAAFQAAALgHAHQgIAHgLAAQgOAAgHgNgAgoAJQgOAQAAAiQAAAVAQAPQAPAPAVAAQAOAAAIgDQAFgDANgKIAGgGIAAhIQgGgMgLgFQgKgGgOAAQgcAAgPAQg");
	this.shape_22.setTransform(784.325,118.875);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AAoBaIgGgoQgDgWAAgTIABgQIABgSIAAgGIABgKQAAgQgIAAQgRAAgPAWQgQAVgJAgIgCASIgBARIgBARIgCARQAAAMgHAHQgIAIgMAAQgLAAgIgIQgIgHAAgMIgBgQIgBgRQAAgTADgiQADghAAgTIgBgSIgBgSQAAgLAIgHQAIgIALAAQAaAAACAfIAAACQAdgcAeAAQAlAAAOAeQAKAVAAApIAAAOIgBAMQAAAPAFAYQAEAYAAAPQAAALgIAHQgIAIgLAAQgYAAgDgYg");
	this.shape_23.setTransform(762.625,124.025);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AAvBaQgSAJgNAEQgOAEgJAAQgvAAgXgZQgYgZAAgyQAAguAjgiQAjghAvAAQATAAAYAKQAeANAAAQQAAAIgFAFQgCAHgBAMIgBAbQAAAkAFARIAJAUQAIAQAAADQAAAKgIAHQgIAGgKAAQgJAAgUgRgAgbgnQgUAVAAAaQAAAbAKANQAJANATAAQALAAALgEQALgEAJgIQgGgtAAgXIABgPIADgSIgHgCIgFgBQgaAAgUAUg");
	this.shape_24.setTransform(740.975,124.325);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("Ag2BmQgegKAAgWQAAgTAXAAQAKgBAQAGQARAGAKAAQAmAAAAgQQAAgKgbgMQgogSgKgHQgcgTAAgcQAAgnApgOQAZgIAwAAQAUAAAKAFQAMAHAAASQAAAkgSgBQgUAAgEgQQgHgBgJAAQguAAAAANQAAAIAbANQAnARAOAKQAcAUAAAZQAAAigfASQgZANgkAAQgaAAgVgIg");
	this.shape_25.setTransform(702.4,124.15);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AhMBmQgHgIAAgKIAAh/IABgSIAAgTQAAgKAHgIQAGgHAMAAQAWAAAEAXQAigaApAAQAoAAAAA0IgBAMQgBAegaABQgYAAAAgaIgBgTQgrAGgTAnIAABhQAAALgHAIQgIAGgMAAQgMABgGgIg");
	this.shape_26.setTransform(683.7,124.35);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AhCBUQghgYAAgtQAAgwAagjQAdglAwgBQAiABAWAKQAeAPAAAeQAAAVgYASQgLAHghANIhBAdQAKALANAFQANAFAQAAQAaAAASgLQARgJAJgBQAVAAAAAVQAAAVggAPQgcAMgfAAQgtAAgegXgAgaguQgNAMgIAYIAtgTQAYgMARgKQgOgIgVAAQgRAAgNANg");
	this.shape_27.setTransform(662.3,124.25);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AAHA+QgFgSgHgwIgFALIgdBLQgDAIgGAFQgIANgRABQgJAAgKgRQgLgRgGgbQgGgYgNhQQgDgSAAgKQAAgKAIgHQAIgIAMAAQAVAAAFAVIAEAbIADAbIAIAxQAOgmATg7QAIgaAVAAQAWAAAHAdQAFATAFAgIAKA2IAeh1QAFgRAUAAQALAAAJAHQAIAHAAALIgBAGQgVBMgUA+QgGARgNATQgKANgPAAQgZgBgOgvg");
	this.shape_28.setTransform(637.925,124.625);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("Ag/BSQgdgbgBgtQgCgqAZgiQAegoA0AAQAnAAAXAfQAVAcAAAqQAAAsgZAgQgbAkgsAAQgkAAgagZgAgcggQgLASAAAYQAAAXANAMQALAKAOAAQAQABAMgMQAOgNABgYQADg+gkAAQgXAAgOAXg");
	this.shape_29.setTransform(613.2958,124.45);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgSCZQgIgHAAgLIAAkOQAAgLAJgHQAHgHALAAQALAAAIAHQAHAHAAALIAAEDQAAAlgbAAQgKAAgIgIg");
	this.shape_30.setTransform(597.35,118.75);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AglClQgIgIAAgKIABgFQAEgcAAgZIAAhgIgNACIgLABQgMgBgIgGQgHgIAAgLQAAgTATgFQAIgDAaAAIACgXQAGgrASgVQAWgbAvAAQAjAAAAAaQAAAZghAAQgXAAgLARQgIAMgDAbIgBAFIAmgDQAkAAAAAZQAAAagmgBIgmACIAAA0IABA0QAAAkgFAVQgEAVgVAAQgLAAgIgHg");
	this.shape_31.setTransform(581.625,119.95);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AAoBaIgGgoQgDgWAAgTIABgQIABgSIAAgGIABgKQAAgQgIAAQgRAAgPAWQgQAVgJAgIgCASIgBARIgBARIgCARQAAAMgHAHQgIAIgMAAQgLAAgIgIQgIgHAAgMIgBgQIgBgRQAAgTADgiQADghAAgTIgBgSIgBgSQAAgLAIgHQAIgIALAAQAaAAACAfIAAACQAdgcAeAAQAlAAAOAeQAKAVAAApIAAAOIgBAMQAAAPAFAYQAEAYAAAPQAAALgIAHQgIAIgLAAQgYAAgDgYg");
	this.shape_32.setTransform(561.475,124.025);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AAnBhQgZAJgaAAQgbAAgTgMQgWgNgEgaQgHgwAAgmQAAgZAFggQAEgWAXAAQALAAAIAHQAIAHAAALQAAAIgDASQgCATAAAJQAAAcABATQACAVAEANIAKADIAIABQAVAAAagGIAAgiIgBggQAAgoAEgdQADgXAYAAQALAAAIAHQAJAHgBALIgEBFIAAAmIABAoIAAAMIABAMQAAALgIAHQgIAHgLAAQgRAAgHgOg");
	this.shape_33.setTransform(540.2053,124.425);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AhpB/QgYgSAAgYQAAgNAIgIQAHgIANAAQASAAAIASQALAYAnAAQAhAAAfgOQAhgPAAgSQAAgZgUgIQgPgGgqgBQgiAAgbgLQgkgQAAgfQABgmAogfQAoggAvAAQAUAAAcAJQAjAKAAAPQAAAKgHAIQgIAIgNAAQgJAAgSgDQgSgEgKAAQgZAAgVAMQgYAMAAAOQAAAIAHAEQAHAFAPACIAwADQAsADAZAVQAcAXAAApQAAAyg6AaQgrAUg4AAQgxAAgdgWg");
	this.shape_34.setTransform(516.125,120.275);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AhCBUQghgYAAgtQAAgwAagjQAdglAwgBQAiABAXAKQAdAPAAAeQAAAVgYASQgLAHghANIhBAdQAJALAOAFQANAFAQAAQAbAAARgLQARgJAKgBQAUAAAAAVQAAAVggAPQgcAMgfAAQgtAAgegXgAgaguQgNAMgHAYIAsgTQAZgMAPgKQgNgIgVAAQgRAAgNANg");
	this.shape_35.setTransform(473.45,124.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AAtCPQgEgQgEgdQgEgbABgSIAAgPIABgOIgBgRQgBgKgJAAQgWAAgRATQgIAKgQAcQAABGgHAPQgHAQgRAAQgLAAgIgHQgJgHAAgLIACgLQABgEACgwQgCgoAChaIABgHIABgeIgCgSIgDgSQAAgLAJgHQAIgHALgBQATABAHAUQAEAMAAAYIgBAoIgCAmQAOgPARgGQAQgHASAAQAhAAAPASQALAOACAdIADAwIADAmQADAWAEAQIABAHQAAAMgJAGQgIAIgLgBQgTAAgHgTg");
	this.shape_36.setTransform(451.4,118.95);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgRCIQgJgHAAgKIABgWIABgVQAAgXgEhNIglgDQgYgDAAgWQAAgLAHgIQAHgIAMAAIAhADIAAgVIgBgTQAAgLAIgHQAIgIALAAQAcAAAAAxIAAAQQAMgCAHAAQAXAAAIADQAQAGAAASQAAALgIAIQgIAHgLAAIgKAAIgKgBQgIAAgKACQAEBOAAAYIAAAKIAAALQAAAtgdAAQgJAAgIgHg");
	this.shape_37.setTransform(430.1,120.975);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgRCIQgJgHAAgKIABgWIAAgVQABgXgEhNIgkgDQgZgDAAgWQAAgLAHgIQAIgIALAAIAiADIgBgVIgBgTQAAgLAIgHQAIgIALAAQAcAAAAAxIAAAQQAMgCAIAAQAWAAAIADQAQAGAAASQAAALgIAIQgHAHgMAAIgKAAIgJgBQgJAAgKACQAEBOgBAYIAAAKIABALQAAAtgdAAQgJAAgIgHg");
	this.shape_38.setTransform(393.9,120.975);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AAoBaIgGgoQgDgWAAgTIABgQIABgSIAAgGIABgKQAAgQgIAAQgRAAgPAWQgQAVgJAgIgCASIgBARIgBARIgCARQAAAMgHAHQgIAIgMAAQgLAAgIgIQgIgHAAgMIgBgQIgBgRQAAgTADgiQADghAAgTIgBgSIgBgSQAAgLAIgHQAIgIALAAQAaAAACAfIAAACQAdgcAeAAQAlAAAOAeQAKAVAAApIAAAOIgBAMQAAAPAFAYQAEAYAAAPQAAALgIAHQgIAIgLAAQgYAAgDgYg");
	this.shape_39.setTransform(374.175,124.025);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AAnBhQgZAJgaAAQgbAAgTgMQgWgNgEgaQgHgwAAgmQAAgZAFggQAEgWAXAAQALAAAIAHQAIAHAAALQAAAIgDASQgCATAAAJQAAAcABATQACAVAEANIAKADIAIABQAVAAAagGIAAgiIgBggQAAgoAEgdQADgXAYAAQALAAAIAHQAJAHgBALIgEBFIAAAmIABAoIAAAMIABAMQAAALgIAHQgIAHgLAAQgRAAgHgOg");
	this.shape_40.setTransform(352.9053,124.425);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("Ag/BSQgdgbgBgtQgCgqAZgiQAegoA0AAQAnAAAXAfQAVAcAAAqQAAAsgZAgQgbAkgsAAQgkAAgagZgAgcggQgLASAAAYQAAAXANAMQALAKAOAAQAQABAMgMQAOgNABgYQADg+gkAAQgXAAgOAXg");
	this.shape_41.setTransform(331.8958,124.45);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AhXB3QgcgegBgqQAAhBA5hEQAxg6AyAAIAPABIAMACQAJgJANAAQATAAAFAXQADARABAVQAAAKgHAIQgHALgOAAQgRAAgJgTQgEgJgEgBQgCgCgNAAQgZAAgfAnQgtA0AAAvQAAAVAOAPQAPAPATABQASAAAVgLQAGgDAXgQQAPgKAJAAQALAAAJAIQAHAJAAAKQAAAMgKAIQg2Atg3AAQgsAAgeggg");
	this.shape_42.setTransform(309.55,119.35);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_43.setTransform(1108.55,1058.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("Ag6BHIAAiOIAxAAQAQAAAIACQANADAIAHQAMAKAFAPQAGAPAAATQAAAQgEAMQgEAMgGAJQgFAIgIAFQgHAFgKACQgKACgMAAgAgnA2IAeAAQANABAIgDQAIgDAFgFQAHgGAEgMQAEgLAAgPQAAgWgIgNQgHgMgLgEQgHgDgQAAIgeAAg");
	this.shape_44.setTransform(1098.775,1052.15);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgIBHIAAh9IgwAAIAAgRIBxAAIAAARIgvAAIAAB9g");
	this.shape_45.setTransform(1085.225,1052.15);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgsBHIAAiOIATAAIAAB9IBGAAIAAARg");
	this.shape_46.setTransform(1075.425,1052.15);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_47.setTransform(1061.2,1058.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgIBHIAAh9IgwAAIAAgRIBxAAIAAARIgvAAIAAB9g");
	this.shape_48.setTransform(1054.525,1052.15);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgJBHIg3iOIAUAAIAlBoIAHAXIAIgXIAmhoIATAAIg3COg");
	this.shape_49.setTransform(1041.7,1052.15);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("Ag2BHIAAiOIA2AAIAVABQALACAHAFQAHAFAEAJQAEAJABALQAAASgMALQgMAOgeAAIgjAAIAAA5gAgigCIAkAAQARgBAIgGQAIgIAAgLQAAgKgEgGQgFgHgHgCQgFgBgNAAIgjAAg");
	this.shape_50.setTransform(1028.7,1052.15);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgbBFQgNgHgIgKQgHgMgBgOIASgCQABAKAFAIQAFAGAJAFQAKAEALAAQALAAAJgEQAIgCAEgGQADgGAAgGQABgHgEgFQgEgFgJgEQgGgCgSgEQgUgGgIgCQgLgGgEgIQgFgIgBgKQABgLAFgJQAHgJAMgFQALgFAPAAQAPAAAMAFQAMAFAGAKQAHAKABANIgSABQgCgOgIgHQgJgGgQAAQgQgBgJAHQgHAGgBAJQABAIAGAFQAFAFAWAFQAXAFAJAEQAMAFAGAJQAGAIAAAMQAAALgGALQgHAJgMAHQgMAFgQAAQgSAAgNgFg");
	this.shape_51.setTransform(1009.4,1052.15);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AAyBHIAAh2IgqB2IgQAAIgph5IAAB5IgSAAIAAiOIAcAAIAiBkIAGAWIAHgXIAjhjIAZAAIAACOg");
	this.shape_52.setTransform(994.475,1052.15);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("Ag0BHIAAiOIBmAAIAAARIhTAAIAAAsIBOAAIAAAQIhOAAIAAAwIBWAAIAAARg");
	this.shape_53.setTransform(979.725,1052.15);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgIBHIAAh9IgwAAIAAgRIBxAAIAAARIgvAAIAAB9g");
	this.shape_54.setTransform(966.725,1052.15);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgbBFQgOgHgHgKQgIgMAAgOIASgCQABAKAFAIQAEAGAKAFQAKAEALAAQALAAAIgEQAIgCAFgGQADgGAAgGQAAgHgDgFQgEgFgJgEQgGgCgTgEQgUgGgHgCQgLgGgEgIQgGgIAAgKQAAgLAHgJQAGgJAMgFQAMgFAOAAQAPAAAMAFQAMAFAHAKQAGAKABANIgSABQgCgOgIgHQgJgGgQAAQgQgBgJAHQgIAGAAAJQAAAIAHAFQAFAFAWAFQAXAFAIAEQANAFAGAJQAGAIAAAMQAAALgHALQgGAJgNAHQgMAFgPAAQgTAAgMgFg");
	this.shape_55.setTransform(953.85,1052.15);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgJBHIAAg8Ig4hSIAXAAIAdAsIANAXIAQgYIAcgrIAWAAIg6BSIAAA8g");
	this.shape_56.setTransform(940.525,1052.15);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgcBFQgMgHgIgKQgHgMgBgOIASgCQABAKAFAIQAEAGAKAFQAKAEALAAQALAAAJgEQAHgCAEgGQAEgGAAgGQAAgHgDgFQgEgFgJgEQgGgCgSgEQgVgGgHgCQgLgGgFgIQgEgIgBgKQABgLAFgJQAHgJALgFQAMgFAPAAQAPAAAMAFQAMAFAGAKQAHAKAAANIgSABQgBgOgIgHQgJgGgQAAQgQgBgJAHQgHAGgBAJQABAIAFAFQAGAFAWAFQAXAFAJAEQAMAFAGAJQAGAIAAAMQAAALgGALQgHAJgMAHQgNAFgPAAQgSAAgOgFg");
	this.shape_57.setTransform(927.15,1052.15);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AggBCQgMgHgGgNQgGgNAAgXIAAhSIATAAIAABSQAAASAEAJQAEAJAIAFQAJAFALAAQAUAAAKgKQAIgJABgbIAAhSIATAAIAABSQAAAVgGANQgEANgNAIQgNAIgUAAQgUAAgNgHg");
	this.shape_58.setTransform(907.75,1052.275);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("Ag6BHIAAiOIAxAAQAQAAAIACQANADAIAHQAMAKAFAPQAGAPAAATQAAAQgEAMQgEAMgGAJQgFAIgIAFQgHAFgKACQgKACgMAAgAgnA2IAeAAQANABAIgDQAIgDAFgFQAHgGAEgMQAEgLAAgPQAAgWgIgNQgHgMgLgEQgHgDgQAAIgeAAg");
	this.shape_59.setTransform(893.575,1052.15);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("Ag0BHIAAiOIBmAAIAAARIhTAAIAAAsIBOAAIAAAQIhOAAIAAAwIBWAAIAAARg");
	this.shape_60.setTransform(879.675,1052.15);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("Ag0BHIAAiOIBmAAIAAARIhTAAIAAAsIBOAAIAAAQIhOAAIAAAwIBWAAIAAARg");
	this.shape_61.setTransform(860.775,1052.15);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgeBBQgSgJgIgRQgJgRAAgWQAAgUAJgRQAIgTARgIQAQgJAVAAQAPAAANAFQAMAFAHAJQAHAJAEAPIgRAEQgDgLgFgGQgFgHgJgDQgIgEgLAAQgMAAgKAEQgJAEgGAGQgGAHgDAIQgGANAAAPQAAASAHAOQAHAMAMAHQANAGANAAQAMAAAMgFQAMgEAGgGIAAgaIgqAAIAAgQIA8AAIAAA0QgOAKgOAHQgPAFgQAAQgUAAgRgJg");
	this.shape_62.setTransform(845.975,1052.15);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("Ag6BHIAAiOIAxAAQAQAAAIACQANADAIAHQAMAKAFAPQAGAPAAATQAAAQgEAMQgEAMgGAJQgFAIgIAFQgHAFgKACQgKACgMAAgAgnA2IAeAAQANABAIgDQAIgDAFgFQAHgGAEgMQAEgLAAgPQAAgWgIgNQgHgMgLgEQgHgDgQAAIgeAAg");
	this.shape_63.setTransform(831.325,1052.15);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("Ag0BHIAAiOIBmAAIAAARIhTAAIAAAsIBOAAIAAAQIhOAAIAAAwIBWAAIAAARg");
	this.shape_64.setTransform(817.425,1052.15);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgIBHIAAh9IgwAAIAAgRIBxAAIAAARIgvAAIAAB9g");
	this.shape_65.setTransform(799.275,1052.15);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AAlBHIAAhDIhJAAIAABDIgTAAIAAiOIATAAIAAA7IBJAAIAAg7IATAAIAACOg");
	this.shape_66.setTransform(785.925,1052.15);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgeBBQgSgJgIgRQgJgRAAgWQAAgUAJgRQAIgTARgIQAQgJAVAAQAPAAANAFQAMAFAHAJQAHAJAEAPIgRAEQgDgLgFgGQgFgHgJgDQgIgEgLAAQgMAAgKAEQgJAEgGAGQgGAHgDAIQgGANAAAPQAAASAHAOQAHAMAMAHQANAGANAAQAMAAAMgFQAMgEAGgGIAAgaIgqAAIAAgQIA8AAIAAA0QgOAKgOAHQgPAFgQAAQgUAAgRgJg");
	this.shape_67.setTransform(770.825,1052.15);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgJBHIAAiOIASAAIAACOg");
	this.shape_68.setTransform(760.4,1052.15);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AAnBHIgTgdIgNgUQgGgHgDgDQgEgDgFgBIgKAAIgWAAIAAA/IgTAAIAAiOIA+AAQAUABAKADQAKAEAFAKQAGAJAAAMQAAAQgJAKQgKAJgVAEQAIADAEAEQAIAHAHAMIAZAmgAgrgIIApAAQAMAAAHgCQAHgDAEgFQAEgHAAgHQAAgKgHgHQgIgGgQAAIgsAAg");
	this.shape_69.setTransform(751.025,1052.15);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("Ag1BHIAAiOIA1AAQAQAAAKAFQAKAEAGAJQAFAJAAAKQAAAJgFAIQgFAIgKAFQANAEAHAIQAHAKAAAMQAAAKgEAIQgEAJgHAFQgGAFgJACQgKACgOAAgAgiA2IAiAAIANAAQAHgBAEgDQAFgCADgGQACgFAAgHQAAgIgEgGQgEgGgHgCQgHgCgNAAIghAAgAgigKIAfAAQALgBAGgBQAHgDAEgEQADgGAAgHQAAgHgDgGQgDgFgHgCQgGgCgPAAIgcAAg");
	this.shape_70.setTransform(736.675,1052.15);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgjBAQgSgKgKgSQgJgRAAgTQgBgSAKgSQAKgSASgJQARgKASAAQATAAARAKQASAJAKASQAJASAAASQAAATgJARQgKASgSAKQgRAKgTAAQgSAAgRgKgAgdg1QgPAIgIAPQgJAPAAAPQAAAQAIAOQAJAPAPAIQAOAIAPAAQAQAAAOgIQAPgIAJgPQAIgOAAgQQAAgPgJgPQgIgPgPgIQgOgIgQAAQgPAAgOAIgAgbAfQgKgLAAgUQAAgMAEgJQAFgKAKgFQAJgFAKAAQANAAAJAHQAIAGADALIgLACQgDgHgGgEQgGgEgIAAQgKAAgHAIQgIAIAAAOQAAAPAHAIQAHAIALAAQAIAAAHgFQAGgGADgIIAMADQgEANgIAHQgKAHgOAAQgQAAgLgLg");
	this.shape_71.setTransform(716.9,1052.125);

	this.instance_2 = new lib.BRIGHTEDGEEDUSYSTEMPVTLTDlogopng1();
	this.instance_2.setTransform(1408.5,55.9,0.256,0.256);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.cor_sou},{t:this.wro_sou},{t:this.instance_1},{t:this.instance},{t:this.b8}]}).wait(1));

	// Layer_4
	this.wrong3 = new lib.Symbol20copy();
	this.wrong3.name = "wrong3";
	this.wrong3.setTransform(1324.5,388.8,0.98,0.98,0,0,0,52.1,48.3);

	this.wrong2 = new lib.Symbol20copy();
	this.wrong2.name = "wrong2";
	this.wrong2.setTransform(1164.15,392.15,0.98,0.98,0,0,0,52.1,48.3);

	this.wrong1 = new lib.Symbol20copy();
	this.wrong1.name = "wrong1";
	this.wrong1.setTransform(923.55,407.8,0.98,0.98,0,0,0,52.1,48.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.wrong1},{t:this.wrong2},{t:this.wrong3}]}).wait(1));

	// Layer_2
	this.correct = new lib.Symbol19();
	this.correct.name = "correct";
	this.correct.setTransform(1555.55,364,0.9999,0.9999);

	this.timeline.addTween(cjs.Tween.get(this.correct).wait(1));

	// Background
	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#373535").ss(1,1,1).p("ECH5BMcMkPxAAAMAAAiY3MEPxAAAg");
	this.shape_72.setTransform(959.975,539.975);

	this.timeline.addTween(cjs.Tween.get(this.shape_72).wait(1));

	// Layer_1
	this.b4 = new lib.Symbol113();
	this.b4.name = "b4";
	this.b4.setTransform(1529.9,302.6,1,1,0,0,0,29.9,57.9);
	new cjs.ButtonHelper(this.b4, 0, 1, 2, false, new lib.Symbol113(), 3);

	this.b3 = new lib.Symbol112();
	this.b3.name = "b3";
	this.b3.setTransform(1319.85,301.6,1,1,0,0,0,29.9,57.9);
	new cjs.ButtonHelper(this.b3, 0, 1, 2, false, new lib.Symbol112(), 3);

	this.b2 = new lib.Symbol111();
	this.b2.name = "b2";
	this.b2.setTransform(1083.5,301.6,1,1,0,0,0,29.9,57.9);
	new cjs.ButtonHelper(this.b2, 0, 1, 2, false, new lib.Symbol111(), 3);

	this.b1 = new lib.Symbol110();
	this.b1.name = "b1";
	this.b1.setTransform(877.9,299.8,1,1,0,0,0,32.6,71.7);
	new cjs.ButtonHelper(this.b1, 0, 1, 2, false, new lib.Symbol110(), 3);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#373535").s().p("AgKATIgIgIQgDgFAAgGQAAgFADgFQADgFAFgDIAKgDIALADIAIAIIADAKIgDALIgIAIIgLADgAgIgPQgEACgCAFIgDAIIADAJIAGAHIAIACIAJgCIAHgHIACgJIgCgIIgHgHIgJgCgAAGAMIgGgJIgDgBIgCAAIAAAKIgEAAIAAgXIAOABIACADIABADIgBAEIgFABIACACIAGAJgAgFAAIAFAAIAEgBIABgDIgBgCIgBgBIgEAAIgEAAg");
	this.shape_73.setTransform(283.4,79.125);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#A53792").s().p("Ag2BIIADgOIAOACIAJgBIABgRIgChbIgUADIgCgLIAcgFIATgKIAEAEIgEAYIACgCIAKgLQAHgFAGgBIAMgBQAGABAEADIAIAJIAEAMIAAAMIgFAOIgJAKIgLAFIgNAAIgHgCIgGgGIgDgIIAAgIQABgDADgCIAFgFIAHgEIAGAAIAGACIAFADIADAFIAAAGIgEAHIgJACIgFAAIACADIACAAIAHAAIAGgDIAEgGIADgIIgBgGIgDgFIgFgFIgGgCIgHAAIgHACQgDABgEADIgHAIIgFAJIgCAEIgIBKIAbgIIAEgBIABAOIgDABIgdAHIgQACgAgYg3IABABIADBgIgCAVIgBACIABAAIAIhTIADgGIACgDIgDgBIAEggIABgCgAAQgEIgCgDIgCgFIAAgFIABgFIACgEIABAAIABgDIgIAGIgBACIAAAGIACAGIADADIADACgAAXgYIgCACIgCADIgBADIABAEIAEgIIAAgCIAAgCgAAegTIABgCIAAgDIgBgBgAAxggIgBgGIgDgJIAAgBIgGgGQgDgDgEgBIgJABQgFABgGAEIgJAKIgBABIgBABIACgCIAIgGIAJgCIAJAAIAIAEIAHAFIAEAIIABABg");
	this.shape_74.setTransform(178.625,109.075);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#A53792").s().p("AgxA+IAXABIACg1IgDg/IgUAEIgBgFQAcgDARgLIgHApQAJgTAKgIQANgIAKACQAJABAGAKQAGAKgCAMQgCAPgLAHQgJAHgMgCQgHgBgDgGQgEgGABgIQAAgDAHgFQAHgEAEABIAIAEQAEADAAAFQgBAGgKAAIADgHQABgFgDgBQgEAAgDADQgCADgBAFQgBAEADADIAFAFQAJACAHgGQAHgHABgJQACgHgGgHQgFgGgJgCIgQACQgHADgHALIgIANIgIBPIAfgIIAAAHIgdAHIgiABg");
	this.shape_75.setTransform(178.7,109.025);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#EE3338").s().p("AhLAlIADgCQBWghANgJIABgBQAYgOgHgBIgBAAIgcgIIhBgGIgGAAIABgYIAMADIAjgBQAhACAbAJIAAABIASANQAPAQgTAPQgJAHgWAMQgqAXhAAUIgHADgAAvghQAUAEgOAOIgUAPQgMAJhXAjIAAAEQA7gUAngWQAUgKAIgHIABAAQAKgIgJgKIgMgJQgbgKgjgBIggABIAAABIAKAAQAqAAAnAOg");
	this.shape_76.setTransform(165.3138,110.775);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#EE3338").s().p("AhHApQBYgiANgKIAQgLQANgLgNgCIgdgJIhDgGIABgMIAHABIAfgBQAjACAbAJIAQALQAMAOgPALIgeATQgqAXhAAUg");
	this.shape_77.setTransform(165.304,110.725);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#EE3338").s().p("AgOAqIADgPIACgBQA1ggAHgPIAAAAIAAgDIgKgCIgBABIgNABQgTAEgUAKIgBAAIgyAcIgDAAIgJgCQgHgEAKgLIAAAAIAlgZQArgYAqACIAWAIQARAOgcAYIgBAAIhCAvgAgVgUQgUAKgSANQAcgQAPgHQAWgKATgEIAOgCQgdABgfAPgAA8gQIgMAOIAHgFQAUgSgQgHQAHAFgGALg");
	this.shape_78.setTransform(161.5691,101.6384);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#EE3338").s().p("AgHAeIAcgTQAegUAEgKIACgHQgCgHgPABIgOACQgTAEgVAKQgLADgpAZIgEgBQgDgCAEgFIAkgYQAqgYAoADIASAGQAOAKgXAVIhDAug");
	this.shape_79.setTransform(161.5731,101.7086);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#EE3338").s().p("AghCHIgGgKIAAAAQgEgQARhPIAShLQARhHARgPQAJgHAEAHIACADIgBADIgNAjIAAAAQgHAQgUBeIgSBcIgBABQgGAWgGAAIgCAAgAAAgqIgQBHQgQBMACAQIAWhqQAThbAHgRIAKgfQgJAKgTBIg");
	this.shape_80.setTransform(160.3951,107.2767);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#EE3338").s().p("AgfCBIgDgEQgDgPAQhOIAShKQAQhBANgQQAHgIADAFIgNAkQgHAQgTBfIgUBcQgEAQgEAAIAAAAg");
	this.shape_81.setTransform(160.3269,107.1046);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#373535").s().p("AhKAlIACgBQBXghAMgKIABgBQAagOgJgBIAAAAIgdgJIhBgGIgFAAIABgWIALACQAPgBATABQAiABAbAJIAAAAIASAOQAOAQgSAOQgJAHgWAMQgqAXhAAVIgGACgAAvggQAUADgOAPIgVAOQgNAKhVAhIgBAGQA8gUAogXIAcgRQALgIgJgLIgNgJQgbgKgiAAIgfAAIgDAAIAAACIAKAAQArAAAnAPg");
	this.shape_82.setTransform(165.5765,111.05);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#373535").s().p("AhGApQBXgiANgKIAQgLQANgLgNgCQgLgFgSgDIhDgHIABgMIAHABIAfAAQAjAAAbALIAQAKQAMAOgPALQgJAHgVALQgqAYg/AUg");
	this.shape_83.setTransform(165.579,111);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#373535").s().p("AgNAqIADgPIACgBQA1gfAHgQIAAgDQgCgDgJAAIAAAAIgOACQgTAEgUAKIgBAAQgKADgpAZIgCABIgIgDQgHgEAJgKIAAAAIAlgYQArgZAqADIAAAAIAWAIQAQAMgbAZIgBAAIhCAugAgcgRQgXANgOAMQAngZALgCQAVgLAUgEIAPgBQATgCACAJQABAGgEAFQgEAIgOALIAOgJQASgQgKgIQgEgEgKgBIgIAAQgiAAgjATg");
	this.shape_84.setTransform(161.833,101.9134);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#373535").s().p("AgGAeIAbgTQAegUAEgKIACgHQgCgHgOACIgPABQgTAEgVAKQgLAEgpAZIgEgCQgDgCAEgFIAkgYQAqgYAoADIASAGQAOALgXAUIhDAug");
	this.shape_85.setTransform(161.8266,101.9632);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#373535").s().p("AghCGIgGgJIAAAAQgDgQARhOIARhLQAShIAQgOQAJgHAEAHIACACIgCADIgIAVIgEAOIAAAAQgHAQgUBeIgTBcIAAABQgFAWgHAAIgCgBgAAAgqIgQBIQgRBNACAPIAEgMIATheQAThcAIgRQAGgWAEgKQgKAIgTBLg");
	this.shape_86.setTransform(160.6275,107.5396);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#373535").s().p("AgfCBIgDgEQgDgPARhOIARhKQAQhCANgPQAHgIADAFIgNAkQgHAQgTBeIgUBcQgEARgEAAIAAAAg");
	this.shape_87.setTransform(160.5775,107.4046);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#FFFFFF").ss(0.6,0,0,2.6).p("ABiBnQgpAqg5AAQg4AAgpgqQgogrAAg8QAAg7AogrQApgqA4AAQA5AAApAqQAoArAAA7QAAA8goArg");
	this.shape_88.setTransform(161.325,107.5);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFF215").s().p("AhhBnQgogrAAg8QAAg7AogrQApgqA4AAQA5AAApAqQAoArAAA7QAAA8goArQgpAqg5AAQg4AAgpgqg");
	this.shape_89.setTransform(161.325,107.5);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#EE3338").s().p("AgZgcIAzAgIgeAZg");
	this.shape_90.setTransform(152.825,93.925);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#F26C36").s().p("AgzAAIBlgPIACAfg");
	this.shape_91.setTransform(142.5,108.25);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#EE3338").s().p("AgFgbIAbAWIgrAhg");
	this.shape_92.setTransform(153.65,121.55);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#EE3338").s().p("AAPgVIAPAlIg7AGg");
	this.shape_93.setTransform(146.5,113.15);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#EE3338").s().p("AgegQIA9gDIgMAng");
	this.shape_94.setTransform(145.8,103.15);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#373535").s().p("AgZgcIAzAhIgdAYg");
	this.shape_95.setTransform(152.8,93.75);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#F26C36").s().p("Ag1gpIBrA3IgXAcg");
	this.shape_96.setTransform(146.2,96.375);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#F26C36").s().p("AAkgoIARAfIhpAzg");
	this.shape_97.setTransform(146.975,119.4);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#EE3338").s().p("AgIALQgEgFABgGQgBgFAEgFQADgEAFAAQAFAAADAEQAEAFABAFQgBAGgEAFQgDAEgFAAQgFAAgDgEg");
	this.shape_98.setTransform(246.3,101.925);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#373535").s().p("AAQAIQgBgGgHgBIgGABIgRgCIgCgFIAAgBQAAgBAAAAQAAAAABAAQAAAAAAAAQAAAAAAABIAAABQAAAGASgBIAHAAQAHABACAHg");
	this.shape_99.setTransform(280.475,89.8375);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#373535").s().p("AgHAHIgEgHIgBgFIACAAIAAAFQABADADADIABABIAEAAIABAAIADgEIAIgLIACABQgIAMgFADIgFABg");
	this.shape_100.setTransform(279.075,95.475);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#373535").s().p("AgGACIgEgEIACgBIADAEIAQACIAAABg");
	this.shape_101.setTransform(276.725,95.05);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#373535").s().p("AgOgIIABgBQANARAPABIAAABQgRgCgMgQg");
	this.shape_102.setTransform(279.65,93.8);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#373535").s().p("AgDAGIADgDIACgEIgBgFIACgBIABAHIgDAEIgDAEg");
	this.shape_103.setTransform(277.925,93.1);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#9D4035").s().p("AAEAHIgFABIgEgGIAEABIgBgKIAEACIAEAMIgCABg");
	this.shape_104.setTransform(273.15,86.225);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#9D4035").s().p("AgIACIABgFIAEAGIAAgEQABgGAEgBIgBACIAAAGIAHgHQABALgHAEIgCABQgCAAgGgHg");
	this.shape_105.setTransform(275.5063,85.3721);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#9D4035").s().p("AgIAGIABgDQAAgGAHgCQAOgCgJAEQgGACgBADIABAEIgCABg");
	this.shape_106.setTransform(277.863,85.3886);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#373535").s().p("AAAAEIABgHIAAABIgBAGg");
	this.shape_107.setTransform(277.875,87.175);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#373535").s().p("AAAADIAAgFIABAAIAAAFg");
	this.shape_108.setTransform(277.65,87.175);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#373535").s().p("AAAAAIgGAAIgBgBIAHgBQAGAAADAEIgCABQgCgDgFAAg");
	this.shape_109.setTransform(279.65,86.775);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#373535").s().p("AgHADIAFgFQAFgEAFAHIgBABQgEgGgEAEIgFAEg");
	this.shape_110.setTransform(277.525,86.4554);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#201F1F").s().p("AAAAAIgCAAIgBgBIADAAQADAAABACIgCABg");
	this.shape_111.setTransform(274.2,87.075);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#373535").s().p("AgGAFIAMgKIABABIgLAKg");
	this.shape_112.setTransform(273.75,88.825);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#373535").s().p("AAFAGIgKgGIgFgEQgFAAABAEIACADIgBABIgDgFQgBgGAHACIABAAIAEAEQAFAEAFABIABAAIADABIAIgBIAAABIgIABg");
	this.shape_113.setTransform(272.2368,87.76);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#373535").s().p("AgHAFIAHgHQAHgGABAIIgBAAQgCgGgFAGIgGAGg");
	this.shape_114.setTransform(280.3,85.73);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#373535").s().p("AgBACQAFgCgGgBIAAgCIAEADQADACgFACg");
	this.shape_115.setTransform(281.5113,90.85);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#CB7246").s().p("AgDAAQAAgFADAAQAEAAAAAFQABAGgFAAQgDAAAAgGg");
	this.shape_116.setTransform(275.0775,97.575);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#CB7246").s().p("AgDAAQAAgFADAAQAEAAAAAFIgBAEIgDACIAAAAQgCAAgBgGg");
	this.shape_117.setTransform(274.725,95.8019);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#9D4035").s().p("AAAAMIgCgDQgEgEAAgHIADgHQADgFAGAIIABAIQAAAKgGAAIgBAAg");
	this.shape_118.setTransform(274.3,92.9262);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#EE3338").s().p("AgDAKQgCgCAAgIIABgJIAKAJIgHAKg");
	this.shape_119.setTransform(279.025,94.275);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#373535").s().p("AAAADIAAgFIABAAIgBAFg");
	this.shape_120.setTransform(279.85,87.4);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#373535").s().p("AAAAEIAAgHIAAAAIAAAHg");
	this.shape_121.setTransform(279.5,87.3);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#373535").s().p("AAAgDIAAAAIABAHIAAABg");
	this.shape_122.setTransform(279.2,87.35);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#373535").s().p("AgBADIACgFIABAAIgCAFg");
	this.shape_123.setTransform(278.125,87.325);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#373535").s().p("AAAgBIAAAAIABADIAAAAg");
	this.shape_124.setTransform(277.375,87.35);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AgBAAQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIABABIgBACQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAg");
	this.shape_125.setTransform(279.6,89.225);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_126.setTransform(277.825,89.325);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AgDAAQABgFADABQADABAAAEQgCAFgCgBQgDgBAAgEg");
	this.shape_127.setTransform(277.5746,89.1764);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#373535").s().p("AAAAFQgDgBAAgEQABgFADABQADABAAAEQgBAEgDAAIAAAAg");
	this.shape_128.setTransform(277.5746,89.1764);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#373535").s().p("AgEAJQgCgDgBgFIACgHIABgBIAAABQgCADAAAEIADAHQADAEAAgBIAGgDIABgIIgCgHIgFgDIgBAAIABgBQACAAADAEIADAHIgCAIQgCAEgEAAg");
	this.shape_129.setTransform(277.7,88.65);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AgEAIQgCgDAAgFQgBgDACgEQACgDADAAQACgBADADIACAIIgBAIIgGAEg");
	this.shape_130.setTransform(277.72,88.6964);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AgCAAQABgEACAAQADABgBAEIgDADQgDgBABgDg");
	this.shape_131.setTransform(279.3744,89.0826);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#373535").s().p("AgCAAQABgEACABQADABgBADIgDAEQgDgBABgEg");
	this.shape_132.setTransform(279.3744,89.0472);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#373535").s().p("AgEAHQgCgCgBgEIABgCIAAACIACAFIAEADIAFgDIACgGIgCgFQgCgDgDgBIgEAEIgBABIAAgBIAFgEQADAAACADIADAGIgCAGQgCAEgEAAg");
	this.shape_133.setTransform(279.575,88.65);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AgEAHIgDgHIACgGQACgDADAAIAFADIADAGIgCAGQgCADgEAAIAAABQAAAAgBgBQAAAAgBAAQAAAAgBgBQAAAAgBgBg");
	this.shape_134.setTransform(279.575,88.6536);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#CB7246").s().p("AgDABQAAgDADgBQAEAAAAADQAAAEgEAAQgDAAAAgDg");
	this.shape_135.setTransform(273.775,90.75);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#CB7246").s().p("AgBACIgBgCQAAAAAAAAQAAgBABAAQAAgBABAAQAAAAAAAAIACAAIABACIgCADg");
	this.shape_136.setTransform(275.4,101.425);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#9D4035").s().p("AgDAGIgDgGIACgEQACgDACAAIAFACIACAFIgCAGIgFACQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAgBg");
	this.shape_137.setTransform(275.325,99.675);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#9D4035").s().p("AgHAMIgBgXIAIgBIADAGIAGALIgDAIg");
	this.shape_138.setTransform(276.175,113.525);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#CB7246").s().p("AgCAFIgCgEQAAgBAAAAQAAAAAAgBQABAAAAgBQAAAAABgBIACgCQAFAAAAAFQAAAGgFAAg");
	this.shape_139.setTransform(276.2,111.0481);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#9D4035").s().p("AgHAIIgBgOIAFgFQAFgEAFAJIACAJQAAAJgJABIAAAAQgFAAgCgFg");
	this.shape_140.setTransform(276.0763,108.5581);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#9D4035").s().p("AgCAGIgCgGQAAgGAEgBQAFABAAAGIgBAFIgDACQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_141.setTransform(275.525,106);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#CB7246").s().p("AgDALIgDgWIAFABQAEACAEAHIAAAHQgBAGgGAAIgDgBg");
	this.shape_142.setTransform(275.475,103.3563);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#373535").s().p("AgSC1IgChdIgLh0IgFgaIgEgLQgEgNADgMIgDABIgFAAQgKAAgGgGIgFgGIgDgKQgCgKAFgCIAMACIALAEIAOgBIgDgJIgQgjQgLgCACgHIAFgHIAAgBIABAAQANABgFAMQAaAoAFABQAEABADgJIADglQgEgJAEgEIAFgBIAAAAQAMAHgLAIIAAApIAEABIABAAIAZgOQAIgFADAHIACAIIgFAMIgFAFIAAASIAEAIIANABQAMgEAHAUIAGAUIAAABQgEAJgPAEIgYgCIgGAJIgGAHIgBABIgBAAIgBABQgEABgEgFIAFA2QABATAJAxIAAAAQAEAgAMAyIAAACIgBAAIg4AEIgCAAQgBAAAAAAQAAAAAAgBQAAAAABgBQAAgBABgBgAgohUQAAAJADAJIAEAMIAEAZIAMB1QACBbgBADIAAAAIA1gDQgLgsgFgmQgJgxgBgSIgEg6IABgDIACACQADAHADgCIABAAIAAAAIABgBIAGgGIAGgJIAAgBIABAAIAKACIAOgBQAOgCADgJIgFgUQgHgRgJADIgBABIAAgBIgNgBIgBAAQgFgEAAgFIgBgVIABAAIAFgDQAEgFAAgHIgBgGQgCgGgGAEIgbAPIgEgCIgBAAIgBgtIABAAIACgEQADgDgFgEQgIACAFAJIABABIgDAlQgDANgIgCIgggrIgBAAIABgBIABgFQgBgFgGAAQgJAKANABIABAAIAQAlIAAABIADAKIABABIgGACIAAgBIgLAAQgFAAgHgEIgKgCQgEACADAIIADAJIADAFQAGAFAJAAIAFAAIAGgBg");
	this.shape_143.setTransform(277.0464,98.775);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFF215").s().p("AgRC2IgCheIgLh0IgEgaIgEgLQgDgJAAgKIABgIIgJACQgJAAgHgGIgDgGIgDgJQgCgJAEgCIAKACIAMAFIAMgBIAAABIADgBIgDgLIgQglQgKgBACgFIAEgHQAHAAABAGIgBAGIAOAUQAOAVAEABQAGABADgKIACgmQgEgIAEgEIAEgBQAGAEgCAFIgEAFIABArIAEABIAagPQAIgEACAGIACAHQgBAIgEAGIgFADIAAATQAAAFAEADIAOABQALgEAHAUIAFAUQgDAJgOACIgPABIgKgCIgMAQIgBABIgBAAIAAAAQgEADgDgGIgCgBIAFA4QABAUAIAxQAEAfAMAzIg4AEg");
	this.shape_144.setTransform(277.0417,98.75);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#9D4035").s().p("AALBSIgHABIgCABQABgCAFgBIACgCIgGABIgCABQAAgEADgBIAEgBIgGABIgDABQAAgDAFgBIAFAAIgFgCIgFgBIAIgEIgHABIAGgEIgHABIAHgEIgEgBIgDAAIAJgFIgIABIAIgFIgIABIAHgFIgGABIgCgBQAAAAAAgBQABAAAAAAQABgBAAAAQABgBABAAIAEgCIgIAAIAGgEIgGAAIAHgEIgHAAIAIgGIgJACIAHgHIgGAAIAFgDIgGgBIAHgDIgHgBIAHgGIgEAAIgEABIAHgGIgHAAIAGgDIgGAAIAHgFIgFAAIgDABIAGgFIgDgBIgEAAIAHgEIgDAAIgFABIAHgGIgDgBIgDABIAGgFIgEgBIgDABIAIgIIgIgBIAHgHIgJACIAHgGIgHgBIAGgHIgHAAIAEgDIgGgBIAGgDIgFAAIAEgDIgFgBIAGgEIgIABIAFgEIgFgBIAFgDIgGgCIAFgCIgFgBIAFgBIgDgEIAJgBIgBABQgCAEABAGIACAGQAFAGACARIAJBfIgBAjIgJABg");
	this.shape_145.setTransform(273.475,98.025);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#9D4035").s().p("AgxBYQgIgJAAgNQgBgNAFgPQAFgQAJgPQAFgIAHgHIAPgNQAPgLAKAAQAFgBAKAGIABgFQAOhLAJAQQAHANAAA+QAAA8gHAhQgIAmgMgqIgEgUQgRATgPALQgQAMgKAAIgDAAQgJAAgHgHgAAEgMQgEAFgDAIIgFAUIgCASQABAQAJgBQAFAAAHgGIAQgPIgBgHIgKAGIgCgCIADgSQgBgKgFgKIgGgFIgBAAg");
	this.shape_146.setTransform(271.6432,107.4396);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f().s("#EE3338").ss(0.2,0,0,2.6).p("AgiAFIAYgHQAbgFARAJ");
	this.shape_147.setTransform(198.4947,85.4774);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#373535").s().p("AgBAYIgHgCIAPgyIACA5QgDgDgHgCg");
	this.shape_148.setTransform(256.375,86.925);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#EE3338").s().p("AhDAsIAYgpQAhgqAogKIAZgEQAXADgRAeIgCADIgWAUQgQAOgSAIIg8AdgAgPgGQgQAPgNAWIAqgVQAagKAYgcIABgBQAEgIgJAAIgKACIgBAAQgaAGgWAXg");
	this.shape_149.setTransform(252.699,97.775);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#EE3338").s().p("AAQBCQgQgKgIgbIgCgEQgDgLAAgFIgCgJIgCgHIgRgaQgLgOgEgNIAKgJIAAAAIAPAJIAYATQAbAaALARQARAcgGAcIgBADQgDAGgIADIgLAAQgFgBgFgDgAgNgcIABABIAIAOIAEASIAAAEIAEAPQAHAWAMAHIAGADIAEgBIACgBQAEgWgOgWQgJgOgYgaIgNgKg");
	this.shape_150.setTransform(251.6922,109.175);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#EE3338").s().p("AgNAUIgEgBIgEgHIgEgDIAEAAIgCgIIAJAJQADADACgGIAEgHIACgCIALgBQAGACAFgGQAEgDAAgJIADACIgCALIgFAGIgIABQgGgBgDADIgCAEIgGAKQgCADgDAAIgCAAg");
	this.shape_151.setTransform(243.675,104.8111);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#EE3338").s().p("AgCAUIgFgCQgHgEgEgJQAAgIgEgFIgEgHIAEAAIAFAEIgBgIIACgBIADAEIAAAHQABAJAGACIADADIAIAEIAKACQAKACACAFIgEADg");
	this.shape_152.setTransform(243.975,100.4);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#EE3338").s().p("AgEABIgPAOIAGgUQATgPAIAJQAHAHgBATQgIgXgQAJg");
	this.shape_153.setTransform(244.9132,102.8563);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#EE3338").s().p("AgLAHIAAgCQALAAAGgFIAEgGIACAAIgFAHQgGAGgKAAIgCAAg");
	this.shape_154.setTransform(246.425,99.8268);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#EE3338").s().p("AgLAGIAAgBQALAAAGgFIAEgGIACAAIgFAHQgFAGgKAAIgDgBg");
	this.shape_155.setTransform(247.125,96.6067);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#EE3338").s().p("AgLAHIAAgCQALAAAGgFIAEgGIACABIgFAGQgGAGgKAAIgCAAg");
	this.shape_156.setTransform(247.775,93.9268);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#EE3338").s().p("AgLAGIAAgBQALAAAGgFIAEgGIACABIgFAGQgGAGgJAAIgDgBg");
	this.shape_157.setTransform(243.925,110.4567);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#EE3338").s().p("AgLAHIAAgCQALAAAGgFIAEgGIACABIgFAGQgGAGgKAAIgCAAg");
	this.shape_158.setTransform(244.7,107.1768);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#EE3338").s().p("AgLAHIAAgCQALABAGgGIAEgGIACABIgFAFQgGAHgKAAIgCAAg");
	this.shape_159.setTransform(245.475,103.6767);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#EE3338").s().p("AgYAKQgFgFANgFIAPgEIAPACIAAACQAAAFgPABIAAgEIADgBIAHgBIgJAAIgLACQgMADADACIAPABIAYgGIAIgCIADgDIgagDIgVAFQgMACgCADIgDgDQADgCAMgEIAWgFQAWgDAJAHIAAABIABAEIgGAEIgJAEIgZAFg");
	this.shape_160.setTransform(240.7,114.9421);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#EE3338").s().p("AgWAIIgBAAIAAgFIADABIAPACQANAAANgHQAAgEgMAAIgCAAQAKABgQAIIAAAAIgPAAIgBgEQAAgFAJgCIAPgCQANAAACAFIAAAEIgBABQgPAJgOAAQgIAAgIgCgAgEgEIgIAEIABABIALgBIABAAIgCgBIAAgDg");
	this.shape_161.setTransform(247.125,90.939);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#EE3338").s().p("Ag+B5QA6hMANhXIAFg1IgCgXIAPAEIAKgBQASgDAEgGIAEACIgWBjQgJAwgZBbIgBACIgDgBQgHgIgdAHIgaAJgAALgdQgOBOgzBFQArgPAOAIQAahdAIgqIAAgCIABgGIAThVIgTAHIgLAAIgKgCQAEAlgKAug");
	this.shape_162.setTransform(243.4,103);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#EEEAA4").s().p("AAMgpQAEgcAAgaIgBgUIAXACQASgDAFgGIgWBjQgJAwgZBaIglgBIgcAJQA6hMAOhYg");
	this.shape_163.setTransform(243.375,102.975);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#EE3338").s().p("AgXAMQgLgCgBgEIAAgBQAAgFALgEQAIgEAQgCIAYgBQALABABAGQAAAEgLAFIgYAGIgCABgAAAgGQgOADgJADIgIAFIAIACIAWAAIABgBIAXgFIAIgFIgIgCg");
	this.shape_164.setTransform(240.5739,114.975);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#EEEAA4").s().p("AggAFQgBgEAJgDIAYgGIAXgBQAKABAAAEQABADgKAEIgXAGIgXABQgKgBAAgEg");
	this.shape_165.setTransform(240.5782,114.975);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#EE3338").s().p("AgPALQgIgCgBgFQgBgEAIgEIARgFIABAAQAIgCAIACQAIABAAAFIAAABQABAEgIAEQgHADgKACgAgPAAQgGABABACIAFADIAQAAIAPgFQAFgBAAgCIgFgDIgQAAQgJACgGADg");
	this.shape_166.setTransform(247.125,90.8625);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#EEEAA4").s().p("AgPAIIgHgEQgBgEAHgCQAGgDAKgCQAJgBAGABQAIABAAAEIgGAGIgQAEg");
	this.shape_167.setTransform(247.15,90.8625);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f().s("#EE3338").ss(0.5,0,0,2.6).p("AgCADIABABIACADIABgDQgDgDAAgCg");
	this.shape_168.setTransform(244.3945,104.2141);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#EEEAA4").s().p("AgBACIgBgCIABgDQABACADACIgCAEg");
	this.shape_169.setTransform(244.35,104.45);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#3F4096").s().p("AACgBIADADIgGAAIgDABQADgHADADg");
	this.shape_170.setTransform(198.375,82.2591);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#EE3338").s().p("AAEAXQgRgHgDgDIADgLQACgLgEgNIANAHQANALAHATIgBAFQgCADgFAAIgGAAg");
	this.shape_171.setTransform(203.5,87.9417);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#00A85A").s().p("AABALIgGgBQACgKgGgIIgGgHQAPABAKAPIAGAPg");
	this.shape_172.setTransform(200.275,84.05);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#EE3338").s().p("AgLAFQgBgJAIgJIAFAAIAIAJQAFAJgDAHIgTABg");
	this.shape_173.setTransform(198.5974,83.8);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#EE3338").s().p("AgOARQAEgVANgIIADgBIgFADQgLAIgEATIAZgIQgFgJAJgQIgCAAIACAAQgGALABAHIACAHIAAAAIgaAIg");
	this.shape_174.setTransform(196.55,84.175);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#3F4096").s().p("AADgMQAHgEAFAAQgGALAAAIIADAHIgaAHQAEgUANgJg");
	this.shape_175.setTransform(196.55,84.15);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#FFFFFF").s().p("AgLABIgCgGIATADIAIgFQAAAIgGAEIgHACIgBABQgGAAgFgHg");
	this.shape_176.setTransform(198.7518,89.5018);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#373535").s().p("AgBABIACgBIABgBIAAAAIgBABIgBABIgBABg");
	this.shape_177.setTransform(197.3,88.925);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#373535").s().p("AgDACIAAgCIABgBIAAAAIgBADIAHgCIAAAAIABAAIAAAAIgIACg");
	this.shape_178.setTransform(198.6,88.55);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_179.setTransform(200.025,87.8);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_180.setTransform(197.325,87.9);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#373535").s().p("AgCAAQAAgDACAAQADAAAAADIgDAEQAAAAgBAAQAAgBAAAAQgBgBAAAAQAAgBAAgBg");
	this.shape_181.setTransform(200.025,87.775);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#373535").s().p("AgDAAQAAAAABgBQAAAAAAgBQABAAAAAAQABAAAAAAQABAAABAAQAAAAABAAQAAABAAAAQAAABAAAAIgDAEQAAAAgBgBQAAAAgBAAQAAgBAAAAQgBgBAAgBg");
	this.shape_182.setTransform(197.3,87.9);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#373535").s().p("AgGADIACgDIADgBQAEgCAEADIAAABIgFgBQgEgBgEAEg");
	this.shape_183.setTransform(199.95,87.5942);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#373535").s().p("AAFABQgEgDgHAFIAFgDQAFgEADAFIAAACIgCgCg");
	this.shape_184.setTransform(197.2286,87.598);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#373535").s().p("AABABQgBAAAAgBQAAAAAAAAQAAAAgBAAQgBABgBAAIADgBQACgBACACg");
	this.shape_185.setTransform(200.125,86.7886);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#373535").s().p("AgDABQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAABAAIACAAIAEAAIgGABg");
	this.shape_186.setTransform(197.0417,87);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#373535").s().p("AgiANQgEgMAEgOIAXgHQAagFATAKIACAMQACAOgHALIAAgVIgEABIgDACQAFgNgHADIgBgEQgHAIgFgHIgCACIgMABIAAgBIgKACIgCgDQgCgCgDAFIgEAGIAAgCIgFADIABADIgBASQgCgEgBgGg");
	this.shape_187.setTransform(198.5007,87.2388);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#373535").s().p("AgBAZIgGgCIgIgCIgGgBQgEAAgDgFIgCgFIgCgIIgBgWIAFgDIAogCIALABIAHAEIABAAIADAGIAAAOIgCAIQgBAJgLAEIgFABIgCABIgKADgAgcgXIgFAEIACAVIABAIIADAFIAGAFIAGAAIASAFIARgFQAKgEABgIIADgWIgEgGIgHgDg");
	this.shape_188.setTransform(198.475,88.375);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#FCD4C3").s().p("AgPAVIgGgBIgGgFIgDgFIgCgIIgBgVIAFgEIAogCIALACIAHADIAEAGIgBAOIgBAIQgCAJgKADIgFABIgCABIgKAEg");
	this.shape_189.setTransform(198.475,88.375);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#EB5C38").s().p("AgDBmIgLgKIgHgOQgCgJAAgKIAFheIgXAIIAAgQIACgBIAWgGIgDgxIAcgGIgDAuIAhgLIAEARIgmAJIgNBnIABAPIAEALIAFAGIAIACIAFgBIAFgGIACgJIABgMIAAgFIgBgBIAAABIgCAKIgDAEIgEABIgGgBIgFgDIgCgFQgCgDAAgEIACgIIADgGIAGgFIAHgCIAIACIAIAFIAFAHIADAJIgCAPIgGAPIgJALQgFAEgGAAgAAZA0IADAGIABAHIgBANIgDALIAFgOIACgOIgBgFIgEgGIgFgDgAgLBUIgDgIIgCgRIAPhsIABAAIACgBIgDABIACgwIgOAEIACApIAAAIIgYAGIAAACIAYgIIgGBnIACARIAEAIgAAHAxIgDAFIgBAFIABAEIADAEIgCgGIABgGIACgFIADgEgAAPAzIgCACIgBAEIAAAEIAAABIAAAAIACgEIABgFIAFAEIABABIgEgHIgBAAgAAKg1IACAAQADgCAFgBIAOgDIAAgCg");
	this.shape_190.setTransform(226.825,105.225);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#EB5C38").s().p("AgLBaQgJgLAAgUIAGhjIgXAIIAAgIIAXgIIgCgwIAVgFIgDAvIAVgIIANgEIACAKIglAJIgGAyQgHArAAAMQAAASAGALQAGAJAKAAQAIAAAEgJQAEgJAAgOIgDgLQgDgGgEAAQgDAAgCAEIgCAKQAAAEADAAQAEAAABgHIACACIgCAIIgFADQgEAAgEgDQgEgEAAgFQAAgHAFgFQAFgGAFAAQAIAAAGAGQAHAHAAAGQAAAPgHANQgIAOgJAAQgOAAgJgMg");
	this.shape_191.setTransform(226.775,105.275);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#00A85A").s().p("Ag+BJIgEgEIAAAAIgEgGIAAgHQABgDACgCIAEgDIAFgCIAFgBIAFACIADADIACADIADgMIACgXIABhQIgBAAIgDgBIgFAAIgDgBIACgLIApAFIAEAAIgCAMIgMgBIgFAvIABAAIAMACIAegCIACgjQABgHADgFIAHgJIAJgFIAKgBIAIADIAFAFIAEAIIAAAIIgCAFIgFAEIgFACIgGABIgEgCIgEgDIgDgEIAAgBIgCAIIgFBYIADAAIALgDIACAMIgmAEIgEABIABgLIAAgDIANAAIgBgxIglABIgIAAIgIAxIgEAKIgFAJIgIAGIgIABIAAABgAg4BAIABABIADAAQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAgBgBgAg/A4IgBABIAAAEIACADIAAgHIAAgCgAAng/IgGAHIgCAJIgDAmIABAAIAAAfIAFhAIADgLIAEgKIADgDgAgfhBIAABLIACgOIABgCIgBgBIABgDIAGg1IAAgBIgJgBgAAyg/IgEAEIgBACIABgBIADgCIAEAAIAFABIgBgDIgCgBIgCgBg");
	this.shape_192.setTransform(213.725,108.725);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#00A85A").s().p("Ag4BIQgEAAgEgFQgEgFABgFQABgEAFgCIAIgDQAEABACADIABAFIgCAEIgDABIgEgFIABAAIACACIACgDIAAgDIgDgCQAAAAgBAAQAAAAgBAAQAAABAAAAQgBAAAAABIgDAFIABAHQAAABAAABQABAAAAABQABAAAAAAQABABAAAAQAHABAEgHQAFgIACgOIADhqIgDAAIgIgCIAAgEIAnAEIgBAFIgMgBIgGA2IAIACIASAAIAYgCIACgmQACgMAIgHQAHgGAKABQAGABAEAGQAFAGgBAHIgFAHIgJADQgEgBgDgDIgCgFIADgFIAFgCIADACIABACIgCADIgDgEQgBAAAAAAQAAAAAAABQgBAAAAABQAAAAAAABIABAFIADACIAEgDIADgIIgBgIIgGgFQgGgBgEAIQgFAJgCALIgGBcIAPgCIABAFIgiADIAAgGIAOAAIgCg4IgaADIgYgCIgJA0IgJASQgEAGgGAAIgDAAg");
	this.shape_193.setTransform(213.723,108.7484);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#00A85A").s().p("AgIAWIgHgFIgFgHIgBgIIABgIIAGgIIAGgGIAHgCQAJAAAGAEQAFAFACAJIABABIgFABIgFgHIgIgCIgGABIgGAEQgDACgBACIgBAEIABAGIADAFIAFADIAEABIAFgCIACgGIgBgGIgCAIIgFACIgCgBIgCgCIgDgDIAAgCIABgFIADgCIADgCIAEgBIAEABIAGACIADAEIACAFIgCAHIgEAEIgHAEIgFABgAgGgRIgGAFIgFAHQgBADAAAEQAAAEABACIAFAGIAFAEIABAAIgFgDIgEgGIgCgHIACgFIAFgGIAHgEIAHgBIAJACIADADIgEgGQgFgDgIgBgAAIAAIADAJIgDAIIACgBIAEgEIABgFIgBgDIgCgEIgHgBIADABgAgEAFIABADIABABIABABIACgCIABgBIgCAAIgDgBIgBgDgAAAABIgBABIAAABIAAABIABABIAEgCIABgBIgDgCIgCAAg");
	this.shape_194.setTransform(260.9,98.9);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#00A85A").s().p("AgNAPQgGgFAAgIQAAgJAGgGQAGgHAHgBQAQABAEAQIgBAAQgGgIgJAAQgHAAgGAEQgGAFAAAFQAAAIAFAEQAGAFAEgBQAJABAAgKQAAgKgHAAIgDABIgBADQAAADADAAIAEgBQgBAGgFABIgDgDIgCgEQAAgEADgCQADgCADAAQAFAAAEADQAFABAAAGQAAAHgGADQgFAEgGABQgIAAgFgHg");
	this.shape_195.setTransform(260.875,98.9);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#00A85A").s().p("AgaA4IARgBQAAg2gGg1IgLAAIgDAAIAAgMIAVABIAKgCIASgFIAAAOIgMADIgGBrIAcgCIAAAPIgDAAIg1AEgAgJg3QAGAvAAAyIAFhkIgKABIgBAAg");
	this.shape_196.setTransform(261.125,109.225);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#00A85A").s().p("AgXA7IASgBQAAg6gHg3IgOgBIAAgFIATAAIAXgEIAAAGIgLADIgFBxIAbgCIAAAIIglABIgNACg");
	this.shape_197.setTransform(261.1,109.275);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#00B0F0").s().p("AgIAWIgGgFIgGgHIgBgIIABgIIAGgIIAGgGIAIgCQAIAAAGAEQAFAFADAJIAAABIgEAAIgBABIAAgBIgFgGIgIgCIgGABIgGAEIgEAEIgBAEIABAGIADAFIAFADIAEABIAGgCIABgGIgBgGIgCAIIgFACIgCgBIgCgCIgCgDIgBgCIACgFIACgCIADgCIAEgBIAFABIAFACIAEAEIABAFIgCAHIgEAEIgGAEIgGABgAgGgRIgGAFIgEAHIgCAHIABAGIAFAGIAGAEIAAAAIgFgDIgEgGQgCgDAAgEIACgFIAFgGIAHgEIAHgBIAJACIADADIgEgGQgFgDgHgBgAAIAAIADAJIgDAIIACgBIAEgEIABgFIgBgDIgCgEIgFgBIgBAAgAgEAFIABADIABABIABABIACgCIABgBIgCAAIgDgBIgBgDgAAAABIgBABIAAABIAAABIABABIAGgDIgEgCIgCAAg");
	this.shape_198.setTransform(188.45,98.9);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#00B0F0").s().p("AgNAPQgGgFAAgIQAAgJAGgGQAGgHAHgBQAQABAEAQIgBAAQgFgIgKAAQgHAAgGAEQgGAFAAAFQAAAIAFAEQAGAFAEgBQAJABAAgKQAAgKgHAAIgDABIgBADQAAADADAAIAEgBQgBAGgEABIgEgDIgCgEQAAgEADgCQADgCADAAQAFAAAEADQAFACAAAFQAAAHgGADIgLAFQgIAAgFgHg");
	this.shape_199.setTransform(188.425,98.9);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#00B0F0").s().p("AgaA4IARgBQAAg7gGgwIgOAAIAAgMIAVABIAYgFIAEgCIAAAOIgMADIgGBrIAcgCIAAAPIgnABIgRADgAgJg3QAGAvAAAyIAFhkIgKABIgBAAg");
	this.shape_200.setTransform(188.675,109.225);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#00B0F0").s().p("AgWA7IARgBQAAg8gHg1IgOgBIAAgFIATAAIAYgEIAAAGIgMADIgFBxIAbgCIAAAIIglABIgMACg");
	this.shape_201.setTransform(188.65,109.275);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#FFF215").s().p("AgmgjQAegBAiAJIAdAIQgDAGgTALQgJAGgWAJIg4AXg");
	this.shape_202.setTransform(164.675,110.3947);

	this.instance_3 = new lib.Symbol81("synched",0);
	this.instance_3.setTransform(159.5,107.15,0.64,0.64);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#FFF215").s().p("AgPgRIAbgHIAKAAQAKgBgHAKIgJAKIgqAeg");
	this.shape_203.setTransform(164.1441,101.3738);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#EE3338").s().p("AgsAYQAdgHAegVIAYgVIAGAaQgiAXgeACg");
	this.shape_204.setTransform(212.075,96.65);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#EE3338").s().p("AAEAGIg2AQIA0gsIAxAoIgEAFQgCgCgpgPg");
	this.shape_205.setTransform(215.8,96.425);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#EE3338").s().p("AgLgJQALAHAMgDQAHgCADgEIAHAWIgagKIggALg");
	this.shape_206.setTransform(198.2,91.35);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#EE3338").s().p("AgCAAQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAAAAAQABAAAAAAQABABAAAAQAAAAAAABQABAAAAAAIgDADg");
	this.shape_207.setTransform(198.35,98.625);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#EE3338").s().p("AgBAAQAAAAAAAAQAAgBAAAAQAAAAABAAQAAgBAAAAIACACIgCADg");
	this.shape_208.setTransform(198.4,97.3);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#EE3338").s().p("AgBAAQAAAAAAAAQAAgBAAAAQABAAAAAAQAAgBAAAAIACACIgCACg");
	this.shape_209.setTransform(198.425,96.05);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#EE3338").s().p("AgMANIACgbIAVgBQADgBgCAeIgJACIgDAAQgIAAgEgDg");
	this.shape_210.setTransform(198.5031,93.4516);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#EE3338").s().p("AgMAAIAVgJIAEAJIgVAKg");
	this.shape_211.setTransform(204.375,107.325);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#EE3338").s().p("AgNAAQAFgDAAgFIAWAIIgEAIg");
	this.shape_212.setTransform(193.475,106.7);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#3F4096").s().p("AgPAOQgCgCgBgGIgDgGIARgNIABgBIADAFQAHAJANACIACAEQAAAEgGAAIgJACIgGAAIgGgEIAAAHg");
	this.shape_213.setTransform(205.625,108.275);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#3F4096").s().p("AAGAOIAAgIIgFAEIgCABIgFAAIgJgCQgGAAAAgEIACgEQANgCAHgKIADgEIAAABIASAMIgDAHQgBAGgCABQgCAEgDAAIgFgCg");
	this.shape_214.setTransform(192.3731,107.5092);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#EE3338").s().p("AALANIgLgCIgGgDIgFgEIgHgEIgDgEQgFAAASgVIAIAGIABAAIAIABQAJAAAFAGIgEAGIgCAOIAAAJIgDAJg");
	this.shape_215.setTransform(194.3194,92.725);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#EE3338").s().p("AgGAnQgCgBgCgJQgEgMACgLIAGgRQgEgSAEgFIADgEQADgBAEAIIABAJQAEgDAAAKIgGAIQAFALgEAPIAJAHIABABIgBABIgSALgAgFgUIABAJIAAABIgGARQgCAKAEALIAAABIADAHIAPgJIgHgGIgBgBIABgUIgDgHIAAgBIABAAIAEgFIABgDQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAgBABIgCACIgBgCQADgHgDgEIAAAAIgEgGIgCACIAAAAQgDAEACAJg");
	this.shape_216.setTransform(192.6295,88.1637);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#FCD4C3").s().p("AgJAdQgEgMACgKIAGgSIgBgJQgCgKADgEIACgCQADgBADAHQADAFgEAIIADgDQADgCAAAHQgCAGgFACIADAHQACAIgDAMIAEACIAFAFIgSALg");
	this.shape_217.setTransform(192.6045,88.1938);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#EE3338").s().p("AgeAtQgCgGABgWIACgTIAAgBIABAAIAEgIQgCgMADgLIADgIIACABQABADAOAAIAJgBIAJgBIAEgEIACgBIACAFIAAABQgCAKAFAOIAFAMIAAAAQACAQgCAMIgBABQgFABACAFIACAFIABABIgBABIgEAFIAAAAIg3ABgAgXgLIgEAKIgCATQgBATACAGIA0gBIADgEIgDgHQAAgGAFgCQACgNgCgMIgGgNQgEgOACgKIgBgCIgFADIgJACIgJABQgMAAgEgEQgFAKABASg");
	this.shape_218.setTransform(198.5094,95.75);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#FFF215").s().p("AgdASIACgTIAEgJQgBgNADgKIADgIQAAAHAUgCQATgCgBgFIACADQgCAMAFAOIAFALQADAQgDAMQgFABABAGIADAGIgEAGIg1ABQgDgGACgVg");
	this.shape_219.setTransform(198.4918,95.7);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#EE3338").s().p("AgEAWIgIgRQgDgIACgHIAAgHIgDgFQAiALgCAIIgBAGQgDAJgJAGQgEAFgCAAIgBgBg");
	this.shape_220.setTransform(202.1531,93.5417);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#EE3338").s().p("AgPAiQgDgDABgDQgFgCAAgFIABgFQAFgHAHAGIANgSQgHgGAAgIIgBgEIAAAAIAAAAIAIgMIAAgBIADACIAOAPIACAFIAAANIgEAIQgNAOgLADIgDAFIgCADIgEABgAgTASQgEAGAIACIACABIgBABIgBABIABADIABAAIABAAIADgCIACgFIAAgBIABAAIAGgDIARgOIAEgHIAAgMIgCgEIgOgOIgHAKIACAIIAHAJIAAABIgPATIgBACIgBgBQgCgDgDAAQgCAAgCADg");
	this.shape_221.setTransform(203.325,96.775);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#FCD4C3").s().p("AgQAdIABgCQgGgBAAgFIABgEQADgFAEACIAEADIAPgUQgGgEgBgFIgCgJIAIgLIAPAQIACAEIAAANIgEAHQgIAJgJAFIgHADIgDAHIgGABg");
	this.shape_222.setTransform(203.325,96.775);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#00B0F0").s().p("AgOAOIAFgbIAYgCIAAAfIgUAAg");
	this.shape_223.setTransform(198.475,93.525);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#3F4096").s().p("AAlAUQgJgTgcgLIgNAKQgQANgJAPIgbgJQACgKAEgGQACgDAHgJIASgbIA3gBIAQANQARAQABAQQAGAJAAACQAGAKgFADIgWAGg");
	this.shape_224.setTransform(198.676,103.825);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#ED2790").s().p("AgVBcIgMgGIgIgKQgDgGgBgHQAAgIAFgHIARgOIABABIAAgBIABgSIgIgEIgJgJIgFgKIgDgMQAAgJAEgKQACgJAHgHIAMgKQAGgEAIAAIAIABIAEADIABgBIABABIABAAIABAAIABABIABABIADAGIgCABIgFAEIAGAFIAIALIACAMIgDAQIgJAMIgMAKIgKADIgBARIAIgFIANgHIAJgDIAIgBIAIACIAHAGIAEAJIACAKQAAATgQAPQgHAHgLAEIgUAEgAgbA3IgBAFQAAAGACAEIAEAIIAHAFIAIACIAPgDQAIgDAGgGIAIgMIADgLIgCgHQgDgDgEAAIgHAAIgHACIgOAHIgRALIgDgDIgDgCIACgCIABgGIgBADIgCAFgAgiA0QgEAFAAAGIACAJIAHAIIAEADIgCgBQgDgEgCgGQgBgFAAgHQAAgHABgEgAAjAmQAEAFAAAHIAAAGIABgKIgBgIIgDgHIgEgEIgGgBIgGABIgIACIgdARIgBAEIALgHIAPgHIAQgDQAHAAAEAFgAgPg3IgHAHIgFALIgCAOIABAOIAFAJIAEAGIAGACIAIgDIAGgGIAEgLIACgNIgCgIIgCgHIgBgBIABAGQAAAEgDAFQgEAEgFAAQgGAAgFgFQgDgFAAgHIABgGIAEgFIAFgEIAHgBIAKACIABABIgBgBIgEgDIgGgCQgEAAgFADgAglgjQgCAGAAAKIABAKIAGAJIADADQgDgEgBgHIgCgPIACgQIAEgKQgFAHgDAHgAAMgjIABAKIgBAPIgFAKIAGgKIADgNIgCgKIgEgIgAgKggIABABIACgCIAAAAIgDgBgAgHguIgCABIgCAEIADgDIADgBIAFACIgCgCQAAAAAAAAQgBgBAAAAQgBAAgBAAQAAAAgBAAgAAHhdIAAgBIAEAHg");
	this.shape_225.setTransform(199.8,109.975);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#ED2790").s().p("AgfBGQgKgHAAgNQAAgNARgLIABACQgHAHgBAMQABAMAGAIQAHAIAKAAQASABANgNQAMgNAAgMIgDgKQgEgEgFAAIgPACQgGACgIAFIgQAKIgCgCQADgHABgMIACgVQgLgBgIgLQgGgJAAgMQAAgTALgNQALgNANAAQAHAAAGAEIgCgCIACAAIADADIABACIgDACQgGgGgHAAQgMAAgGAMQgIALAAAPQAAAQAGAKQAFAKAIgBQALABAFgMQAHgLAAgPQAAgJgFgIQgFgIgGABQgDAAgDADIgCAHQAAALAGAAIADgBIABgFIgBgDIgEACIACgEIACgCQAFAAAAAGIgDAHQgCADgEAAQgFAAgEgEQgDgEAAgFQABgEAEgFQAGgFAEAAQAJABAJAHQAHAKABALQAAAQgMAMQgKAKgLAAIgDAbIAagQQAJgDAHAAQAIAAAFAGQAEAIAAAJQAAASgOAOQgPANgVAAQgOAAgKgIg");
	this.shape_226.setTransform(199.8,111.25);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#EE3338").s().p("AgYgCIAbgXIAWAzg");
	this.shape_227.setTransform(170.15,120.725);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#EE3338").s().p("AgQgXIAhgEIgIA3g");
	this.shape_228.setTransform(161.975,124.3);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#DE3438").s().p("AgZACIAzgfIgYA7g");
	this.shape_229.setTransform(172.225,95.925);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#EE3338").s().p("AgSAbIAWg5IAPA9g");
	this.shape_230.setTransform(163.025,90.425);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#F26C36").s().p("AgQg+IAhAHIggB2g");
	this.shape_231.setTransform(157.925,127.175);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#F26C36").s().p("AgWg8IAtByIghAHg");
	this.shape_232.setTransform(157.7,87.975);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#F26C36").s().p("AgjgnIAVgPIAyBtg");
	this.shape_233.setTransform(168.25,125.575);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#F26C36").s().p("AgiArIBFhhIguBtg");
	this.shape_234.setTransform(169.55,89.75);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#373535").s().p("AgzAAIBmgPIgBAJIACAWg");
	this.shape_235.setTransform(142.8,108.425);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#373535").s().p("Ag2BIIADgOIADABIAUABIABgSIgChbIgUAEIgCgMIADAAIAYgFIAUgKIAEAEIgEAZIACgCIAKgMIANgHIAMAAQAFABAFADIAHAJIAFAMIAAANIgFANIgJALIgLAEIgOAAIgHgCIgFgGIgDgHIAAgJIADgFIAGgFIAHgDIAGgBIAGACIAFADIADAFIAAAHIgFAGIgIACIgFAAIACADIACAAIAHAAIAGgDIAEgGIADgIIgBgGIgDgFIgFgFIgGgCIgIAAIgGACQgEABgDADIgHAJIgFAIIgCAEIgIBKIAMgDIAOgFIAEgCIABAMIAAADIggAIIgPACgAgWg4IgCABIABACIADBfIgCAVIgBACIABAAIAIhSIADgHIACgDIgEgBIAGgigAAOgaIgFADIgBADQgBACAAADIADAGIADAEIADABIgCgDIgCgFIgBgFIACgFIACgEIACgCgAATgTIgBADIAAACIAAACIADgEIACgDIAAgDIAAgCIgBAAgAAegUIgBABIABAAIABgCIAAgDIgBgBgAAxggIgBgGIgDgKIgGgGQgEgDgEAAIgJAAIgKAGIgKAJIAAABIgBABIABgCIAJgGIAJgCIAJABIAIADQAEACADADIAFAJg");
	this.shape_236.setTransform(178.975,109.375);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#373535").s().p("AgxA+IAXABIgBh0IgUAEIgBgFQAbgCASgMIgHApQAIgSAMgJQALgJALACQAKACAFAKQAGAJgCANQgDAPgJAHQgJAHgNgCQgHgBgEgGQgDgHABgHQAAgEAHgEIALgDQAGABADADQAEADgBAFQgBAFgKABIADgHQABgFgEgBQgDAAgCADQgEAEAAAEIACAHIAGAFQAJACAGgHQAGgFACgKQABgIgFgGIgNgIIgQACQgIADgHAKIgIAPIgIBOIAfgIIABAHIgdAHIgiABg");
	this.shape_237.setTransform(179.0267,109.35);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f().s("#373535").ss(3,0,0,2.6).p("AAiAKQgpAXhAAUIABgOQBYghANgLIAPgLQAOgLgNgCIgdgJIhDgGIABgMIAHABIAfgBQAiACAcAKIAPALQANANgQAMQgIAHgWALg");
	this.shape_238.setTransform(165.5563,111.233);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#373535").s().p("AhGApQBXgiANgKIAQgLQANgMgNgCIgcgIIhDgGIAAgMIAHABIAfgBQAjACAbAKIAQALQAMANgPAMQgJAGgVAMQgqAXg/AUg");
	this.shape_239.setTransform(165.629,111.05);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f().s("#373535").ss(3,0,0,2.6).p("ABDgrQAOAKgXAVIhDAtIACgMIAcgTQAegTAEgLIACgHQgCgGgPABIgOACQgTAEgVAKQgLADgpAZIgEgBQgDgDAEgEIAkgYQAqgYAoACg");
	this.shape_240.setTransform(161.9147,102.8632);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#373535").s().p("AgHAeIAcgTQAegTAEgLIACgHQgCgGgPABIgOACQgTAEgVAKQgLADgpAZIgEgBQgDgDAEgFIAkgXQAqgYAoACIASAHQAOAKgXAVIhDAtg");
	this.shape_241.setTransform(161.9147,101.9882);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f().s("#373535").ss(3,0,0,2.6).p("AAah7QgOAQgQBBIgRBKQgRBOADAPIADAEQAEABAFgRIAThcQAThfAIgQIAMgkQgDgFgGAIg");
	this.shape_242.setTransform(160.7441,107.4387);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#373535").s().p("AgfCBIgDgEQgDgPAQhOIAShKQAQhBANgQQAHgIADAFIgNAkQgHAQgUBfIgTBcQgEAQgEAAIAAAAg");
	this.shape_243.setTransform(160.6769,107.4387);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#373535").s().p("AgFgbIAbAWIgrAhg");
	this.shape_244.setTransform(153.75,121.6);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#373535").s().p("AAPgVIAPAlIg7AGg");
	this.shape_245.setTransform(146.65,113.25);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#373535").s().p("AgegQIA9gCIgMAlg");
	this.shape_246.setTransform(145.975,103.45);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#373535").s().p("AgZgdIAzAhIgeAZg");
	this.shape_247.setTransform(153.175,94.25);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#373535").s().p("Ag1gpIBqA3IgVAcg");
	this.shape_248.setTransform(146.75,97.075);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#373535").s().p("AAkgoIARAeIhpA0g");
	this.shape_249.setTransform(147.225,119.4);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#373535").s().p("AgIALQgDgFAAgGQAAgGADgEQAEgEAEAAQAFAAAEAEQADAFAAAFQAAAGgDAFQgEAEgFAAQgEAAgEgEg");
	this.shape_250.setTransform(246.625,102.275);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AgRgFIACADQAEADANAAIAGgBQAHAAACAI");
	this.shape_251.setTransform(280.942,90.1257);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AgIgEIAEAEIARAC");
	this.shape_252.setTransform(276.9478,95.4551);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AARAJIgKgDQgKgEgJgL");
	this.shape_253.setTransform(279.8356,94.1925);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AACgHIABAFIgGAI");
	this.shape_254.setTransform(278.2922,93.5071);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#373535").s().p("AAEAHIgFAAIgEgEIAEAAIgBgKIAEACIAEAMIgCABg");
	this.shape_255.setTransform(273.6,86.5);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#373535").s().p("AAAAJQgDgBgFgGIABgEIAEAFIAAgEQABgFAEgCIgBACIAAAGIAHgGQABAKgHAFg");
	this.shape_256.setTransform(275.8563,85.55);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#373535").s().p("AgIAGIAAgDQABgGAHgBQAPgDgLAEQgFACgBADIABAEIgCABg");
	this.shape_257.setTransform(278.0533,85.5357);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AABgDIgBAH");
	this.shape_258.setTransform(278.225,87.525);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AAAgCIAAAF");
	this.shape_259.setTransform(278,87.5);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f().s("#201F1F").ss(0.8,0,0,2.6).p("AgHAEIAFgEQAFgEAEAG");
	this.shape_260.setTransform(277.9482,86.704);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AgFAAIADAAQACAAABAD");
	this.shape_261.setTransform(274.8,87.2);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AAGgFIgLAK");
	this.shape_262.setTransform(274.1,89.15);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AgLADIgCgEQgCgEAHABIAEAEIALAFIADABIAJgB");
	this.shape_263.setTransform(272.3885,88.0948);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AgHAGIAGgGQAGgHACAH");
	this.shape_264.setTransform(280.7168,85.9744);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AgDgCQAIACgHAD");
	this.shape_265.setTransform(281.9942,91.179);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#373535").s().p("AgCAFIgBgEIABgEIACgCQAEAAAAAFQAAAGgEAAg");
	this.shape_266.setTransform(275.425,97.875);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#373535").s().p("AgDAAQAAgEADgBQAEAAAAAFIgBAEIgDACIAAAAQgCAAgBgGg");
	this.shape_267.setTransform(275.075,96.1269);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#373535").s().p("AgDAJQgDgEAAgHIADgHQADgFAGAHIABAJQAAAKgHAAg");
	this.shape_268.setTransform(274.6469,93.2708);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#373535").s().p("AgDAKQgCgCAAgIIAAgJIALAJIgHAKg");
	this.shape_269.setTransform(279.375,94.575);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AABgCIgBAF");
	this.shape_270.setTransform(280.2,87.7);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AAAgDIAAAH");
	this.shape_271.setTransform(279.825,87.6);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AAAgDIABAH");
	this.shape_272.setTransform(279.525,87.625);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AABgCIgBAF");
	this.shape_273.setTransform(278.45,87.65);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AAAgCIABAF");
	this.shape_274.setTransform(277.725,87.65);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#373535").s().p("AAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIABABIgBACg");
	this.shape_275.setTransform(279.925,89.525);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#373535").s().p("AAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIABABIgBACg");
	this.shape_276.setTransform(278.15,89.675);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AADgCIABACIgEAFQgEgBACgEQABgFACABg");
	this.shape_277.setTransform(277.8947,89.5291);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#373535").s().p("AgCAAQABgFACABIACACIABACIgEAFQgEgBACgEg");
	this.shape_278.setTransform(277.8795,89.5159);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AAGAIQgCAEgDAAQgCAAgCgDIgDgIIACgHQABgEADAAIAFADIACAHg");
	this.shape_279.setTransform(278.0214,88.9421);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#373535").s().p("AgDAJIgDgIIACgIQABgDADgBIAFAEIACAHIgBAIQgCADgDAAIgBABQAAAAAAgBQgBAAAAAAQgBAAAAgBQgBAAAAgBg");
	this.shape_280.setTransform(278.025,88.9536);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f().s("#201F1F").ss(0.2,0,0,2.6).p("AgBgDIACAAQADAAgBAEIgBADIgCAAQgEAAACgEg");
	this.shape_281.setTransform(279.7,89.3744);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#373535").s().p("AgCAAIABgDIACAAQADAAgBAEIgBADIgCAAQgEAAACgEg");
	this.shape_282.setTransform(279.7,89.375);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#373535").s().p("AgDAAQAAgCADgBIAEADQAAAEgEAAQgDAAAAgEg");
	this.shape_283.setTransform(274.1222,91.075);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#373535").s().p("AgCAAQAAAAAAAAQAAgBABAAQAAgBABAAQAAAAAAAAIADABIAAABIgCADIgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQAAgBAAgBg");
	this.shape_284.setTransform(275.7469,101.7281);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#373535").s().p("AgEAGIgCgFIACgFIAEgDIAFACIACAFIgCAFIgFADIAAAAQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBgBg");
	this.shape_285.setTransform(275.675,99.9792);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#373535").s().p("AgHAMIgBgXIAIgBIADAGIAGALIgDAIg");
	this.shape_286.setTransform(276.525,113.85);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#373535").s().p("AgCAEIgCgDQAAgGAEAAQAAAAAAAAQABAAAAAAQABABAAAAQABAAAAAAIACAEIgBAEIgDACg");
	this.shape_287.setTransform(276.5477,111.35);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#373535").s().p("AgHAIIgBgNIAFgGQAFgEAFAJIACAJQAAAJgJABIgBAAQgEAAgCgFg");
	this.shape_288.setTransform(276.425,108.8951);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#373535").s().p("AgCAFIgCgFQAAgCABgCIADgDIAEACIABAFQAAAHgEAAIgBABQAAAAAAgBQAAAAgBAAQAAAAgBgBQAAAAAAgBg");
	this.shape_289.setTransform(275.875,106.3042);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#373535").s().p("AgDALIgDgVIAFAAQAEACAEAIIAAAGQgBAFgFAAIgEAAg");
	this.shape_290.setTransform(275.825,103.6929);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#373535").s().p("AgSC1IgChdIgLh0IgFgZIgEgLIAAgBQgEgNADgMIgIABQgKAAgGgFIgFgHIgDgJQgCgLAFgCIAMACIALAEIADAAIAKAAIgCgJIgQgkQgLgBACgIIAFgHIAAgBIAAAAQAOABgFANQAaAnAFACQAFAAACgJIADglQgFgJAFgDIAFgCIABAAQAGAEgCAFIgEAGIAAApIAEABIAagNQAIgGADAHIACAIQgBANgJAEIAAATQAAAEAEADIANABQAMgEAHAUIAFAUIAAABQgDAKgPADIgZgBIgFAJIgIAIIgBAAQgEACgEgFIAFA2QABATAIAwQAEAgAMAzIABABIgBAAIg4AEIgCAAQAAAAgBAAQAAAAAAgBQABAAAAgBQAAgBABgBgAgnhbIgBAHQAAAJADAKIAEALIAEAaIAMB0QACBbgBADIA1gDQgMg1gEgcQgJgxgBgTIgEg5QAAgBAAgBQAAAAAAgBQAAAAAAAAQABAAAAAAIACABQADAHADgBIAAgBIABAAIABgBIAAAAIAGgGIAGgJIAAgBIABAAIAJACQALACAEgCIAIgDQAHgDACgFIgFgVQgHgRgJAEIgBAAIAAgBIgOAAIgBgBQgEgDAAgGIAAgUIAAgBQAJgDAAgMIgBgGQgCgFgGAEIgaAOIgBAAIgEgBIgBgBIgBgsIABgBIACgDQACgEgEgDQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAABgBAAQgCADADAGIAAABIgCAmQgDAMgHgCQgFgBgOgVIgOgUIgBgBIABAAIABgGQgBgFgGAAIgDAGQgBAFAIABIAAAAIARAlIADAMIgDABIgCAAIAAgBIgIABIgDgBIgWgFQgEABADAJIADAIIAAABIADAFQAGAFAJgBIAJgBIACAAg");
	this.shape_291.setTransform(277.2609,98.9474);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#201F1F").s().p("AgRC2IgCheIgQiOIgEgLQgCgJAAgKIABgHIgJABQgKAAgGgGIgEgFIgDgJQgCgKAEgCIALACIAMAEIAMAAIAAABIADgBIgDgLIgQgkQgLgBACgHIAEgGQAIAAABAGIgBAGIANAUQAPAVAEAAQAGACACgKIADgmQgEgIADgDQABgBAAAAQABAAAAAAQABgBABAAQAAAAABAAQAGAEgDAFIgDAEIABArIAEACIABgBIAZgOQAIgEACAGIACAHQgBAIgEAFIgFADIAAAUQAAAFAEADIAOACQALgEAHATIAFAUQgDAJgOADIgQAAIgJgCQgGALgGAFIgBABIgCABQgDABgEgFQAAgBgBAAQAAgBAAAAQAAAAAAAAQAAAAAAABIAEA5QABATAKAxQADAgANAyIg5AEg");
	this.shape_292.setTransform(277.2667,98.925);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#373535").s().p("AALBSIgHABIgCABQABgCAFgBIACgCIgGABIgCABQAAgDAEgCIADAAQgDgCgEACIgCABQAAgEAFAAIAFAAQAAgCgFAAIgFgBIAJgEIgHABIAGgDIgIAAIAIgEIgFgBIgDAAIAJgFIgHABIAHgFIgHABIAGgFIgGABIgBgBQAAAAAAgBQAAAAAAAAQABgBAAAAQABgBABAAIAEgCIgHAAIAFgDIgGgBIAIgEIgIAAIAIgGIgIACIAGgHIgGAAIAFgDIgFgBIAGgDQABgCgHACIAGgHIgIABIAIgFIgJgBIAHgDIgGAAIAHgFIgFAAIgDABIAGgFIgDgBIgEAAIAHgEIgDAAIgFABIAHgGQAAAAgBgBQAAAAgBAAQAAAAAAAAQAAAAgBAAIgDABIAGgFIgEgBIgDABIAIgIIgIgBIAHgGIgJABIAHgGIgGgBIAGgHIgHAAIADgDIgFAAIAFgDIgEgBIADgDIgFgBIAGgDIgIAAIAGgEIgGgBIAFgDIgHgBIAGgDIgFgBIAGAAIgEgFIgBAAIAKgBIgBABQgCAEABAHIACAFQAFAGABAQIAKBgIgBAjIgJABg");
	this.shape_293.setTransform(273.8,98.325);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#373535").s().p("AgxBYQgIgIgBgOQAAgNAFgPQAEgPAKgPIAMgQQAIgIAHgFQAOgKALgBQAFAAAKAFIABgFQAOhLAJAQQAHANAAA+QAAA8gHAhQgIAmgMgqIgEgUIggAeQgQAMgKAAIgDAAQgJAAgHgHgAAFgNIgBABIgHAOIgGATIgBATQABAPAJgBQAFAAAHgGIAPgPIAAgHIgKAGQgBAAAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAIABgEIACgPQgBgKgFgKIgGgFg");
	this.shape_294.setTransform(271.9727,107.7396);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#FFFFFF").s().p("AAAAeIhdgdIAAgCIBhgcIABAAIBZAcIAAACIheAdgAhWAAIBWAbIBXgbIhTgag");
	this.shape_295.setTransform(247.95,84.1);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#373535").s().p("AhcAAIBggbIBZAbIhdAcg");
	this.shape_296.setTransform(247.975,84.075);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#373535").s().p("AgbADIgRgGIAEgMIAqAMIAqgMIABAPQgMABgTAJIgQAHQgGgHgTgHg");
	this.shape_297.setTransform(247.775,87.05);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#373535").s().p("AhCAsIAYgpQAggqAogJIAZgEQAWACgRAdIgCADIgVAUQgQAOgTAHIg7AegAAhgkQgbAHgXAXQgQAQgNAWIAsgVQAQgHAPgLIAVgVQAFgKgKAAg");
	this.shape_298.setTransform(253.0286,98.1);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#373535").s().p("AATBFQgRgLgHgaIgBgEQgEgKAAgFIgEgRIgRgaQgLgPgEgLIgFgQIAdAQIAYATIABAAQAaAaALARQAQAcgFAcIgBACIgKAIIgLABQgFgBgFgDgAgLgYIABABIAIAPIAHAgIABAEQAGAWANAHIAGADIAFAAIADgCQADgWgNgXQgKgQgYgYIgRgNg");
	this.shape_299.setTransform(251.2938,109.3);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#373535").s().p("AgNAUIgEgBIgFgHIgDgDIAEAAIgCgIIAJAJQADADACgGIAEgHIACgCIALgBQAGACAFgGQAEgDAAgJIADACIgCALQgCAHgDgBIgIABQgGgBgEAEIgBADQgBAGgFAFQgCACgEAAIgBAAg");
	this.shape_300.setTransform(244.025,105.1286);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#373535").s().p("AARAVIgTgBIgGgCQgGgEgFgKQABgGgEgGIgEgHIAEAAQAEAAABAEIgBgIIACgCIADAFIAAAHQABAIAGADIACACIAJAFIAKACQAKACACAFIgFAEg");
	this.shape_301.setTransform(244.325,100.725);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#373535").s().p("AgDABIgQAOIAHgUQASgPAJAJQAGAHgBAUQgIgXgPAIg");
	this.shape_302.setTransform(245.2317,103.1813);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f().s("#EE3338").ss(0.5,0,0,2.6).p("AAJgGIgEAGQgGAFgLAA");
	this.shape_303.setTransform(246.9271,100.2209);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f().s("#EE3338").ss(0.5,0,0,2.6).p("AAJgGIgEAGQgFAFgMAA");
	this.shape_304.setTransform(245.9726,104.0631);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#373535").s().p("AgXAKQgGgGAOgEIAPgEIANACIABABQgBAFgOABIAAgDQAKgBABgCIgKABIgMACQgLADACACIARABIAYgFIAIgDIADgDIAAgBQgHgGgUADIgVAFQgMACgCADIgCgCQADgCALgEIAXgFQAWgCAHAGIABAAIAAAEIgFAEIgJADIgZAGg");
	this.shape_305.setTransform(240.6,115.2515);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#373535").s().p("AgVAIIgCgBIAAgDIADABQAVAGAUgMIgBgCIgKgDIgIABQAJAAgDAEIgHAEIAAAAIgPAAIgBgDQABgEAJgDIAPgCQALAAADAFIAAAEIgBAAQgOAKgNAAgAgEgEQgHACgBACIABABIALgBQAGgCgHABIAAgDg");
	this.shape_306.setTransform(247.425,90.95);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#201F1F").s().p("Ag9B6QA5hMAOhXIAFg1IgCgYIADABIALAEIAKgBQATgEAEgFIACACIgVBjQgKAvgZBaIAAACIgCgBIgkgBIgbAJgAALgfQgOBQg0BHQAtgRAOAKQAbhpAGgfIAWhgQgIAFgNADIgLABIgLgDQAEAmgJAsg");
	this.shape_307.setTransform(243.7,103.3);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#373535").s().p("AALgpQAFgcAAgaIgBgUIAXADQASgEAFgGIgVBfIgBAEQgJAwgZBaIglgBIgcAJQA6hMANhYg");
	this.shape_308.setTransform(243.725,103.275);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#373535").s().p("AgiAFIAAAAQAAgFAKgDIAYgGIACgBIAWAAQAKABABAFIgKAIQgJAEgPACIgCABIgWAAQgKgBgBgFgAACgHIgCABIgXAGIgIAFQAAACAIABIAWAAIACgBIAXgGQAIgCAAgDQAAgCgIgBg");
	this.shape_309.setTransform(240.825,115.275);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#373535").s().p("AghAFQAAgDAJgEQAKgDAOgDIAXgBQAKACABADQAAAEgJADIgYAGIgXABQgKgBgBgEg");
	this.shape_310.setTransform(240.9,115.375);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#373535").s().p("AgQAKQgIgCAAgEQAAgEAHgDQAHgEAKgCIAQAAQAIACABAFQAAADgHAEIgRAFgAgQgBQgFACAAADIAGADIAPAAIABAAQAKgCAFgDIAGgEIgGgEIgQAAg");
	this.shape_311.setTransform(247.525,91.075);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#373535").s().p("AgPAIQgHgBAAgEQAAgDAGgDIAQgFIAQAAQAHACAAADQABADgHADIgQAFIgIABIgIgBg");
	this.shape_312.setTransform(247.3768,90.925);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f().s("#EE3338").ss(0.5,0,0,2.6).p("AgBgCIAAABIAAAEIACAEIABgDg");
	this.shape_313.setTransform(244.6913,104.5442);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#373535").s().p("AgBABIAAgEIAAgBIADAGIgBADg");
	this.shape_314.setTransform(244.675,104.725);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#373535").s().p("AgCBmIgMgJIgHgPIgCgTIAFheIgWAIIAAgQIAWgGIgCgyIAcgFIgDAtIAigMIADARIgDABIgjAJIgNBnQAAAIABAHIAFALIAFAGIAHADIAFgCIAEgFIAEgKIABgNIgBgEIgBAGIgCAEIgEADIgDACQgHAAgDgFIgDgEIgBgHIABgIIADgHIAGgEIAGgCIAJACIAIAFIAGAHIACAIIgCARIgGAOIgIALQgGADgGAAgAAZA0IADAGIABAGIgBAOIgEAKIABgBIAGgMIABgPIgBgFIgFgFIgEgDgAgLBUIgDgIIgBgRIAOhqIAAgBIAGgDIgHADIABgHIADgqIgOAEIABAjIAAANIgXAHIAAACIAXgJIgGBoIADARIADAIgAAHAxIgDAFIgBAFIABADIABAEIACABIgCgGIABgGIACgFIADgFgAAOA1IgCAEIAAAFIABgBIACgJIAGAFIAAABIgBgDIgDgEIgBAAIgBAAgAAMg2IAWgEIgBgEg");
	this.shape_315.setTransform(227.15,105.55);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#373535").s().p("AgLBaQgJgLAAgUIAGhjIgXAJIAAgJIAXgHIgCgxIAVgFIgDAvIAVgIIANgEIACAKIglAKIgGAyQgHAnAAAQQAAASAGAKQAGAKAJAAQAIAAAFgJQAEgIAAgQIgDgLQgDgFgEAAQgDAAgCADIgCAKQAAAFADAAQAEgBABgGIACABIgCAJIgFACQgEABgEgEQgEgDAAgGQAAgHAFgFQAEgFAGAAQAHgBAHAHQAHAGAAAGQAAAQgIANQgHANgKAAQgNAAgJgMg");
	this.shape_316.setTransform(227.125,105.55);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#373535").s().p("Ag+BJIgFgEIgDgGIAAgHIACgEIAFgEIAFgDIAFAAIAFACIADADIACADIAAgBIADgLIADhnIgBAAIgIgCIgDAAIACgKIAZADIAUABIgCAMIgMgBIgFAwIABAAIADAAIARABIAWgCIACgjQABgIADgFIAGgJIAKgEIAKgBIAHACIAGAGIADAIIABAHIgDAGIgEADIgFAEIgGAAIgIgFIgDgDIAAgCIgCAHIgGBYIAEAAIALgCIABAMIgcACIgNACIABgNIAOgBIgCgwIglABIgIAAIgIAxIgEALIgFAJIgHAFIgKACgAg3BAIAAABIAEAAIgBAAIgEgCgAhAA5IABAEIABADIgBgCIABgFIAAgCgAAng/IgGAHIgDAKIgCAlIABAAIgBAEIABAbIAFhAIACgLIAFgKIACgDgAgfAKIADgRIgBAAIAHg4IAAgBIgJgBgAA/gyIgBACIACgBIAAgDIAAgDgAAyhAIgEAFIAAABIADgCIAEgBIAFADIgBgEIgCgCIgCAAg");
	this.shape_317.setTransform(214.075,109.05);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#373535").s().p("Ag4BIQgEAAgEgFQgEgFABgFQABgDAEgDIAIgCQAFABACACIABAGIgCADIgDABQgEAAAAgFIABAAIACACIACgDIAAgDQAAAAgBgBQAAAAAAAAQgBAAAAAAQAAAAgBAAIgEABIgCAFQgBAFABACQABAEADAAQAHABAEgHQAFgHACgPIADhqIgDAAIgIgCIAAgEIAnAFIgBAEIgMAAIgGA1IAIACIASABIAYgDIACgmQACgMAIgHQAHgGAKABQAGABAEAGQAFAGgBAHIgGAHIgIACIgHgDQgDgDABgCIADgFIAFgCIADACIABACIgCADIgDgEIgCAEIABAEIADADIAEgEIADgIIgBgIQgCgEgEAAQgGgBgFAIQgEAGgCANIgGBcIAPgCIABAFIgiADIAAgFIAOgBIgCg4IgaADIgYgBIgJAzIgJASQgEAGgHAAIgCAAg");
	this.shape_318.setTransform(214.073,109.0484);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#373535").s().p("AgIAVIgHgEIgEgHIgCgJQAAgEACgEIAFgIIAGgFIAIgCQAIAAAGAEQAGAEABAJIABACIgDABIgBAAIgGgHIgIgCIgGABIgGADIgEAFIgCAEIACAGIADAFIAFACIAEABIAGgBIACgGIgCgGIAAACIgCAGIgFACIgCgBIgDgDIgCgFIABgEIADgCIADgCIAEgBIAFABIAFACIAEAEIABAFIgBAHIgFAEIgGAEIgGABgAAJAAIACAJIgDAIIACgBIAEgEIABgFIgBgEIgDgDIgEgBIgCAAgAgGgRIgGAFIgEAGQgCAEAAADQAAAFACACIAEAGIABABIgEgGIgCgHIACgGIAFgFQACgCAFgCIAHgBQAFAAAEACIAEADIgFgGQgFgEgHAAgAgEAGIACADIABABIACgCIABgBIgCAAIgDgBQAAAAAAAAQgBgBAAAAQAAAAAAgBQAAAAAAgBgAgBACIAAACIABAAIACAAIADgCQAAgBgBAAQAAAAgBAAQAAgBgBAAQAAAAgBAAIgBAAg");
	this.shape_319.setTransform(261.225,99.225);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#373535").s().p("AgOAPQgFgFAAgJQAAgHAGgIQAHgGAGAAQAQAAAEAQIgBAAQgGgJgJAAQgGAAgHAFQgGAFAAAFQAAAHAGAFIAJAEQAJAAABgJQgBgJgHAAIgCAAIgDADIAEADIADgCQgBAHgDAAIgEgCIgCgFQAAgDADgCIAGgCQAGAAADADQAFACAAAFQAAAGgFAEQgGAEgGAAQgHAAgHgGg");
	this.shape_320.setTransform(261.2,99.225);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#373535").s().p("AgaA4IARAAQAAg4gFgzIgQgBIAAgLIAXAAIAJgBIASgGIAAAOIgMADIgGBrIAYgCIAFAAIAAAPIgoABIgRADgAgJg3QAGAvAAAyIAFhkIgJACIgCAAg");
	this.shape_321.setTransform(261.45,109.525);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#373535").s().p("AgWA7IARgBQAAg6gHg3IgOgBIAAgEIATAAIAXgGIAAAHIgLADIgFBxIAbgBIAAAIIglAAIgMACg");
	this.shape_322.setTransform(261.45,109.55);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#373535").s().p("AgIAVQgDgBgDgEIgFgGIgCgJIACgIIAFgIIAGgFIAIgCQAIAAAGAEQAGAEABAJIABACIgCAAIgBAAIgBABIgBgBIgFgGIgIgCIgGABIgGADIgEAFQgCACAAACQAAAEACACIADAFIAFADIAEABIAGgCIABgCIABAEIACgBIAEgEIABgFIgBgEIgCgDIgFgBIgDgBIABADIABABIgBAAIAAgBIgDgBIgBAAIgBABIgBABIAAACIABAAIAEgBIABgBIABAFIgCAEIgFACIgCgBIgCgDIgCgCIAAgDIABgEIACgCIADgCIAEgBIAFABQADABACACIAEADIABAFIgBAGIgFAFIgGAEIgGABgAgGgRIgGAFIgEAGIgCAHIABAHIAFAHIAFADIACABIgGgEIgEgGIgCgHIACgGIAFgFIAHgEIAHgBIAJACIAEAEIgFgHQgFgEgHAAgAgEAEIAAACIABACIABABIABABIACgCIABgBIgCAAIgCgBIgCgDIABgCgAAHANIgBgGIAAgCIAAgCIACAGIgBAEgAAGAHg");
	this.shape_323.setTransform(188.775,99.225);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#373535").s().p("AgNAPQgGgFAAgJQAAgIAGgHQAGgGAHAAQAQAAAEAQIgBAAQgGgJgJAAQgGAAgHAFQgGAFAAAFQAAAHAFAFIAKAEQAJAAAAgJQAAgJgHAAIgDAAIgBADQAAABAAAAQAAABABAAQAAAAABABQAAAAAAAAIAFgCQgCAHgEAAIgDgCIgCgFQAAgEADgBIAGgCQAFAAAEADQAFABAAAGQAAAGgGAEQgFAEgGAAQgIAAgFgGg");
	this.shape_324.setTransform(188.775,99.225);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#373535").s().p("AgaA4IARAAQAAg4gFgzIgQgBIAAgLIAXAAIAJgBIASgGIAAAOIgMADIgFBrIAYgCIAEAAIAAAPIgoABIgRADgAgJg3QAGAvAAAyIAFhiIAAgCIgJACIgCAAg");
	this.shape_325.setTransform(189,109.525);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#373535").s().p("AgWA7IARgBQAAg6gHg3IgOgBIAAgEIATAAIAXgGIAAAHIgLADIgFBxIAbgBIAAAIIglAAIgMACg");
	this.shape_326.setTransform(189,109.55);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#373535").s().p("AgmgjQAegBAiAIIAdAJIgWARIhXAmg");
	this.shape_327.setTransform(165.025,110.7388);

	this.instance_4 = new lib.Symbol79("synched",0);
	this.instance_4.setTransform(159.9,107.45,0.64,0.64);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#373535").s().p("AgPgSQAWgIAPACQAKAAgHAJIgJAKIgqAeg");
	this.shape_328.setTransform(164.4941,101.6632);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#201F1F").s().p("AgrAYQAdgHAcgVIAagVIAEAaQghAXgeACg");
	this.shape_329.setTransform(212.4,96.975);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#373535").s().p("AADAGIg1AQIA0gsIAxAoIgEAFg");
	this.shape_330.setTransform(216.125,96.725);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#373535").s().p("AgVBcIgMgGIgIgLQgEgFAAgHQAAgIAFgHQAGgIAIgFIADgBIABABIAAAAIABgSIgIgFIgJgJIgGgKIgCgMQAAgLAEgHQACgJAHgIQAFgHAHgDQAGgFAIAAIAHADIAFACIABgBIABABIABAAIAAAAIABAAIABABIAAAAIABAAIAAABIACACIABAEIgIAEIAIAGIAGALIADAMIgDAQQgDAHgGAFIgMAKIgKACIgBASIANgJIARgGIAIgBIAJACIAGAGIAEAJIACAKQAAATgQAPIgSALIgVAEgAgcA8IACAKIAEAIIAHAEIAIACIAPgDQAIgCAGgHIAIgLIACgLIgBgHQgDgDgEAAIgHABIgHABIgHADIgPAJIgIAGIgIgFgAgjA0QgDAFAAAGIACAJIAGAIIAEADIgBgCIgFgKIgCgLIACgLgAAYAiQAHgBAEAFQAEAEAAAIIAAAFIABgJIgBgJIgEgGIgDgEIgGgBIgHAAIgPAHIgWANIgBAFIAbgQIAIgBgAgPg3IgHAHIgFAMIgCANIABAOIAFAJIAEAGIAGACIAIgDIAFgGIAFgLIACgNIgCgIIgDgHIABAFQAAAEgDAFQgEADgFAAQgHABgEgFQgDgFAAgHIABgFIAEgGIAGgEIAGgBIALACIAAgBIgFgCIgGgCQgFAAgEADgAglgjIgCAQIABAKIAGAJIADAEIAAgBIgEgLQgCgFAAgKIACgPIAEgLQgFAFgDAJgAAOgZIgCAPIgGAKIAIgKIACgNIgCgKIgFgIgAgKghIABABIABAAIAAgBIgCgBgAgIguIgBACIgCACIAAAAIADgCQAAAAABAAQAAAAAAgBQABAAAAAAQAAAAABAAIAFACIgCgCIgEgBgAAHhdIAAAAIAEAFIAAAAg");
	this.shape_331.setTransform(200.15,110.3);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#373535").s().p("AgfBGQgKgIAAgMQAAgOARgKIABACQgIAHAAAMQAAALAHAJQAGAIALAAQATAAAMgMQAMgNAAgNIgDgJQgDgEgGAAIgPACQgGACgJAFIgOAKIgDgCIAGgoQgLgCgHgJQgHgKAAgMQAAgSALgOQALgOANAAQAIAAAFAFIgBgCIACABIABABIABABIABABIgDADQgFgGgIAAQgLAAgHALQgIALAAAQQAAAQAGAKQAGAJAHAAQAKAAAGgLQAHgMAAgOQAAgJgFgIQgFgIgGAAQgDAAgCAEIgDAHQAAALAGAAIADgBIABgFIgBgCIgEABIABgEIADgCQAFAAAAAGIgCAHIgHADQgFAAgDgEQgDgEAAgGQAAgEAEgEQAFgFAFAAQAKAAAHAJQAIAIAAAMQAAAQgLALQgJALgMAAIgDAbIAagQIARgEQAHAAAFAHQAEAHAAAKQAAASgOANQgPAPgVAAQgOAAgKgJg");
	this.shape_332.setTransform(200.125,111.575);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#373535").s().p("AgWgCIAZgWIAUAxg");
	this.shape_333.setTransform(170.375,120.95);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#373535").s().p("AgQgXIAhgEIgJA3g");
	this.shape_334.setTransform(162.125,124.6);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#373535").s().p("AgZACIAzgfIgXA7g");
	this.shape_335.setTransform(172.25,96.225);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#373535").s().p("AgSAbIAXg6IAOA+g");
	this.shape_336.setTransform(163.225,90.75);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#373535").s().p("AgQg+IAhAIIggB1g");
	this.shape_337.setTransform(157.95,127.475);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("#373535").s().p("AgWg8IAtBzIghAGg");
	this.shape_338.setTransform(158,88.3);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#373535").s().p("AgjgnIAVgPIAyBtg");
	this.shape_339.setTransform(168.525,125.925);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#373535").s().p("AgiArIBFhhIguBtg");
	this.shape_340.setTransform(169.55,90.05);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#3F4096").s().p("AhCAcIgBgBIAAgCIAAgDIgBgBIAAgOIABgCIgBgBIABgBIAAgGIgIAAIgDABIgFAAIgBAAIgBgBIAAAAIgBABIgCAAIgBAAIgBACIgCgCIgDAAIAAABIgCAAIgBgBIAAABIgBgBIgCAAIgBABIAAAAIAAAEIgBACIABACIAAABIgBACIABABIAAAAIgBAEIAAABIAAADIABACIAAADIgBAAIAAAAIgBABIgCgBIgBgCIAAgEIgBgCIgBgCIABgBIAAgDIgBgIIAAgDIgBAAIAAgBIAAAAIgBgDIAAAAIABgBIACgBIAAgEIAAgCIAAgBIAAAAIAAgDIABgCIgBgGIABgDIAAAAIACgCIABAAIAAAAIABABIABAAIABABIAAACIAAABIABAAIgBABIAAABIAAABIAAAAIAAAJIAAABIAAABIAAABIgBACIAAABIABAAIABAAIACAAIAEAAIABAAIABAAIABAAIAAAAIACAAIADAAIABAAIAAAAIABgBIABABIAAAAIACAAIABAAIAAAAIABAAIAKgBIACAAIAAgBIAAgEIAAgDIAAgBIAAgCIgCgEIAAgDIACgCIAAAAIAAgCIADAAIABABIAAAAIAAAAIACAAIAAABIABAAIAAAEIgBABIABABIAAABIAAADIAAACIAAABIAAAAIgBAHIADAAIAEgCIAFAAIABAAIABAAIABAAIABACIgDACIAAAAIAAAAIgBgBIgCACIAAgBIgBAAIgBABIAAAAIgBAAIgBAAIgDAAIAAABIgBABIgBAAIAAgBIgBABIAAAAIAAACIAAAEIgBABIABAAIAAABIgBABIAAABIABACIgBABIAAAEIgBAEIABAAIgBACIAAABIAAABIAAAAIABACIAAABIgBAEIgDACgAhBADIAAABIAAAAIAAABIgBACIAAAIIABABIgBABIAAABIABABIAAAAIABgNIAAgBIAAAAIAAgBIAAAAIAAgBIAAgCIgBAAgAhpAPIAAgCIgBABIAAABIAAgBgAhqAMIABABIAAgCIAAgBIgBAAgAhqgZIAAACIABAEIgBADIABACIAAABIgBABIABAAIAAABIgBAFIgBABIgCABIABABIABABIABACIAAAKIABgDIAAgHIABgCIACgBIADgBIAAgBIABABIABAAIAAABIABAAIABgBIABAAIAAAAIACAAIgBgBIgBAAIgFAAIgFAAIAAgBIAAgCIAAgDIABAAIgBgBIAAgBIABgHIAAgBIAAAAIAAgCIAAgBIAAgBIAAgBIgCgBIAAAAgAhBgCIAAACIACgCIgCAAIAEgEIgCAAIABgKIAAgDIAAAAIAAgCIgBgCIAAAAIAAgBIABgBIgBABIAAgCIgBAAIAAAAIAAABIgCAAIgBAAIABABIABAFIAAADIABADIAAABIgBABIABABIAAACIgBAAIABABIABABIgCAAIAAAEgAhbgEIAAAAIABAAIAAAAIADAAIABgBIACAAIAAAAIABABIAFAAIADgBIAEAAIABAAIAAgBIABABIAAgBIgBAAIgJABIgFAAIAAAAIgBAAIgGAAgABhAcIgBABIgCAAIgBgBIgCAAIAAAAIgCgBIgCgCIAAgBIgBAAIAAgBIgBgBIAAAAIAAAAIgBAAIAAgCIgBgFIAAgDIABgCIAAgCIAAgCIAAgCIABAAIAAgBIAAgDIAAgBIAAAAIABgBIgBgDIAAgCIABgDIABADIABAAIAAAAIABgBIAAgBIADgFIAAAAIAAgBIABAAIABgCIABgBIAAgBIABAAIABgBIABgBIAAAAIABgBIABAAIADAAIAAAAIACAAIAAABIAAABIACAAIAAABIAAAAIACACIgBAAIAAABIABACIAAAAIgBABIABADIAAAAIgCAEIgCACIAAABIAAABIgDACIgDABIgBABIAAAAIgDABIgBAAIgCABIgBgBIAAAAIgBAAIgBADIAAAAIgBADIAAABIAAADIABAAIgBAAIAAAEIAAABIABABIAAAAIAAABIACABIABAAIAAABIABAAIAEAAIACAAIABgBIAAAAIABgBIAAAAIABAAIAAgBIACgBIAAAAIABgBIABgBIAAAAIABgBIABgCIABAAIACAAIAAAAIABACIgBACIgCAEIAAAAIgBAAIAAABIgBABIgBAAIgCACIgBABIgBAAIAAABIgCAAIAAABIgBAAIAAAAIgBAAIgBABgABhAaIABgBIABAAIACAAIAAgBIABAAIAAgBIABAAIACgBIABgBIAAAAIABgBIAAgBIABAAIAAgBIgBAAIAAABIAAAAIgBAAIAAABIgBABIgBAAIAAABIgCAAIAAAAIAAAAIgBABIgBABIgKgBIAAgBIgCAAIgBgBIAAABIACABIAAABIABABIACAAIAAAAIAAABIABAAIABgBIAAABIACAAIABgBgABWAUIABAAIAAAAIgBgBgABXAGIABgDIABgCIADAAIAAABIACgBIABAAIACgBIABAAIAAAAIAFgDIAAgBIABgBIABgCIABgDIAAgCIgBAEIAAABIgBABIgBAAIAAAAIgBABIgBABIgBABIgBAAIAAAAIgBABIAAAAIgBAAIgBAAIAAABIgCAAIgBABIgBAAIgBAAIgBgBIAAAAIAAgBIgBAAIABgDIAAAAIgDAAIABADIAAABIgBAAIACABIgBAAIgBABIAAABIABABIgBABIAAABIgBAAgABhgMIgBABIgBADIgBABIAAAAIgDAEIABAAIAAABIABgBIACAAIAAgBIABAAIAAAAIABAAIABAAIAAgBIAAAAIABAAIAAgBIAAAAIABAAIABgBIAAgBIABAAIAAAAIABAAIAAgCIABgCIAAgCIAAgBIgDAAIAAAAIgBAAIgBABIgBAAIAAABIAAgBIAAABIgBAAgABegOIAAABIgDAGIgBAAIABABIABgDIADgFIAAAAIABAAIAAgBIABAAIABgBIABgBIABAAIAAAAIABgBIABAAIAAABIABgBIAAAAIABABIAAgBIgBgBIgCAAIAAgBIgBAAIAAABIgBAAIgBAAIgBACIgBABIAAABIgBAAIAAAAgAglAcIgBAAIgBgBIgEAAIgCgEIgBgBIABAAIAAgBIgBgDIgBAAIABgCIgBgCIABgBIAAgFIAAAAIABgEIAAAAIABAAIAAgEIABAAIAAgBIAAgBIAAgBIAAgBIABgBIABAAIgBAAIAAgBIACgCIAAgDIABAAIABAAIgBgBIAAgBIAAgBIABAAIACAAIABgCIAAgBIACAAIABgBIAAAAIABABIACAAIABgBIABgBIAAACIABAAIABABIACAAIAAABIAAAAIABAAIABACIABAAIAAABIABAAIAAABIACADIABAEIAAABIABADIAAAAIAAACIAAADIgBABIAAAAIAAACIgBACIgBABIAAABIAAABIAAAAIgBABIAAAAIAAAAIgCACIgBACIAAAAIAAACIgBAAIgBAAIAAABIgBABIgCAAIgBAAIgBACIgBABIgBAAIgBAAIgBAAIgCACIgBACgAglAZIABAAIAAgBIACAAIgEAAIgBAAIAAAAIgBAAIAAAAIgBAAIAAgBIgBAAIgBgBIAAAAIAAAAIABABIAAABIADABIABAAIAAgBgAgmgBIAAABIABABIgCABIAAACIgBAAIAAACIgBABIAAADIgBADIAAADIAAACIAAACIABABIAAABIABAAIABAAIAAAAIABAAIADAAIAAgBIABAAIABAAIAAgBIACAAIABAAIAAAAIAAgBIABgBIAAgBIACAAIAAgBIACgBIABgBIAAgBIACAAIAAgBIAAgBIAAgBIAAgBIABAAIAAAAIAAgBIAAAAIABgCIAAAAIAAgBIAAAAIAAgBIAAgBIgBAAIABgBIAAgCIgBAAIABgBIgBgBIAAgDIgBAAIAAgBIgBgBIAAgBIgBAAIAAgBIAAgBIgBgBIgBAAIgCgCIgBAAIgBABIAAAFIgDAAIgCABIAAABIgBAAIgBACIAAABIAAAAgAgsALIAAABIABgCIAAgBIgBAAIAAAAgAgrAHIAAAAIAAgBIAAAAgAgngHIAAABIAAABIgBABIgBABIAAADIgBABIAAACIABAAIAAgBIABgCIAAgCIABgBIABgCIAAgBIAAAAIABgBIAAAAIAAgBIADgCIACAAIAAgCIABgCIACgBIABAAIABABIACAAIABABIACABIgDgCIAAAAIgCgBIgBAAIgBAAIAAAAIgCAAIgBAAIgDACIgCABIAAABIAAABIgBACIABAAIgBABIgBAAgAgVgIIAAABIACABIABABIAAADIAAABIAAABIABAAIAAAAIgBgDIAAgBIAAgBIgBgCIgBgDgAA2AZIAAAAIgBAAIgBAAIAAgBIAAABIgBAAIgBgBIAAAAIgCAAIgCAAIAAAAIgBABIgBgBIAAAAIgBgBIgCgBIgBgEIAAgBIACAAIAAgBIABAAIABgCIAAACIABAAIACAAIAAACIABAAIAAACIABAAIABAAIAAAAIAPgBIABgBIAAAAIABgBIACAAIACgBIAAgCIgBAAIAAgBIgBAAIgBAAIAAAAIgBgBIgBAAIAAgBIgCAAIgCgBIAAAAIgCAAIgBAAIAAgBIgBAAIAAgBIgDgBIgBAAIAAgBIgDgBIgBAAIAAAAIgCgCIgBAAIgBgDIgBgBIAAgBIAAgEIAAAAIAAgCIABgDIACgBIAAgBIABAAIADgDIAAAAIAFgDIABAAIAFgBIAAAAIAFAAIABABIABAAIABADIAAAAIAAABIAAABIAAABIgBABIgBABIgCgBIAAgBIgCgBIAAABIgBAAIAAgBIgBAAIgBAAIgCABIgCABIAAAAIgBAAIgBAAIAAABIgCAAIAAABIgBAAIAAAAIgBACIgBABIAAAAIgBABIgBADIAAAAIAAABIABABIAAAAIABABIABABIABAAIACABIACAAIABABIABAAIABAAIAAABIAEABIABAAIADACIABAAIAAAAIAAABIADAAIABABIABACIABABIAAAAIACABIgBAAIAAABIABABIAAAAIAAABIgBABIgCADIAAABIAAABIgCAAIgBAAIAAABIgDAAIgBABIgBAAIAAAAIAAABIgCAAIgBgBIgCABIgFAAIgBABgAA4AWIABABIAAgBIAGAAIACAAIABAAIAAAAIABAAIACgBIABAAIABgBIABAAIAAgBIgBAAIgEABIAAABIgBAAIgPABIACAAIABABIABgBgAArAVIABABIABAAIAAAAIABAAIgBAAIAAgCIgBAAIAAgBIgBABIAAgBIgBAAgABJAOIAAABIABAAIAAABIgBABIAAABIgBABIABAAIABgEIAAgBIAAAAIAAgBIgBAAIgBgCIgBgBIgCAAIAAABIABAAIAAAAIABABIAAAAIABAAIAAABIABAAIABAAgAA6AGIABAAIAAABIABAAIACABIABAAIACABIACAAIgBAAIAAgBIgDgBIAAAAIgEgBIAAgBIgCAAIAAAAIgBgBIgBAAgAAxgKIgBABIgBADIAAAAIAAABIABgCIABgBIABgCIACgCIAAAAIABAAIABgBIABgBIABAAIAAAAIACgBIACAAIABAAIAAgBIABAAIABAAIACABIADAAIAAAAIABABIAAgBIgBgBIAAgBIgBAAIgBAAIgDAAIgFABIgFACIgDADIAAAAIAAAAgAAcAYIgBAAIgBgBIAAAAIgEgDIAAgDIgBgBIAAgCIgBgBIAAgEIABgBIgBgBIAAgDIgBAAIAAABIgBABIgBAAIAAACIAAAAIgBABIgBACIgBABIgBABIgBAAIgBAAIgCAEIgBABIgCACIgCABIAAABIgEACIgBgBIgBAAIgCgBIgBgBIAAAAIABgBIgCgCIABAAIAAAAIgBgDIAAAAIAAgBIAAgBIAAgEIAAgBIAAgBIgBAAIABgBIABgCIgBAAIAAgBIABAAIAAgCIgBgDIAAAAIABgGIAAgDIAAgDIgBAAQAAgBAAAAQABgBAAAAQAAAAABAAQABAAAAAAIACABIABABIAAAAIAAAKIgBABIAAAEIAAABIAAABIABAAIgBABIAAABIAAAAIAAABIAAACIAAACIABABIgBAAIAAADIABAAIgBABIABABIAAACIABgBIABgCIAAAAIABgBIAAgBIACAAIAAgBIAEgCIAAAAIABgBIACgDIABgBIAAgBIABAAIACgCIABgBIAAgBIABAAIABgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIABgBIACgFIAAgBIAAAAIAAgBIABAAIAAgBIABgCIAAAAIABAAIABgBIACAAIAAACIAAABIAAABIAAAEIgBAAIgBACIgBADIAAAAIgBABIAAACIAAAAIAAACIgBABIAAADIAAAGIAAAAIAAACIABADIACAAIAAABIAAAAIABABIABAAIACAAIABAAIABgCIACAAIACABIABABIgBABIgBACIgBAAIgCABIgBABIgBAAIgDAAgAAZATIACADIABAAIABAAIAAAAIACAAIABAAIAAAAIACAAIAAgBIACgBIAAgBIgBAAIgBACIgCAAIgBABIAAgBIgCAAIgBAAIgBgBIgBAAIAAgBIAAAAIgBAAIAAgBIgBgBIAAgBgAgDASIABABIAAABIABABIAAAAIABABIACgBIABgBIAAgBIACgBIACgDIAAAAIADgDIgBABIgBAAIgBAAIAAACIgBAAIAAAAIgCABIAAABIAAAAIgCACIgBABIgBAAIAAAAIgCgCgAgEAPIAAABIABAAIAAgBIAAgBIAAgBIAAAAIAAgCIAAgBIAAgDIgBAAIAAAFIAAAAIAAABIABACgAALAKIAAABIACgCIAAgBIABgBIgBAAIAAABgAASACIAAABIABAAIAAgBIABgBIADgBIAAACIAAAAIAAgCIABgBIAAgCIABAAIAAgBIABgDIAAAAIABgDIABgDIAAgBIgCADIAAADIAAAAIgCAEIAAAAIgBABIAAABIAAABIgBABIgBAAIAAAAIAAAAIgBABIgBAAgAgEgOIABAGIgBAGIABACIAAAAIAAgHIABgFIAAgBIAAgBIAAAAIgBAAg");
	this.shape_341.setTransform(246.225,124.75);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#3F4096").s().p("AhBAcIgCgCIAAgEIAAgCIABAAIgBgBIAAgLIABgCIgBgBIAAgCIAAgEIABgEIgCACIAAgCIgBACIgBgBIgDABIgCAAIgDABIgFAAIgBAAIgCgBIAAABIgCAAIgBAAIgBABIgCgBIgCAAIgBAAIgBAAIgBAAIgBAAIgBAAIgEAAIAAACIAAADIgBADIABACIgBACIABABIgBAFIAAABIAAADIABABIAAADIgBAAIgBgBIgBgGIgCgCIACgBIgBgBIAAgDIgBgIIAAgCIgCgBIAAgEIACgBIABgEIAAgCIABABIAAgBIgBgEIABgCIgBgFIAAgCIABgCIACgBIABABIAAACIABABIgBADIABACIgBAHIAAACIAAAEIABAAIABAAIADAAIACAAIABAAIACABIAAgBIABAAIABAAIAGAAIABgBIAAABIADAAIACAAIAKgBIADAAIAAgBIAAgEIgBgEIABgCIgCgHIABgBIABAAIAAgCIABAAIAAABIADAAIAAABIABAAIAAACIgBABIABADIAAABIAAABIAAACIgBAJIAEAAIADgBIAGAAIgCABIgCAAIgBABIgBgBIgDACIgBACIgCgCIgBADIAAAAIgCACIABAAIABAAIgCAFIACAAIgBACIgBAAIABACIgBAAIAAAFIgBAFIAAAFIABAAIAAACIgBABIAAAAIAAACgABgAbIgCABIgBgBIgBAAIAAAAIgEgBIAAgBIgCgBIAAgBIgBgCIAAgBIgBgEIAAgEIABgCIAAgEIABgBIAAgFIAAAAIAAAAIAAgBIAAgEIAAgCIABABIADAAIAAgBIADgHIABgBIABgCIACgCIACABIAAgCIACAAIABAAIABAAIAAABIAAAAIACABIADAEIgBACIABADIgBAAIgBACIgCAEIAAABIgFACIgBABIgBAAIgCABIgBAAIgCABIAAAAIgCgBIgDAFIAAACIgBAAIABAEIgBABIAAADIABACIABACIADACIAAAAIAFABIADAAIACgCIABgBIABAAIAAgBIABgBIABAAIABgBIAAgBIADgCIABAAIABABIgBABIgCADIAAAAIgCADIgBAAIgCACIAAABIgBAAIgBAAIgBAAIgBABIAAAAIgCABgABagCIACACIADgBIAAgBIABAAIABAAIABAAIABgCIAAAAIABgBIACgCIABgBIAAgBIACgCIAAgBIgBgEIgBAAIgCAAIgBAAIgDABIAAABIAAgBIgBAAIAAABIAAABIAAABIgBABIgBAAIAAADIgBAAgAgmAaIAAABIgCgBIgCAAIgDgDIABgCIgCgDIAAgIIACgBIAAgBIAAgCIABAAIAAgCIAAgEIABAAIAAgDIABgCIAAgBIABgCIABAAIgBgBIACgBIAAgCIAEgEIABAAIABAAIACAAIACgBIAAABIADABIABAAIADAEIAAABIABAAIABACIACAFIAAABIABACIgBACIABABIAAADIgBABIAAABIgDAFIAAABIgBABIgBABIgBABIAAABIgBABIgBAAIgBACIgGADIAAABIgBAAIgCABIgCABgAgggLIAAADIgBAAIgDABIgBABIgBABIAAADIgBABIgBABIABAAIgCABIAAACIAAACIAAABIgBABIAAABIAAABIAAABIgBADIAAABIAAADIAAABIAAACIACAEIAAAAIACAAIABAAIADAAIABgBIAAAAIABAAIABgCIABABIAAgBIABAAIABgBIABgCIACAAIAAgBIADgBIAAgBIABgBIABgDIAAgBIABgBIAAAAIABgBIgBAAIABgBIAAgEIAAgCIAAAAIAAgBIAAAAIgBgBIAAgCIgBgCIgBgBIAAgBIAAAAIAAgBIgBgBIAAAAIAAgBIgCgBIgEgDQgBAAAAABQgBAAAAAAQAAAAAAABQAAAAgBABgAA7AYIgBABIgBAAIgBgBIgBABIgBAAIgCgBIgBABIgCgBIgDAAIAAAAIgBAAIgBAAIAAgBQgDAAAAgFIACAAIAAgBIAAAAIAAAAIABAAIAAABIABgBIABABIAAABIABAAIAAACIACAAIAAABIABgBIAMAAIAEgBIAAgBIABAAIAAAAIAEgCIABAAIAAAAIABgBIgBAAIAAgBIgBgBIgBgBIAAgBIgBAAIgBgBIgBAAIgBgBIAAAAIgDgBIgCAAIgBAAIgBAAIAAAAIAAAAIgBgBIgDgBIgBgBIgDgBIgBAAIgCgDIgBgCIgBgBIAAgFIABgDIACgCIAAAAIACgDIABgBIAGgCIACgBIADAAIAEAAIAAAAIAAAAIACABIAAABIABABIgBADIgBABIgBgDIgDAAIgBgBIgBAAIgBABIgCAAIgCACIgBAAIgBABIgCABIgBAAIAAAAIgCABIAAACIgBAAIgBAFIAAAAIAAABIABABIAAAAIADACIAAAAIACABIACAAIABACIACAAIAAABIAFABIABABIADABIAAAAIABAAIACAAIACABIABACIAAABIAAABIABAAIAAAAIABACIgBABIgBACIgBABIAAABIgBAAIgCACIgCAAIgBAAIgBABIAAAAIgCAAIgEAAIgBABgAAcAYIgCgBIgDgDIgBgDIAAgBIAAAAIgBgDIAAgDIAAgBIAAgCIAAgFIgBAAIAAABIgCADIgBAAIgBACIgCABIgBACIgDADIgFAFIgCABIAAACIgDACIgCgBIAAAAIgBgBIAAgBIgBAAIABgBIgCgCIABgBIgBAAIAAgBIAAgBIAAgBIAAgGIAAgBIAAgCIAAgGIABgHIgBgDIAAgDIACgBIABAAIABABIgBADIAAAEIAAAEIAAABIAAACIgBABIABAAIgBACIABAAIgBACIAAABIAAABIAAACIAAABIABABIAAAFIAAABIACACIABgBIACgBIAAAAIABgCIACAAIAAgBIAAgBIAEgCIAAgBIACgBIABgCIABgBIACgDIAAAAIAAgBIACAAIAAgCIACAAIABAAIAAAAIAAgBIAAAAIACgCIgBgBIACgFIABAAIAAgBIACgEIABgBIAAABIABACIgBAEIgBABIgBAFIgCAAIAAACIAAAAIAAACIgBABIAAALIABAAIAAABIABADIACAAIAAABIACABIACAAIACAAIACgCIABAAIABABIgBACIAAAAIgBABIgCABIgBAAIgDABgAgxgIIABAAIABAAIgCABg");
	this.shape_342.setTransform(246.25,124.7);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#3F4096").s().p("AB6AjIgBAAIgBgBIgFAAIAAgBIgCgDIAAAAIAAgBIAAgBIgBgDIAAgBIABgBIgBgCIAAAAIABgCIAAgEIAAAAIAAgCIABgCIABAAIAAgBIgBAAIABgCIAAgBIABgBIgBgCIAAgBIABgBIABgBIgBgBIACgBIABgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIABAAIACgCIAAgBIABAAIACgBIAAAAIABABIACAAIACgBIAAABIABABIACAAIABABIAAAAIACABIABACIAAABIABAAIABADIAAAAIABADIABABIAAAAIAAAEIAAAAIAAACIAAAAIAAABIAAACIgBABIAAACIAAACIgBABIAAABIgBABIAAABIgBAAIAAACIgBAAIgBACIgBAAIAAACIAAAAIgCAAIAAABIgBABIgBABIgBAAIgBABIgCABIAAAAIgBABIgBAAIgCABIgBACgAB6AgIAAAAIABAAIABgBIgDAAIgBABIAAgBIgBABIgBAAIAAgBIgBAAIgCgCIAAAAIACADIADAAIABAAIAAAAgAB2AQIgCAEIABABIAAACIgBACIAAACIACABIAAABIABAAIAAAAIABAAIABAAIACAAIABgBIAAAAIABAAIABAAIAAgBIACAAIABAAIABgCIAAgBIACAAIAAAAIAEgEIABAAIAAgBIAAgBIAAgBIAAgBIABAAIAAgBIABgBIAAAAIAAgBIAAgCIAAAAIgBgBIABgBIAAgBIAAgBIAAAAIgBAAIABgBIgBgBIAAgCIAAgBIgBgBIAAgBIgBAAIAAAAIAAgBIgBAAIgBgCIgEgCIAAAAIgBAAIAAAFIgDAAIgDAAIAAABIgBABIAAADIgBAAIAAAAIAAACIAAAAIAAABIAAABIgBAAIAAABIgBABIAAABIAAABIgBABIAAABIAAAAgACCAbIAAABIABAAIABgBIAAAAIgBAAgAByARIAAAAIAAABIAAABIABgCIAAgBgAB4AAIgBAAIABABIgBACIgBABIAAADIgBABIAAACIABgDIABAAIAAgCIABgBIAAgBIABgCIAAgBIAAAAIABgBIADgCIABAAIAAgCIACgCIACgBIAAAAIAAAAIAAAAIgCAAIgBAAIgDACIgCABIAAABIgBACIAAABIAAAAIAAABIgBAAgACDgHIADABIABABIAAgBIgBgBIgBAAIgBAAIgBgBIAAAAgAALAjIAAABIgDAAIAAgBIgCAAIAAAAIgCgBIgCgBIAAgBIgBgBIAAAAIAAgBIgBgBIAAAAIAAgCIgBgEIAAgEIAAgEIABgBIAAgBIgBgBIABgBIAAgBIAAgBIAAgCIAAAAIAAAAIAAgBIAAgBIABgBIgBgCIAAgCIABgCIABACIABAAIAAAAIABgBIACgGIAAgBIABAAIAAgBIAGgFIAAABIAAgBIABAAIACgBIACAAIAAABIABAAIABABIAAAAIACAAIAAABIAAABIABABIAAAAIAAABIAAACIAAAFIAAABIgBABIgCACIAAACIAAAAIgGAEIAAAAIgBABIAAAAIgDABIAAAAIgDABIgBAAIgBgBIAAAAIgBAEIAAAAIAAABIgBABIAAAEIAAABIAAAAIAAABIAAABIAAAAIAAACIABABIAAAAIAAABIACABIAAAAIAAABIACAAIAEAAIABAAIACgBIAAgBIABAAIAAAAIAAgBIADgBIABgBIABgBIAAAAIABAAIABgCIAAgBIACAAIAAABIABACIAAABIgCACIAAACIAAAAIgBAAIAAACIAAAAIgBABIgBAAIgCABIgBABIgBAAIgBABIgBAAIAAABIgBAAIgCABgAAMAhIAAAAIACgBIABAAIABgBIABAAIAAAAIAAgBIADgBIAAgBIABAAIABgBIAAgBIABAAIAAgBIgBAAIAAABIAAAAIgBAAIAAABIgBABIgBAAIAAABIgCAAIAAABIgCAAIgBABIgJAAIAAAAIAAgBIgCgBIgBgBIAAABIACACIAAABIABAAIABAAIABABIABAAIAAAAIABAAIABAAIACAAgAACAbIAAAAIgBgBgAADAEIgBABIAAABIABAAIAAABIgBAAIAAADIAAACIAAACIABgEIABgCIADAAIAAABIABgBIACAAIACgBIABAAIAAgBIAFgDIAAgCIACgBIABgDIAAAAIABAAIgBgCIAAABIAAABIgBABIAAABIgCABIAAAAIgCABIgBABIAAABIgBAAIAAABIgBAAIAAAAIgBABIgBAAIAAAAIgBAAIgBABIgBABIgBAAIgCgBIAAAAIgBgBIAAAAIgBgBIACgDIgCAAIgBAAgAAMgGIAAABIgBABIgBADIAAAAIgCABIAAAAIgCAEIABAAIABAAIACgBIAAgBIABABIABgBIABAAIAAgBIABAAIAAgBIAAAAIABAAIABAAIAAgBIABAAIAAAAIAAAAIAAgCIACgCIAAgCIAAgBIgDAAIAAAAIgCAAIgBABIAAAAIAAABIgBAAgAAFAAIAAAAIAAAAIABAAIAAgBIABgBIAAAAIABgDIABAAIABgBIAAAAIAAgCIABAAIAAAAIABAAIAAgBIACgBIAAAAIAAAAIACgBIAAAAIAAABIABAAIAAgBIABAAIABABIAAgBIgBgBIgCAAIgBgBIgBABIgBABIAAAAIgBABIgBABIAAABIgBAAIAAAAIAAAAIgBACIgBAAIAAAAIgBABIgBACIAAADIgBAAgAh3AjIgBAAIgBgBIgEAAIgBgCIgCgCIAAgBIAAgBIgBgDIAAAAIAAgCIAAgGIACgFIAAgBIABAAIAAgBIAAAAIAAgCIAAgBIABgBIAAgEIABAAIABgBIgBAAIAAgBIACgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIACAAIABgCIAAgBIACAAIABgBIABABIACAAIAAgBIACAAIAAABIAAAAIACABIACAAIAAABIADADIAAABIABAAIABADIABAAIABADIAAABIABAEIAAAAIAAACIAAAAIAAABIAAACIgBABIAAACIgCADIAAAAIAAABIgBABIAAABIAAAAIgBACIgBAAIAAACIgBAAIAAACIgBAAIgBAAIgCACIgBABIgBAAIgBABIgBABIgBAAIgBABIgBAAIgCABIgBABIAAABgAh3AgIAAAAIABAAIAAAAIABgBIgEAAIAAABIAAgBIgBABIAAAAIgBgBIAAAAIgBAAIgCgCIAAAAIADADIACAAIAAAAIABAAgAh4AFIAAACIAAABIgBABIAAAAIAAABIAAABIgBABIAAABIgBABIAAADIgBADIAAAHIABABIAAABIABAAIABAAIAAAAIABAAIADAAIAAgBIABAAIABAAIAAgBIACAAIABAAIAAAAIAAgBIABgBIAAgBIACAAIAAAAIAEgEIAAAAIABAAIAAgBIAAgBIAAgBIAAgBIABAAIAAAAIAAgBIAAAAIABgBIAAgBIgBgBIABgBIgBgBIABgBIAAgBIAAgBIAAAAIgBAAIABgBIgBgBIAAgCIAAgBIAAgBIgBgBIgBAAIAAgBIAAAAIgBgCIgBAAIgBgBIgCgBIgBAAIgBAAIAAAFIgDAAIgCAAIgBABIgBABIAAACIAAABIgBAAgAhuAcIAAAAIABgBIgBAAgAh/ARIABABIAAABIABgCIgBgBIAAAAIgBAAgAh5AAIAAAAIAAABIgBACIgBABIAAACIAAACIAAABIABgCIAAAAIAAgCIABgCIAAgCIABgBIABgBIADgCIACAAIAAgCIABgCIACgBIABAAIgBAAIAAAAIgBAAIgCAAIgDACIgCABIAAABIgBACIAAABIAAAAIAAABIgBAAgAhnAAIABAAIAAAAIABACIAAACIABACIAAAAIAAABIABAAIgBgDIAAgBIgCgDIgBgCgAhugHIADABIABAAIACABIgDgCIgBAAIgCgBgACbAhIgBAAIAAgKIAAAAIAAgCIAAgBIAAgCIAAgBIAAAAIAAgEIAAAAIAAgDIAAAAIAAgBIAAgBIAAgBIAAgHIgBAAIgBAAIAAAAIABgBIgBgEIAAgBIgBgBIAAgBIAEgCIABAAIABABIAAABIABABIAAABIAAACIAAAGIAAABIAAABIAAACIAAAAIAAABIAAACIAAAAIAAABIAAABIABgBIAAAAIAAgBIABgBIAAgBIAAAAIABgBIABgBIAAgBIABgBIABgBIAAgBIAAAAIABAAIAAgBIACAAIAAAAIABgBIAAgBIAAAAIABAAIACgCIABAAIABgBIAAAAIAAgBIABAAIACgCIACAAIADAAIABgBIABABIABAAIAAABIAAACIgBAAIgCABIgCABIgBAAIgBAAIgBABIAAAAIgBABIgBABIAAAAIAAAAIgBAAIgCABIgBABIAAAAIgBABIgBABIAAAAIgCADIAAAAIAAAAIAAABIAAACIgBAAIgBAAIAAABIAAABIgBABIAAAAIAAABIgCABIAAACIABABIgCAAIABAAIgCAEIAAABIABAAIgBAAIAAACIAAADIABACIAAAAIAAABIgBACIgBAAIAAABgACcAWIAAAIIACABIAAAAIAAgBIAAAAIgBAAIAAgGIABgBIgBgBIABgBIAAgDIAAAAIAAgBIABgBIAAAAIgBgBIgBAAIAAgBIgBgCIAAAFIABAAIgBABIAAADIAAAAgACcALIABAAIgBAAgACcADIAAAAIAAAAIgBgHIABgCIgBgBIAAgBIgBABIAAACIABADIAAACIABADgAiLAhIgBgBIgBAAIgCgEIgBAAIgBgFIgBgCIAAgEIAAgBIAAAAIAAgBIABgCIgBgBIAAgFIgBgBIABgCIgBAAIAAgBIAAgBIABAAIgBgCIAAgCIgBgBIAAgCIAAgBIAAgBIgIAJIAAACIgDADIgEACIAAACIgBABIgBAAIAAABIgCACIgBABIAAAAIgBABIgDAEIgBAAIAAACIAAAAIgBAAIAAABIgBAAIAAgBIgCgCIAAgCIgBgBIABgBIgBgCIgBgBIgBAAIAAgBIgBgBIAAgBIgBgBIAAgBIgBgBIAAgBIgBgDIgCgCIAAgBIgBgBIgCgBIgDgFIgBAAIAAABIgBAFIgCADIABACIgBACIgCAGIAAABIgBABIgBACIAAAAIgBADIgBADIABABIgBABIgBAEIACABIgDACIgBABIgCAAIgBgBIAAgBIgBgBIABgBIABgFIABgBIABAAIAAgCIAAgCIABgCIAAgBIABgCIAAgBIAAgCIABgBIAAgCIABgCIABgGIgBgBIAAgBIABgBIAAAAIABgHIAAgBIgBgDIAAgBIAAAAIAAgBIAAgBIABgBIAAgBIABAAIABgBIACAAIABACIABAAIAAABIAAAAIAAABIABACIAAAAIABABIABAAIgBACIABAAIABABIABAAIAAABIABACIABAAIAAACIAEAFIABABIABACIACAEIADAFIAAACIACAAIABgDIAEgDIAAgBIAAAAIACAAIAAgBIABgBIAAgBIAAgBIABAAIABgBIAAgBIADgBIABgBIABgCIABgBIABAAIABgDIAAgBIABAAIABAAIACgEIABAAIABAAIAAgDIgBgBIAAgBIABgCIAAgCIABAAIACABIAAAAIAAAAIABAAIAAAAIAAABIABACIACABIAAAEIAAAAIABABIgBABIAAABIABAAIAAACIABAAIgBABIAAABIAAACIAAACIAAABIABAHIgBABIAAABIABAAIAAABIAAABIAAABIgBAAIABABIAAAFIABADIAAAEIAAABIAAABIABABIABABIABABIAAABIAAABIgBABIgBAAIAAABgAiPANIgBACIAAAFIABACIABAAIABAFIACACIgBAAIAAgBIgBgBIAAgBIAAgEIgBgDIAAgGIgBAAgAivASIAAAAIAAAAIAAACIACgBIABgDIgBAAIAAACIgCgBgAjKAQIAAACIABgCIAAgBIACgJIABgBIgBgCIgBAEIgBABIAAADIAAACIAAACgAiqANIgBACIAAAAIACAAIABgCIACgBIAAgCIAAAAIABAAIAAgBIABgBIAEgDIACgDIABgCIAAAAIAAAAIACgBIgBgBIAAAAIgBABIAAABIgBAAIgBAAIgBACIAAACIgCABIAAABIgBAAIAAAAIgBABIgBABIgBAAIAAABIAAAAIgBACIgBABIAAAAgAiUgQIAAAAIAAAAIABADIgBAEIAAAAIACABIAAACIAAACIABACIAAACIABACIAAAAIgBABIAAAAIABABIAAAAIgBABIABABIAAACIAAACIAAABIAAACIACgCIAAgBIgCgCIACAAIAAgBIAAgCIAAgBIgCgEIAAgCIAAgBIAAgBIgBAAIABgCIAAAAIAAgBIAAgBIgBgBIAAAAIgBgBIABgBIAAgFIgBAAIAAgCIgBAAgAi5AAIAAAAIABAAIABACIgBgCIgDgCgAjFgQIgBABIACAEIgBAEIAAAEIgBABIAAABIAAAAIAAABIAAABIACgCIABgEIAAgDIABAAIABAAIAAAAIACABIADADIgBgCIgBgBIAAgBIAAgBIgBAAIgBAAIAAAAIgBgBIAAgCIgBgBIAAgCIgBgBIAAAAIAAgBIgBAAIAAAAIgBAAgAibgDIAAABIAAABIAEgGIAAAAIACgCIAAgBIgBAAIAAACIgCACIgBAAIAAAAgABTAgIAAABIgDgBIAAAAIgBAAIAAAAIgBAAIgCgBIgBAAIgBABIAAAAIgBgBIAAAAIgBAAIgCgCIgBgEIAAgBIABAAIABAAIACgCIABABIAAAAIABABIABABIAAACIACAAIAAAAIAQgBIAAgBIABAAIABgBIABAAIADgBIAAAAIAAgBIgBAAIAAgBIgBAAIgBgBIgBAAIAAgBIgBAAIgBgBIgCAAIgBgBIgCAAIAAAAIAAAAIgBAAIgBgBIAAAAIgBgBIgCgBIgBAAIgBgBIgDAAIgBAAIAAgBIgCgCIAAAAIgBgDIgBgBIAAgBIAAgFIAAAAIAAAAIAAgBIABgCIABgCIAAgBIABAAIADgDIAGgCIAGgCIAAAAIAEABIABAAIAAAAIABABIABABIABABIAAABIAAABIAAABIgBABIgCABIgBgBIgBgBIgBAAIAAAAIgBAAIAAAAIgBgBIgEABIAAABIgCAAIAAAAIAAABIgBAAIgBAAIgCABIAAABIAAAAIgCABIgBABIgBAAIAAADIAAACIABABIAAABIADABIAAAAIAAAAIABABIACAAIABABIACABIAAAAIABAAIAEACIABAAIABABIABAAIABAAIABABIAAAAIACAAIACABIABACIABABIgBAAIABAAIABABIgBABIABAAIAAABIAAABIgBABIAAABIgBACIAAABIAAABIgCAAIgBACIgEAAIgBABIgBgBIAAAAIAAABIgBAAIgCAAIgBAAIgFAAIgBABgABUAeIABAAIABAAIAGAAIABgBIABAAIABAAIAAAAIAAAAIABAAIABgBIAAAAIABAAIACgBIAAAAIABgBIgBAAIgEABIAAAAIgBAAIAAABIgBAAIgDABIAAAAIgLABIACAAIABAAIAAAAIABAAgABHAcIACABIABAAIAAAAIABAAIgBAAIAAgCIgBAAIAAgBIgBABIAAgBIgBAAgABlAaIABAAIABgCIAAgBIAAgBIgBgBIAAABIABABIgBAAIAAABIgBAAgABXAOIAAAAIABAAIABAAIAAABIACAAIABAAIACABIACAAIAAABIAAgBIAAAAIgCAAIAAgBIgCAAIgEgCIAAAAIgBAAIgBAAIgCgBIAAAAgABMACIAAgCIAAAAgABOgDIgCABIAAACIABgBIABAAIAAgCIABAAIABgBIACgBIABgBIAAAAIABgBIABAAIABAAIABgBIABAAIACAAIAAgBIACAAIABAAIAAABIAEAAIgBgBIAAgBIgBAAIAAAAIgDAAIgGABIgEACIgDACIAAACIgBAAgABhgIIAAABIAAgBIAAAAgAArAgIgBABIAAgBIgBAAIgBAAIAAAAIgBAAIAAAAIgBAAIgCgBIgBAAIgBABIgBAAIgBgBIAAAAIgBAAIgBgCIgBgEIAAgBIACAAIAAAAIABgCIABABIABAAIABABIAAABIABAAIAAACIACAAIAAAAIABAAIAPgBIAAgBIABAAIABgBIACAAIABgBIAAAAIAAgBIgBgBIAAAAIAAgBIgCgBIgBAAIAAgBIgDAAIgCgBIgBAAIAAAAIAAAAIgBAAIAAgBIgBAAIgBgBIgDgBIgBgBIgDAAIgDgDIgBAAIgBgDIgBgBIAAgHIABgCIACgCIAAgBIABAAIADgDIAAAAIAGgCIAFgCIAAAAIAGABIAAAAIABAAIAAABIAAABIABABIAAABIAAABIAAABIgBABIAAABIgCgBIgBgBIgCAAIAAAAIgBAAIAAAAIgBgBIgBABIgCAAIAAABIgBAAIgBAAIAAABIgCAAIAAAAIgCABIAAAAIgBABIgBABIAAABIgBAAIgBAAIAAADIAAAAIAAACIABABIAAABIACABIAAAAIACABIACAAIABABIACABIABAAIAAAAIADACIABAAIAEABIAAAAIABABIABAAIADABIAAACIACABIAAAAIABABIAAABIAAAAIABABIAAABIgBAAIAAABIgBABIAAACIgBAAIgBABIAAABIgCAAIgBACIgDAAIAAAAIAAABIgCgBIAAABIgCAAIgBAAIgBAAIgGAAIgBABgAAsAeIABAAIABAAIAFAAIABgBIABAAIACAAIAAAAIAAAAIABAAIABgBIAAAAIABAAIABgBIAAAAIABAAIAAgBIgBAAIgCABIgBAAIgBABIAAAAIgFABIAAAAIgKABIABAAIABAAIAAAAIABAAgAAfAcIABABIABAAIAAAAIABAAIAAAAIAAgCIgCAAIAAgBIgBABIAAgBIAAAAgAA9AZIgBABIABAAIABgCIAAgBIAAgBIAAgBIAAAAIgBABIAAAAIABAAIAAABIgBABIAAAAgAAvAOIAAAAIABAAIABAAIABABIABAAIADABIACAAIAAABIAAgBIAAAAIgBAAIgBgBIgCAAIgBAAIgDgCIAAAAIgBAAIgBAAIgBgBIgBAAIgBAAgAAmgDIgCABIgBACIAAACIABgCIABgBIABAAIABgCIAAAAIABgBIAAAAIAAgBIABAAIABgBIAAAAIABAAIABgBIAAAAIACAAIADgBIAAAAIABgBIAAAAIABAAIACABIAEAAIAAgCIgCAAIAAAAIgEAAIgCAAIAAAAIgCABIgGACIgBACIgBACIgBAAgAA5gIIAAABIABgBIgBAAgAC/AgIgDgCIgCgDIAAgHIABgIIAAgHIABgCIAAgCIgBgBIAAAAIABAAIAAgHIgBgBIABgBIACgBIAAAAIABABIAAgBIABAAIABAAIAAABIAAABIABAAIABABIgBABIAAABIgBAFIAAABIAAACIAAABIAAAAIAAABIAAABIgBADIAAABIAAAAIAAADIAAADIgBABIAAABIAAADIABADIAAABIABAAIAAAAIABgBIABAAIAAAAIACgBIABAAIABgBIABgBIABAAIABgBIAAAAIAAgBIAAgBIABAAIAAAAIACgBIAAgCIAEAAIAAABIABABIAAAAIgBACIgBABIAAABIgBAAIgBAAIAAACIgBABIgBAAIAAAAIgCACIAAABIgBAAIgCABIgBABIAAAAIgBABIgDABIAAAAIgCAAIgBABgAC8AUIAAABIAAAFIACADIABABIABgBIABAAIAAAAIACgBIAAAAIADgCIABAAIAAgBIABAAIABgBIABgBIAAAAIAAAAIAAAAIgCAAIgBABIAAAAIgBABIAAAAIgBABIgBAAIAAAAIgBAAIAAABIgCAAIgCAAIgBgBIgBAAIAAgBIABAAIgCgEIAAgBIABgCIgBgBIABgBIAAgDgADLAWIABAAIgBAAgAC+AEIAAAAIAAABIgBABIABAGIAAgCIAAgBIABgEIAAgCgAC/gEIAAABIgBABIAAACIABADIAAgBIABgBIgBgBIABgGIAAAAIAAAAIAAgBIgCAAIABACIgBAAgAhVAgIgBgBIgBgCIAAAAIgBgCIAAAAIABgCIAAgDIgBgCIAAAAIAAgBIABgBIAAgGIgBgBIABgBIAAgBIAAAAIABgEIgBAAIAAgCIAAAAIAAgBIAAgCIAAgBIAAAAIAAgCIAAgCIABgDIADABIAAABIAAABIABABIAAABIAAABIAAABIAAABIAAADIAAABIAAACIAAAEIgBABIABABIAAABIgBABIAAABIAAABIABABIgBADIAAADIAAAAIABgCIAAAAIAAgBIABAAIAAAAIAAgBIACgBIAAAAIABgBIAAgBIABgBIAAgDIABAAIABgBIABAAIAAgBIACgFIAAAAIABgCIABAAIABgBIAAgCIABAAIAAAAIAAgCIACAAIAAgBIACgCIAEgEIABAAIABACIABAAIAAAAIAAABIAAAAIABACIAAAAIABABIgBACIABACIAAADIADANIAAAAIAAACIABABIAAABIABABIAAABIAAABIABAAIAAgBIABAAIAAAAIABAAIABgBIACgBIAAgBIABAAIAAgBIABAAIABgBIABgEIACgBIADAAIAAAEIgBAAIgBABIgBACIAAABIgBABIAAABIgBAAIAAABIgBABIgBABIAAAAIgBABIAAAAIAAABIgCAAIgBABIgBAAIgCABIgBgBIAAABIgBAAIAAgBIgBAAIgCgCIgCgDIgBgBIAAgCIAAAAIAAgBIAAgBIAAgCIAAgCIgBgCIAAgDIgBgJIAAAAIgBgBIAAAAIAAAAIAAgBIgHAJIAAABIgBABIgBABIAAABIAAACIgBABIAAAAIAAAAIgCAAIgBACIAAACIgBABIgBACIgBABIgBACIgEAEIAAABIgBABIgBAAIgCABgAhVAZIAAABIAAABIAAABIAAABIAAABIABAAIABgBIAAgCIABAAIAAgBIAEgDIABgCIAAAAIAAgBIABgBIAAgBIABgBIAAAAIAAgBIACgCIAAAAIAAgBIABAAIAAgCIAAAAIAAAAIgBABIAAABIgBAAIgBABIAAABIgBADIgBABIAAABIgCAAIAAABIAAABIgCAAIAAACIAAABIgCAAIAAAAIgBABIgBgBIAAgBgAg4AMIABACIgBACIABACIAAACIABAAIgBABIABABIAAABIAAAAIABACIABAAIAAAAIAAABIABABIABAAIACAAIAAAAIABAAIABgBIAAAAIABAAIAAgCIABAAIABgBIgCAAIAAACIgBAAIgBAAIgBABIAAAAIgBAAIAAAAIgCgBIgBAAIAAgBIgBAAIABgBIgBgBIAAgBIgBgBIAAgBIAAgBIgBAAIAAgEIgBgDIAAAAgAgrAXIABAAIABAAIAAgBgAhVARIAAAFIAAAAIAAgEIAAgCIAAAAgAgoAUIgBAAIAAABIABAAIAAgCgAgnASIABgBIgBAAgAhVANIAAACIAAgCIAAAAIAAgCIAAABIAAAAgAg6gDIAAABIAAABIABABIgBAAIAAAAIABABIAAAAIABAJIAAgDIgBgDIAAgDIAAgCIAAgBIgBgBIAAAAIAAgCIAAAAIgBAAIAAgBIgBAAIgBABIAAAAIAAAAIAAABIgBABIAAABIACgCgAhDABIAAABIgBACIgBABIAAABIgBADIgCABIABAAIABgBIABgBIACgFIADgDIABgBIAAgBIgBAAIgBAAIAAACIAAAAIgBAAgAhVAFIAAAAIAAAEIAAABIABgBIAAgEIAAgCIAAgEIAAgBIgBgBIAAgCIAAAAgAgPAfIgEABIgCgBIAAAAIgEgCIAAAAIgDgEIgCgEIAAgBIgBgEIAAgCIAAgBIAAgBIAAgCIAAAAIAAgBIAAgGIAAAAIAAgBIAAgCIAAAAIgCAAIAAAAIgCAAIgBAAIgBgBIgBgCIAAgBIgBgBIABAAIAAgBIAAgBIAIAAIAAgCIgBgDIABgBIgBAAIAAgBIABgDIgBgBIAAAAIAAgBIAAAAIAAgBIAAgBIAAgCIABgBIAAgCIADACIACABIAAAIIAAABIAAACIAAABIAAACIAAABIAAABIAAAAIAAABIABAAIAAAAIABgBIASAAIACACIgBACIgBABIgBAAIgBAAIgBAAIgBAAIgCAAIgCABIgDAAIgCABIgCAAIgBAAIAAAAIgCAAIgBAAIgBAAIAAAAIgBAAIgBALIABAFIAAACIABADIAAAAIABACIABABIABABIABABIADABIAFgBIABAAIADgCIACAAIACACIAAABIgBABIgBACIgCAAIAAABIgEAAIgBABgAgYAbIADACIABAAIACABIABAAIACgBIABAAIAAAAIABAAIAAAAIACgBIACgBIACAAIgBAAIgBAAIgDABIgBAAIgEABIgBAAIgDgBIgBgBIgCgBIAAAAgAgdgBIABABIAAAAIABgBIABgBIACAAIAAAAIABAAIABAAIABAAIAAAAIACgBIABgBIgFAAIAAAAIgBABIgDAAIgBgDIAAACIgFAAIgBgBIgBABIgBABIAAAAIACAAIABABIABAAIABAAIAAAAIABAAgAgdgVIABABIgBABIABABIAAAEIAAAAIABgCIAAgEIgBgCIAAAAIAAAAIgBgBIAAAAgAC4gRIAAgBIAAgCIAAAAIACgCIABgBIABgBIAAgBIABAAIgBgCIADAAIAAgBIABAAIAAgBIABAAIAAgBIAAgBIABgBIABgBIAAAAIAAgCIACABIACABIABACIAAABIAAABIgBABIAAAAIgCACIgBAAIgDAEIAAAAIgCABIgBABIAAABIgCAAIgCACgADBgaIAAABIABgDIABgBIABABIAAgBIAAgBIABAAIABgBIgBgBIAAAAIgBABIAAACIgBAAIAAAAIgCACIAAAAg");
	this.shape_343.setTransform(211.05,124.025);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#3F4096").s().p("AALAiIgBABIgCgBIgBAAIgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAgBAAAAIAAgBIgCgBIAAgBIgBgBIAAgBIAAgFIAAgFIAAgCIAAgCIAAgBIAAgBIABgBIAAgDIAAAAIAAgCIAAgBIAAgDIAAgBIABAAIACAAIAAAAIABgBIACgFIAAgBIABAAIAAgBIABAAIABgCIADgDIAAABIABgCIACAAIAAAAIABAAIABABIAAAAIACABIABAAIAAACIABADIAAABIAAADIAAAAIgBADIgCACIAAABIgGAEIAAABIgBAAIgCABIgBAAIgCABIgDgBQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAIgBABIAAADIgBAAIABAEIgBAAIAAACIABAEIABACIADABIAAAAIAFABIADAAIACgBIAAgBIABAAIAAgBIADgBIAAAAIABgBIAAgBIACgDIABAAIABABIgBACIgBADIgBAAIgBACIgDACIgBABIgBAAIAAABIgCAAIAAABIAAAAIgCABgAAHAAIgCADIABABIABABIADgBIAAgBIABAAIABAAIABAAIABgCIAAAAIAAAAIADgBIABgBIACgEIAAgBIgBgDIgCAAIgBAAIgBAAIgCABIgBABIAAgBIgBABIAAAAIAAAAIAAABIgBABIgBAAIgBAEIgBAAgAB5AhIAAABIgCgBIgDAAIgCgEIAAgBIgBgDIAAgCIAAgDIAAgBIAAgCIABgCIAAgBIACgEIAAgDIABgCIgBgCIABgBIABgBIAAgBIAAAAIABgBIAAgCIACgBIAAgCIAEgDIAAAAIABAAIADAAIACgBIAAABIACABIABAAIADADIABABIABAAIABADIACADIAAABIAAAEIAAACIAAABIAAACIgBABIAAABIAAADIgBABIgBACIgBAAIAAABIgBABIgBACIgBABIAAABIgBAAIgBACIgGACIgBABIgBAAIgCABIgBACgAB/gFIAAADIgCABIgDABIgBABIAAACIgBABIgBABIAAACIgBABIAAACIgBABIAAABIAAABIAAABIgBABIAAACIgBADIABAAIAAADIgBACIAAACIADADIAAAAIACAAIABAAIACAAIABgBIAAAAIABAAIACgBIABABIAAgBIABAAIABgBIABgCIABAAIABgBIACgCIAAgBIACgBIABgCIAAgBIABgBIAAAAIABgCIgBAAIABgBIgBgBIAAAAIABgCIAAgCIgBgBIABAAIgBgBIABAAIgBgCIAAgCIgBgBIgBgBIAAAAIAAAAIgBAAIABgCIgBgBIgBAAIAAgBIgFgDQgBAAgBAAQAAAAgBAAQAAABAAAAQAAABAAAAgAh4AhIAAABIgBgBIgEAAIgCgEIAAgBIgBgDIABgCIgBgDIABgBIgBgBIAAgBIABgCIAAgBIABgCIAAAAIABgCIAAgDIABgCIAAgDIABgBIAAgBIABAAIABgBIAAgCIABgBIAAgCIAEgDIABAAIABAAIACAAIACgBIAAABIACABIACAAIAAABIABAAIACACIAAABIABAAIADAGIAAABIABAEIgBACIABABIgBACIAAABIAAABIgDAGIAAAAIgBABIgBABIgBACIgBABIAAABIgBAAIgBACIgBABIgCAAIgEACIAAAAIgDABIgBACgAhygFIABADIgCABIgDABIgBAAIgBABIAAACIgBABIAAADIgBABIgBADIAAABIgBABIAAABIgBABIABACIgCADIABAAIAAADIgBACIAAACIAEADIABAAIABAAIACAAIABgBIABAAIABAAIABgBIABABIAAgBIABAAIABgBIABgCIABAAIABgBIACgCIABgBIABgBIABgCIAAgBIABgBIAAAAIABgCIAAgCIAAgCIAAAAIAAgCIAAAAIAAgBIAAAAIgBgDIAAgCIgBgBIgBgBIAAAAIAAAAIAAgCIgBgBIgBgBIABAAIgFgDIgBAAQgBAAAAAAQgBAAAAAAQAAABgBAAQAAABAAAAgACdAfIAAABIgCAAIAAgKIgBgBIABgBIAAgKIgBgBIABgBIgBgBIAAgDIAAgBIAAgBIAAgCIgBAAIABgCIgBgDIAAgCIgBAAIADgCIAAABIABABIAAADIABAGIAAABIAAAHIABABIgBAAIABADIAAAAIAAgCIADgEIAAAAIABgBIABgDIABgBIABAAIAAgBIABgBIAAgBIABAAIACgBIAAAAIADgDIABAAIABgBIAAAAIAEgCIABAAIABAAIABgBIACABIgBABIgCAAIgCACIgDAAIgBABIgCACIAAABIgBAAIgBABIgBAAIgBABIgBABIgBAAIAAACIgCADIAAAAIAAABIgBAAIgCAEIgBAAIAAAEIgBAAIAAABIgBADIAAABIAAACIAAAEIAAABIABABIgBACgAiMAeIgDgCIgBgGQgBAAAAgFIAAgBIAAgEIAAgBIAAgFIgBgBIABgCIgBAAIABgBIgBgCIAAgDIgBgBIAAgCIgCgCIgBABIgBABIgGAHIgBACIgCADIgEADIAAABIgCABIAAABIgCABIgBACIgBABIgDAEQAAAAAAAAQAAAAgBAAQAAABAAAAQAAABAAAAIgBAAIgBgCIAAgBIgBgBIABgBIgBgBIAAgCIgCgDIgFgIIgCgCIAAgBIgCgBIgCgEIgDgCIgCAAIAAABIAAAGIgCACIAAACIgEANIgCAFIAAADIgCAEIABAAIgCADIgBgBIAAgCIABgFIABgBIAAgDIACgCIAAgCIABgCIgBgBIACgDIAAgCIACgIIgBgBIABgCIABgBIAAgIIgBgDIABgBIgBgBIABgBIABAAIABAAIABABIAAAAIACABIAAACIABACIAAAAIAAAAIACACIABABIAAABIABABIABACIAEAFIABACIABABIABAEIADAFIADAEIAAgCIACAAIABgCIACgBIABgCIAAgBIAEgCIAAgCIABAAIABgBIAAAAIABAAIgBgCIAEgBIAAgBIABgDIABABIAAgBIACgDIAAAAIABAAIACgEIABgBIABAAIAAgBIAAgCIgBgCIACgDIADABIAAACIABABIAAAEIABAAIgBACIABAAIAAABIAAAAIAAACIABAAIgBACIAAAAIAAACIABACIgBABIACAHIgBABIAAACIABAAIgBACIAAAAIAAAGIABADIAAAEIABABIABACIABABIABACIgBABgAC9AdIgCgDIAAgGIAAAAIABgJIAAAAIAAgEIABgFIgBgCIABAAIAAgDIAAgBIAAgCIAAgBIAAABIAAgCIAAgBIABABIABgBIABAAIAAACIABAAIAAABIgBAGIAAABIgBACIAAACIgBAEIAAAGIAAACIAAADIAAAFIAAAAIABABIABAAIABAAIAEgCIAAgBIADgBIACgBIAAgBIABAAIAAgBIABAAIAAAAIACgBIAAgCIACABIAAAAIAAABIgDACIgBACIgBABIgBABIgCACIAAAAIgCABIgBACIgEAAIAAABIgCAAIAAABgABYAeIgBABIgCAAIgBgBIgBABIgBAAIgCgBIAAABIgCgBIgDAAIgBAAIgBAAIAAAAIAAgBQgDAAAAgEIACAAIgBgBIABgBIAAABIABAAIAAABIABgBIAAABIAAABIABAAIAAACIACAAIABABIAAgBIAMAAIAEgBIAAgBIACAAIAAAAIAEgCIAAgBIABAAIAAgBIgBAAIABgBIgBgBIgBAAIgBgBIAAAAIgBgBIgCAAIgBgBIAAAAIgDgBIgBAAIgBgBIgBABIAAgBIgBAAIgDgCIgBgBIgEgBIAAAAIgCgCIgBgDIgBgCIgBgEIABAAIABgDIABgCIABAAIACgCIABgBIAFgCIADgBIADgBIAEAAIAAABIAAAAIABABIAAABIACABIgCADIgBgCIgDAAIgCgBIAAAAIgBABIgDAAIgCABIgBAAIgBABIgCABIgCABIgBADIgBAAIgBADIABAAIAAABIABADIAAAAIADACIAAAAIACABIACAAIABABIACAAIAAABIAEABIABABIACAAIACABIABABIACAAIABABIABACIAAABIABAAIAAAAIAAAAIABACIgBABIgBADIgBABIAAABIgBAAIgBABIgCAAIgBAAIgBABIgBAAIgBAAIgFAAIAAABgAAvAeIAAABIgCAAIgBgBIgBABIgBAAIgCgBIgBABIgBgBIgEAAIAAAAIgBAAIgBAAIAAgBQgCAAAAgEIABAAIAAgBIABgBIAAABIAAABIABgBIABABIAAABIABAAIAAACIACAAIABABIAAgBIAMAAIAEgBIAAgBIABAAIABAAIADgCIABAAIAAgBIABAAIAAgBIgBAAIAAgBIgBgBIAAAAIgBgBIgBgBIgCAAIgBgBIAAAAIgDgBIgBAAIgBgBIgBABIAAgBIgBAAIgEgCIgBgBIgDgBIAAAAIgCgCIgCgDIgBgCIAAgEIAAAAIABgDIACgCIABAAIABgCIABgBIAGgCIADgBIACgBIAEAAIABABIABABIAAABIABABIAAACIgBABIgBgCIgDAAIgCgBIgBABIgDAAIgCABIgBAAIgBABIgEACIgBADIgBAAIgBADIAAAAIAAABIACADIAAAAIACACIABAAIABABIACAAIABABIACAAIAGADIADABIABABIACAAIACABIABACIAAABIAAAAIABAAIAAAAIABACIgBABIgBADIgBABIAAABIgBAAIgCABIgBAAIgBAAIgBABIgBAAIgCAAIgEAAIAAABgAhXAbIAAgBIAAgCIABAAIgBgBIAAgCIAAgBIAAgBIAAgCIABgEIAAgBIgBgBIABgBIAAgBIAAgEIAAgBIAAgBIgBgBIABgCIAAgBIAAgDIAAgCIAAgBIACABIAAABIAAABIABADIAAABIAAADIAAACIAAAEIgBABIABACIgBADIAAABIAAAEIAAAEIABgBIABAAIABgCIABgBQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAAAAAIABgBIACgEIAAgCIACgBIABgBIADgFIgBgBIABAAIACgDIAAgBIABAAIAAAAIAAgBIABAAIACgDIABAAIAAgCIADgBIAAgBIABAAIABABIAAABIABAAIAAACIABABIgBACIABACIAAACIABAHIABADIAAAEIABABIAAACIABAAIAAABIABABIgBABIABAAIAAABIACABIABgBIAAABIABgCIABAAIAAgBIACgBIACgBIAAgBIABgBIACgEIACgBIABAAIAAACIgBACIAAAAIgDAEIgBAAIgBADIgBABIgBAAIAAACIgFABIgCAAIAAAAIgBAAIgDgGIAAgBIgBgBIAAgCIgBgBIAAgDIAAgCIAAgCIgCgJIAAgBIgBgDIAAAAIgGAGIgCADIgBADIgCABIABABIgBACIgBAAIAAABIAAAAIgCADIgBACIgBABIgBABIgCADIgCACIgBACIAAABIgBAAIgCACgAgPAdIgEABIgDAAIgDgCIgCgDIgCgFIgBgEIAAgDIAAgBIAAgBIAAgBIABgBIgBgBIAAgIIAAgBIgBABIgBgBIgBABIgCgCIgBAAIgBgCIAAgBIAAAAIAAgBIADAAIABAAIAEAAIAAgEIgBgCIABAAIAAgBIAAgBIAAgDIgBgCIAAgBIgBgBIACgDIADABIgBABIABADIAAAEIgBABIABACIgBAEIABAAIgBABIABACIABAAIABgBIATAAIAAABIgBABIgGAAIgDABIgCAAIgBACIgBAAIAAgCIgBACIgBAAIAAABIgDgBIgBABIAAgBIgCABIgBAEIABADIgBAHIABADIAAABIABACIAAABIACAEIABABIACABIADABIAFgBIABAAIADgCIABABIABABIgBACIgBgBIgBABIgDAAIgBABgAC5gSIAAgCIACgBIABgDIABAAIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAgBIABAAIAAgBIABgBIABgBIAAgBIABAAIAAgBIABgCIADADIgCACIAAABIgBABIgBAAIgCADIgBABIgCAAIgBACIgBABIgCACg");
	this.shape_344.setTransform(211.075,124.05);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#EE3338").s().p("AjZA0QgFgFAAgJQgBgIAGgGIAAgBIgEgEIgCgEQAAgGAMgEIAAgBQgGgCgCgEIgCgKQAAgIAEgGQAFgFAGAAIADAAIABgDIAFgIQADgEAEAAIAGACIAAABIAAAMIgBABIAAgBIgBgCIgEgBIgEABIgBADIAAABIAFAHIADAKQAAAMgNAHIgFADQgEACgBABQAAAAABAAQAAABAAAAQABAAAAAAQABABABAAIAEAAQAJACAFAFQAEAEAAAKQAAAKgGAFQgHAGgHAAQgHAAgGgFgAjTAeQgCADAAAEQAAAEADACQADAEADgBQAEAAACgDIADgHQAAgJgJAAIgBAAQgDAAgDADgAjRgSQgCACgBAEIADAGIAGACIAFgCIACgGIgDgGQgBgCgEAAgAipAbIACgGIgBgCIgEgEIgBgFIACgHIAFgCQAEAAACADIABAHIgEAMIgGAFgAhKAVIgFgJIgCgMIgBgaIAAAAIAMgDIgBAVQAAATAGAAQAGAAAAgVIgBgUIALgDIAAABIAAAgIgBAIIgDAJIgGAFIgHACgABAAYIgFgJIAAAAQgIAGgFgBQgIgBgDgEQgEgFAAgJQABgIAHgJIABAAIgBgBIgDgIQgEgHABgHQAAgHAFgGQAFgEAGAAQAHAAADAGQAFAGgBAIIgBAGIgCAEIgDAEIgHAHIAAABIAIAOIABAAIAGgNIAHAHIAAAAIgIAOIAFAIIAAABIgEAHgAAngDIAAAGIABAGIAGACIAEAAIAEgEIAAgBIgLgPgAArgrIgDAHIABAFIACAFIADAFIABAAIABgBIAEgGIADgIIgBgGIgFgDgAgOAXIABgaIgBgHIgBgDIgBgCIgDgBIgDACIgDAEIgBAGIgCAXIAAABIgJAAIACg4IABAAIAKgBIAAAIIAGgBQAEAAACACIAGAHIACAVIgBAWIAAABIgJAAgAj0ABIgBgLIgBgDIgBgCIgCgBIgEACIgDAEIgCAdIgBABIgIAAIACg4IAKgBIAAABIAAAHIAAAAIAHgBQADAAAEACIAEAHIACAVIgBAWIAAABIgIAAgACvAQIAAgBQgFAEgEAAQgEAAgEgEQgEgDABgHQgBgGAFgEQAEgEAGAAIAGABIAAAAIAAgDIAAgFIgEgCQgHAAgGAGIgBgBIgCgKQAHgIAJAAQAHAAAFAFQADAGAAAJIgCAfIAAABIgJABgACkAFIABADIADABIAFgCIACgFIgBgCIgCAAQgJAAABAFgAh8AVIAAAAIAChIIAhABIAAABIgCANIgBABIgUgBIAAATIAPgBIAAAAIgBAOIAAAAIgOAAIAAABIAAAZIAAAAgADJAUIgCgxIAAgBIAGgCIABABIABAFIAFgEIAHgCIAHACIABABIgDAOIgBAAQgDgEgEAAQgEAAgCAGIAAABIACAeIAAABIgLACgABvALQgHgKAAgOQAAgRAKgKQAJgLAOAAIAIACIABABIgDAPIgBAAIgGgCQgIAAgGAGQgGAGABAKQAAATARAAIAFgBIAAABIABAMIAAABIgEABIgGABQgLAAgIgKgADwAMQgFgHAAgJQgBgKADgIQAFgJAHgBQAJgBAFAHQAFAHAAALIAAAEIgVACIgBAAQAAAFADACIAHACIAHgEIAAABIADALIAAAAQgFAEgHAAQgJAAgFgHgAD8gVIgFADIgBAHIAAAAIAMgBIAAAAQgBgJgFAAIAAAAg");
	this.shape_345.setTransform(256.15,136.8725);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#EE3338").s().p("AipAxIgBgBIgBAAIgDhcIALgEIABABIAAAuIABAAQAFgIAHAAQAFAAAEAFQAEAFAAAHIgBAVIgEASIgBABIgIgDIgBgBIAEgaQAAgOgFAAQgDAAgDADQgDAEAAADIgBAiIgBABgAkoAtIgFgKIgCgLIgBgaIAAgBIAMgCIAAAAIgBATQAAAVAGAAQAGAAAAgWIgBgTIALgDIAAAAIAAAfIgCAKIgCAIIgFAGIgIACQgFAAgDgDgAE6AuIABgWIgCgMIgBgDIgBgCIgCgBIgEACIgDAFIgDAeIAAAAIgIAAIgBAAIABgKIABgtIABgBIAKgBIAAAJIAGgCQAEAAADADIAFAFIADAXIgCAWIAAAAIgIABgAhKAuIABgaIgBgIIgBgDIgCgCIgCgBIgDACIgDAFIgBAFIgCAZIAAAAIgJAAIAAAAIACg4IALgBIAAAJIAGgCQAEAAADADIAFAFIADAXIgCAWIAAAAIgIABgAjrAUIgBgIIgBgDIgCgCIgCgBIgEACIgCAFIgBAFIgCAZIAAAAIgJAAIACg3IAAgBIAKgBIABABIgBAHIABABIAAAAQADgCADAAQAEAAADADIAEAFIADAXIgBAWIAAAAIgJABgABBAMIAAgBIgIAAIAAgJIABAAIAGgBIABAAIAAgRQAAgJAEgFQAEgGAHAAQAFAAADADIAFAIIABAEIgBABIgGAFIAAAAIgBgEIgCgEQAAAAAAgBQgBAAAAAAQgBgBAAAAQgBAAAAAAIgDACIgDAEIAAATIALAAIABAAIgBAMIgLAAIABAfIgLADgAjXAqIAAgBIADgKIABgBIAKAFIAEgBIABgEIgBgEIgFgDIgEgBIgFgHQgCgDAAgGQAAgHAFgEQAEgFAHAAQAGAAAFAEIAAABIgEAJIgBAAIgGgCIgEABQgBABAAAAQAAAAAAABQgBABAAAAQAAABAAAAIACAFIAKAGIADADIADAEIABAFQAAAIgGAEQgFAEgHAAQgIAAgFgEgADmAuIAAgHIgBAAIgHAEQgGAAgDgEQgDgEAAgGQAAgHAEgEQAEgFAGAAIAGABIABAAIAAgCIgCgGIgEgCQgGAAgGAGIAAAAIgDgKQAIgIAIAAQAHAAAEAGQAEAEAAAJIgCAhIAAABIgJABgADbAdIABACIADABQABAAABAAQAAAAABAAQAAgBABAAQAAAAABgBIACgFIgBgCIgCgBQgIABAAAGgAFTAtIgBgzIAHAAIADAAIACAAIABAAIgCAyIAAABIgJAAgAAXAqIgGgHIgDgJIgBgJIACgMQACgGAEgFQAFgEAFAAIAIACIAFAFIADAGIACAIIAAAIIgCALIgGALQgEAEgGAAgAAbAFIgDAGIAAAFIAAAJIACAEIACADIAEABIAFgDIACgHIAAgGIgCgKQgBgFgFAAQgDAAgBADgAh5AoIgBgDIAAgrIAMAAIAAAAIgBAzIgKAAgAEAAsIgCgyIAHgCIAAAAIABAGIAAAAIAFgFIAGgBIAIACIAAAAIgCANIAAAAQgEgDgEAAQgEAAgCAFIgBACIAEAfIgBAAIgLADgAB/AsIgBhGIABAAIAMgBIABAAIgDA5IAVgBIAAAAIgCAOIgdACgAlcAsIAAAAIgBgQQAFADAGAAIAHgBIADgFQAAgFgGgDIgGgDIgFgFIgEgGIgBgIIACgKQAHgOATAAIADABIACAAIAAAQIAAAAIgLAAIgEABIgEADQAAAAAAABQgBAAAAABQAAAAAAABQAAAAAAABIABAEIADADIAKAGIAGAGIACAEIAAAFIgCAKIgGAGIgIAEIgJABgACtAkQgFgHgBgLQgBgKAEgIQAFgIAHgBQAJgBAEAHQAFAGABALIAAADIAAABIgWADQAAAFADACIAHACIAGgDIABAAIADALIAAABQgFAEgIAAQgJAAgEgHgAC4ABIgEAEIgCAGIABABIAMgCQgCgJgEAAIgBAAgAguAkQgEgHgBgLQgBgKAEgIQAEgIAIgBQAIgBAFAHQAEAGABALIABADIgBABIgVADIgBAAQAAAFAEACIAGACIAHgDIAAAAIADALIAAABQgFAEgIAAQgIAAgFgHgAgjABQgCABgCADIgBAGIAAABIAMgCQgBgJgFAAIgBAAgAFSgSIgCgGIACgGQACgDADAAQACAAACADIADAGIgDAHIgFACgAh7gSIgCgGIACgGQACgDADAAQADAAACADIACAGIgCAHIgFACg");
	this.shape_346.setTransform(192.925,134.525);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#DEE99D").s().p("AjBEeIjegQQjogbgyg3QgUgagHg+QgQh6A9i1IAEgNQAKgPAegOQBggqEHgBICRgFQCtgGCTACQHXAFAWBEIATA3QAVBEAFA/QAODIiXBKQh7AYifASQi1AUiIAAQhoAAhQgMg");
	this.shape_347.setTransform(213.7015,110.5688);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#CFDE56").s().p("AjWFhIj3gTQkCgig3hEQgWgggJhMQgRiYBDjeIAFgRQALgTAhgRQBrg0EkgBIChgHQDBgGCjACQIMAGAYBTQAqBrAIB8QAQD4ioBbQiIAdiyAWQjJAZiXAAQh0AAhYgPg");
	this.shape_348.setTransform(213.9686,110.8613);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#A9D046").s().p("ArFGRQg5AAgpgqQgpgsAAg8IAAn+QAAg8ApgrQApgrA5AAIWLAAQA6AAAoArQApArAAA8IAAH+QAAA8gpAsQgoAqg6AAg");
	this.shape_349.setTransform(214,110.55);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f().s("#FFFFFF").ss(1,1,1).p("EBPlALjMifJAAAIAA3FMCfJAAA");
	this.shape_350.setTransform(855.9037,128.075,1.0834,1);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("rgba(255,255,255,0.498)").s().p("EhPkALjIAA3FMCfJAAAIAAXFg");
	this.shape_351.setTransform(855.9037,128.075,1.0834,1);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#3C408C").s().p("EiV/BUYMAAAiovMEr/AAAMAAACovgEiH4BMcMEPxAAAMAAAiY3MkPxAAAg");
	this.shape_352.setTransform(960,540);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f().s("#373535").ss(1,1,1).p("ECH5BMcMkPxAAAMAAAiY3MEPxAAAg");
	this.shape_353.setTransform(959.975,539.975);

	this.instance_5 = new lib.Symbol109("synched",0);
	this.instance_5.setTransform(1283.1,320.45,1,1,0,0,0,478.7,88.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.shape_353},{t:this.shape_352},{t:this.shape_351},{t:this.shape_350},{t:this.shape_349},{t:this.shape_348},{t:this.shape_347},{t:this.shape_346},{t:this.shape_345},{t:this.shape_344},{t:this.shape_343},{t:this.shape_342},{t:this.shape_341},{t:this.shape_340},{t:this.shape_339},{t:this.shape_338},{t:this.shape_337},{t:this.shape_336},{t:this.shape_335},{t:this.shape_334},{t:this.shape_333},{t:this.shape_332},{t:this.shape_331},{t:this.shape_330},{t:this.shape_329},{t:this.shape_328},{t:this.instance_4},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.instance_3},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.b1},{t:this.b2},{t:this.b3},{t:this.b4}]}).wait(1));

	// Layer_5
	this.instance_6 = new lib.Symbol62("synched",0);
	this.instance_6.setTransform(1658.55,1107.5,1,1,0,0,0,225.5,349.5);

	this.instance_7 = new lib.Symbol62("synched",0);
	this.instance_7.setTransform(1476.55,792.5,1,1,0,0,0,225.5,349.5);

	this.instance_8 = new lib.Symbol62("synched",0);
	this.instance_8.setTransform(1231.55,1107.5,1,1,0,0,0,225.5,349.5);

	this.instance_9 = new lib.Symbol62("synched",0);
	this.instance_9.setTransform(951.55,1072.5,1,1,0,0,0,225.5,349.5);

	this.instance_10 = new lib.Symbol62("synched",0);
	this.instance_10.setTransform(671.55,1037.5,1,1,0,0,0,225.5,349.5);

	this.instance_11 = new lib.Symbol62("synched",0);
	this.instance_11.setTransform(391.55,1002.5,1,1,0,0,0,225.5,349.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6}]}).wait(1));

	// Layer_9
	this.instance_12 = new lib.Symbol62("synched",0);
	this.instance_12.setTransform(1126.55,810,1,1,0,0,0,225.5,349.5);

	this.instance_13 = new lib.Symbol62("synched",0);
	this.instance_13.setTransform(776.55,775,1,1,0,0,0,225.5,349.5);

	this.instance_14 = new lib.Symbol62("synched",0);
	this.instance_14.setTransform(426.55,670,1,1,0,0,0,225.5,349.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_14},{t:this.instance_13},{t:this.instance_12}]}).wait(1));

	// Layer_8
	this.instance_15 = new lib.Symbol1_1("synched",0);
	this.instance_15.setTransform(-20.8,-101.3,1.2,1.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(960,540,960,917);
// library properties:
lib.properties = {
	id: '02A7AEEBE82EF047AED1EC1AA7501744',
	width: 1920,
	height: 1080,
	fps: 35,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Bitmap2.png", id:"Bitmap2"},
		{src:"images/Bitmap3.png", id:"Bitmap3"},
		{src:"images/BRIGHTEDGEEDUSYSTEMPVTLTDlogopng1.png", id:"BRIGHTEDGEEDUSYSTEMPVTLTDlogopng1"},
		{src:"images/sound.png", id:"sound"},
		{src:"images/Sunflowerpngwithleaf.png", id:"Sunflowerpngwithleaf"},
		{src:"sounds/yes.mp3", id:"yes"},
		{src:"sounds/intro.mp3", id:"intro"},
		{src:"sounds/wro.mp3", id:"wro"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['02A7AEEBE82EF047AED1EC1AA7501744'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;